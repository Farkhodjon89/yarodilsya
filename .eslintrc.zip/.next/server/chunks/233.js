"use strict";
exports.id = 233;
exports.ids = [233];
exports.modules = {

/***/ 2471:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ components_CatalogActions)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(5692);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
;// CONCATENATED MODULE: ./utility/AddToArray.js
const AddToArray = (item1, array, setArray)=>{
    if (array.map((item)=>item.slug
    ).includes(item1.slug)) {
        const newItems = array.filter((el)=>el.slug !== item1.slug
        );
        setArray(newItems);
    } else if (array) {
        setArray([
            ...array,
            item1
        ]);
    }
};
/* harmony default export */ const utility_AddToArray = (AddToArray);

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./public/icons/ArrowDown.js


const ArrowDown = ()=>{
    return(/*#__PURE__*/ jsx_runtime_.jsx("svg", {
        width: "15",
        height: "10",
        viewBox: "0 0 15 10",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
            d: "M7.03755 9.79769L0.208873 2.10206C-0.0357703 1.84953 -0.0357703 1.43998 0.208873 1.18745C0.453498 0.934914 0.850429 0.934914 1.09507 1.18745L7.51249 8.41906L13.9299 1.18809C14.1745 0.935555 14.5715 0.935555 14.8161 1.18809C15.0607 1.44062 15.0607 1.85017 14.8161 2.10268L7.98741 9.79833C7.85699 9.93292 7.6841 9.99063 7.51311 9.98164C7.34148 9.99001 7.16861 9.93232 7.03755 9.79769Z",
            fill: "#606060"
        })
    }));
};
/* harmony default export */ const icons_ArrowDown = (ArrowDown);

;// CONCATENATED MODULE: ./components/Accordion/Accordion.js



const Accordion = ({ title ='' , children  })=>{
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Accordion, {
        defaultExpanded: true,
        disableGutters: true,
        square: true,
        sx: {
            boxShadow: 'none'
        },
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(material_.AccordionSummary, {
                expandIcon: /*#__PURE__*/ jsx_runtime_.jsx(material_.IconButton, {
                    "aria-label": "ArrowDown",
                    children: /*#__PURE__*/ jsx_runtime_.jsx(icons_ArrowDown, {})
                }),
                "aria-controls": title + 'content',
                id: title + 'header',
                sx: {
                    padding: 0,
                    fontWeight: 600
                },
                children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                    children: title
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(material_.AccordionDetails, {
                sx: {
                    px: 0,
                    maxHeight: 300,
                    overflowY: 'auto'
                },
                children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                    children: children
                })
            })
        ]
    }));
};
/* harmony default export */ const Accordion_Accordion = (Accordion);

;// CONCATENATED MODULE: ./public/icons/ArrowLeft.js


const ArrowLeft = ()=>{
    return(/*#__PURE__*/ jsx_runtime_.jsx("svg", {
        width: "11",
        height: "16",
        viewBox: "0 0 11 16",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
            d: "M0.17041 7.6292C0.17041 7.36047 0.290457 7.09177 0.530046 6.88689L8.07322 0.439676C8.55305 0.0295482 9.33103 0.0295482 9.81068 0.439676C10.2903 0.849637 10.2903 1.51446 9.81068 1.92462L3.13606 7.6292L9.81044 13.3338C10.2901 13.7439 10.2901 14.4087 9.81044 14.8186C9.3308 15.2289 8.55282 15.2289 8.07298 14.8186L0.529814 8.3715C0.290185 8.16652 0.17041 7.89783 0.17041 7.6292Z",
            fill: "#1F3A8F"
        })
    }));
};
/* harmony default export */ const icons_ArrowLeft = (ArrowLeft);

;// CONCATENATED MODULE: ./components/CatalogActions/Filters/Categories.js





const styles = {
    fontWeight: 'normal',
    fontSize: 16,
    lineHeight: '17px',
    justifyContent: 'flex-start',
    marginBottom: '10px',
    color: '#999999',
    textTransform: 'capitalize',
    ':hover': {
        color: 'text.primary'
    }
};
const Categories = ({ category: category1  })=>{
    const router = (0,router_.useRouter)();
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(Accordion_Accordion, {
        title: "Подгатегории",
        children: [
            category1?.parent && /*#__PURE__*/ jsx_runtime_.jsx(material_.Button, {
                onClick: ()=>router.push({
                        pathname: '/catalog/' + category1?.parent?.node?.slug,
                        query: !!router?.query?.onSale ? {
                            onSale: true
                        } : undefined
                    })
                ,
                fullWidth: true,
                startIcon: /*#__PURE__*/ jsx_runtime_.jsx(icons_ArrowLeft, {}),
                sx: styles,
                children: "Назад "
            }),
            category1?.children?.nodes.map((category)=>/*#__PURE__*/ jsx_runtime_.jsx(material_.Button, {
                    onClick: ()=>router.push({
                            pathname: '/catalog/' + category?.slug,
                            query: !!router?.query?.onSale ? {
                                onSale: true
                            } : undefined
                        })
                    ,
                    fullWidth: true,
                    sx: styles,
                    children: category.name
                }, category.databaseId)
            )
        ]
    }));
};
/* harmony default export */ const Filters_Categories = (Categories);

;// CONCATENATED MODULE: ./components/ColorTick/ColorTick.js



// import Tick from 'public/icons/Tick'
const ColorTick = ({ color , active  })=>{
    return(/*#__PURE__*/ _jsx(Box, {
        sx: {
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            width: 20,
            height: 20,
            backgroundColor: color || 'secondary.main',
            borderRadius: '50%'
        }
    }));
};
/* harmony default export */ const ColorTick_ColorTick = ((/* unused pure expression or super */ null && (ColorTick)));

;// CONCATENATED MODULE: ./components/CatalogActions/Filters/Colors.js





const Colors = ({ colors =[] , colorTerms , setColorTerms  })=>{
    return(/*#__PURE__*/ jsx_runtime_.jsx(Accordion_Accordion, {
        title: "Цвет",
        children: colors?.map((color)=>/*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Button, {
                    // startIcon={
                    //   <ColorTick
                    //     color={color.color}
                    //     active={colorTerms
                    //       .map((color) => color.slug)
                    //       .includes(color.slug)}
                    //   />
                    // }
                    fullWidth: true,
                    sx: {
                        fontWeight: 'normal',
                        fontSize: 16,
                        lineHeight: '17px',
                        justifyContent: 'flex-start',
                        textTransform: 'capitalize',
                        // height: 45,
                        color: 'text.primary',
                        marginBottom: '10px'
                    },
                    // color={
                    //   colorTerms.map((color) => color.slug).includes(color.slug)
                    //       ? 'text.primary'
                    //       : 'text.primary'
                    // }
                    onClick: ()=>utility_AddToArray(color, colorTerms, setColorTerms)
                    ,
                    size: "large",
                    children: color.name
                })
            }, color.databaseId)
        )
    }));
};
/* harmony default export */ const Filters_Colors = (Colors);

;// CONCATENATED MODULE: ./components/CatalogActions/Filters/Sizes.js




const Sizes = ({ sizes =[] , sizeTerms , setSizeTerms  })=>{
    return(/*#__PURE__*/ jsx_runtime_.jsx(Accordion_Accordion, {
        title: "Размер",
        children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
            container: true,
            spacing: 1,
            children: sizes?.map((size)=>/*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
                    item: true,
                    xs: 6,
                    children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Button, {
                        fullWidth: true,
                        size: "large",
                        sx: {
                            fontWeight: 'normal',
                            fontSize: 14,
                            color: 'text.primary',
                            '&:hover': {
                                color: 'text.primary'
                            }
                        },
                        variant: sizeTerms.map((color)=>color.slug
                        ).includes(size.slug) ? 'outlined' : 'text',
                        onClick: ()=>utility_AddToArray(size, sizeTerms, setSizeTerms)
                        ,
                        children: size.name
                    })
                }, size.databaseId)
            )
        })
    }));
};
/* harmony default export */ const Filters_Sizes = (Sizes);

;// CONCATENATED MODULE: ./components/CatalogActions/Filters/index.js




const Filters = ({ category , colors , colorTerms , setColorTerms , sizes , sizeTerms , setSizeTerms ,  })=>{
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(Filters_Categories, {
                category: category
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Filters_Colors, {
                colors: colors,
                colorTerms: colorTerms,
                setColorTerms: setColorTerms
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Filters_Sizes, {
                sizes: sizes,
                sizeTerms: sizeTerms,
                setSizeTerms: setSizeTerms
            })
        ]
    }));
};
/* harmony default export */ const CatalogActions_Filters = (Filters);

;// CONCATENATED MODULE: ./components/CatalogActions/MobileFiltersAndSort.js



// import FilterIcon from 'public/icons/Filter'
// import SortIcon from 'public/icons/Sort'
// import Cross from 'public/icons/Cross'
const MobileFiltersAndSort = ({ filtersComponent , sortBy , setSortBy , sortByItems ,  })=>{
    const { 0: open , 1: setOpen  } = (0,external_react_.useState)({
        filter: false,
        sort: false
    });
    const items = [
        {
            name: 'Фильтры',
            // icon: <FilterIcon />,
            open: open.filter,
            close: (r)=>setOpen({
                    filter: r,
                    sort: false
                })
            ,
            drawer: filtersComponent,
            height: '90%'
        },
        {
            name: 'Сортировка',
            // icon: <SortIcon />,
            open: open.sort,
            close: (r)=>setOpen({
                    filter: false,
                    sort: r
                })
            ,
            drawer: /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
                children: /*#__PURE__*/ jsx_runtime_.jsx(material_.FormControl, {
                    component: "fieldset",
                    children: /*#__PURE__*/ jsx_runtime_.jsx(material_.RadioGroup, {
                        "aria-label": "sortBy",
                        name: "sort",
                        children: sortByItems.map((item)=>/*#__PURE__*/ jsx_runtime_.jsx(material_.FormControlLabel, {
                                value: item.value,
                                control: /*#__PURE__*/ jsx_runtime_.jsx(material_.Radio, {}),
                                label: item.name,
                                checked: sortBy === item.value,
                                onChange: (e)=>{
                                    setSortBy(e.target.value);
                                }
                            }, item.name)
                        )
                    })
                })
            }),
            height: '40%'
        }, 
    ];
    return items.map((item)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Grid, {
            item: true,
            xs: 6,
            sx: {
                display: {
                    xs: 'block',
                    md: 'none'
                }
            },
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(material_.Button, {
                    variant: "outlined",
                    size: "large",
                    color: "secondary",
                    startIcon: item.icon,
                    fullWidth: true,
                    onClick: ()=>item.close(true)
                    ,
                    children: item.name
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Drawer, {
                    open: item.open,
                    onClose: ()=>item.close(false)
                    ,
                    sx: {
                        '.MuiDrawer-paper': {
                            height: item.height,
                            p: 2
                        }
                    },
                    anchor: "bottom",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                            sx: {
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'space-between',
                                mb: 2
                            },
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                    variant: "h5",
                                    sx: {
                                        fontWeight: 600
                                    },
                                    children: item.name
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(material_.IconButton, {
                                    "aria-label": "Cross",
                                    onClick: ()=>item.close(false)
                                    ,
                                    sx: {
                                        path: {
                                            stroke: (theme)=>theme.palette.primary.main
                                        }
                                    }
                                })
                            ]
                        }),
                        item.drawer,
                        open.filter && /*#__PURE__*/ jsx_runtime_.jsx(material_.Button, {
                            variant: "outlined",
                            color: "secondary",
                            size: "large",
                            sx: {
                                mt: 2
                            },
                            onClick: ()=>item.close(false)
                            ,
                            children: "Применить"
                        })
                    ]
                })
            ]
        }, item.name)
    );
};
/* harmony default export */ const CatalogActions_MobileFiltersAndSort = (MobileFiltersAndSort);

;// CONCATENATED MODULE: ./public/icons/Cross.js


const Cross = ()=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
        width: "24",
        height: "24",
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                d: "M18.75 5.25L5.25 18.75",
                stroke: "#888281",
                strokeWidth: "2",
                strokeLinecap: "round",
                strokeLinejoin: "round"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                d: "M18.75 18.75L5.25 5.25",
                stroke: "#888281",
                strokeWidth: "2",
                strokeLinecap: "round",
                strokeLinejoin: "round"
            })
        ]
    })
;
/* harmony default export */ const icons_Cross = (Cross);

;// CONCATENATED MODULE: ./components/CatalogActions/index.js




// import Cross from 'public/icons/Cross'



const CatalogActions = ({ onSale , onSearch , sortBy , setSortBy , category , filters , colors , colorTerms , setColorTerms , sizes , sizeTerms , setSizeTerms , brands , brandTerms , setBrandTerms  })=>{
    const router = (0,router_.useRouter)();
    const FiltersComponent = /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx(CatalogActions_Filters, {
            category: category,
            colors: colors,
            colorTerms: colorTerms,
            setColorTerms: setColorTerms,
            sizes: sizes,
            sizeTerms: sizeTerms,
            setSizeTerms: setSizeTerms,
            brands: brands,
            brandTerms: brandTerms,
            setBrandTerms: setBrandTerms
        })
    });
    const ButtonComponent = ({ key , action , name  })=>/*#__PURE__*/ jsx_runtime_.jsx(material_.Button, {
            variant: "contained",
            endIcon: /*#__PURE__*/ jsx_runtime_.jsx(icons_Cross, {}),
            onClick: action,
            sx: {
                m: 1,
                boxShadow: 0,
                color: 'gray',
                backgroundColor: 'rgba(246, 166, 141, 0.15)',
                '&:hover': {
                    color: 'gray',
                    backgroundColor: 'rgba(246, 166, 141, 0.15)'
                }
            },
            children: name
        }, key)
    ;
    const sortByItems = [
        {
            value: '',
            name: 'по умолчанию'
        },
        {
            value: 'DESC',
            name: 'по убыванию'
        },
        {
            value: 'ASC',
            name: 'по возрастанию'
        }, 
    ];
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(CatalogActions_MobileFiltersAndSort, {
                filtersComponent: FiltersComponent,
                sortBy: sortBy,
                setSortBy: setSortBy,
                sortByItems: sortByItems
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
                item: true,
                xs: 3,
                sx: {
                    fontWeight: 600,
                    fontSize: 18,
                    display: {
                        xs: 'none',
                        md: 'block'
                    }
                }
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
                item: true,
                xs: 12,
                md: 7,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                    sx: {
                        display: 'flex',
                        flexWrap: 'wrap'
                    },
                    children: [
                        colorTerms.map((color)=>/*#__PURE__*/ jsx_runtime_.jsx(ButtonComponent, {
                                name: color.name,
                                action: ()=>utility_AddToArray(color, colorTerms, setColorTerms)
                            }, color.databaseId)
                        ),
                        sizeTerms.map((size)=>/*#__PURE__*/ jsx_runtime_.jsx(ButtonComponent, {
                                name: size.name,
                                action: ()=>utility_AddToArray(size, sizeTerms, setSizeTerms)
                            }, size.databaseId)
                        ),
                        onSale && /*#__PURE__*/ jsx_runtime_.jsx(ButtonComponent, {
                            name: "Скидки",
                            action: ()=>router.push('/catalog/' + router?.query?.slug)
                        }, "Скидки"),
                        onSearch && /*#__PURE__*/ jsx_runtime_.jsx(ButtonComponent, {
                            name: 'Поиск: ' + onSearch,
                            action: ()=>router.push('/catalog/' + router?.query?.slug)
                        }, "Скидки"),
                        !!filters.length && /*#__PURE__*/ jsx_runtime_.jsx(material_.Button, {
                            color: "grey",
                            variant: "outlined",
                            endIcon: /*#__PURE__*/ jsx_runtime_.jsx(icons_Cross, {}),
                            onClick: ()=>{
                                setColorTerms([]);
                                setSizeTerms([]);
                            },
                            sx: {
                                m: 1
                            },
                            children: "Очистить"
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
                item: true,
                xs: 2,
                sx: {
                    display: {
                        xs: 'none',
                        md: 'block'
                    }
                },
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.FormControl, {
                    fullWidth: true,
                    variant: "standard",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(material_.InputLabel, {
                            id: "demo-simple-select-label",
                            children: "Сортировка"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(material_.Select, {
                            labelId: "demo-simple-select-label",
                            id: "demo-simple-select",
                            label: "sort",
                            value: sortBy,
                            onChange: (e)=>{
                                setSortBy(e.target.value);
                            },
                            children: sortByItems.map((item)=>/*#__PURE__*/ jsx_runtime_.jsx(material_.MenuItem, {
                                    value: item.value,
                                    children: item.name
                                }, item.name)
                            )
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
                item: true,
                xs: 3,
                sx: {
                    display: {
                        xs: 'none',
                        md: 'block'
                    }
                },
                children: FiltersComponent
            })
        ]
    }));
};
/* harmony default export */ const components_CatalogActions = (CatalogActions);


/***/ }),

/***/ 9674:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);


const Empty = ({ title =''  })=>{
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
        sx: {
            border: 1,
            borderRadius: 1,
            textAlign: 'center',
            py: {
                xs: 8,
                md: 16
            },
            my: 4
        },
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
            variant: "h6",
            children: [
                " ",
                title
            ]
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Empty);


/***/ }),

/***/ 9296:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1664);
/* harmony import */ var _ProductItem_product_item__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(428);







// import Plus from 'public/icons/Plus'
const ProductsList = ({ products =[] , like , homeSlug  })=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            like && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Box, {
                sx: {
                    fontWeight: 600,
                    fontSize: 20,
                    textAlign: 'center',
                    mb: 4
                },
                children: "Вам может понравиться"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {
                container: true,
                spacing: {
                    xs: 2,
                    md: 4
                },
                sx: {
                    mb: 4
                },
                children: [
                    products.map((product)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {
                            item: true,
                            xs: 6,
                            md: 3,
                            sx: {
                                textAlign: {
                                    xs: 'center',
                                    md: 'start'
                                }
                            },
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ProductItem_product_item__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                product: product
                            })
                        }, product?.databaseId)
                    ),
                    homeSlug && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {
                        item: true,
                        xs: 6,
                        md: 4,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_4__["default"], {
                            href: '/catalog/' + homeSlug,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Box, {
                                    sx: {
                                        backgroundColor: 'secondary.main',
                                        color: 'white',
                                        height: '100%',
                                        display: 'flex',
                                        flexDirection: 'column',
                                        alignItems: 'center',
                                        justifyContent: 'center',
                                        '&:hover': {
                                            boxShadow: 3
                                        }
                                    },
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Box, {
                                            sx: {
                                                display: {
                                                    xs: 'none',
                                                    md: 'block'
                                                },
                                                fontWeight: 'bold',
                                                mb: 5
                                            },
                                            children: "Показать больше"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Box, {
                                            mt: 5,
                                            children: "еще 10"
                                        })
                                    ]
                                })
                            })
                        })
                    })
                ]
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProductsList);


/***/ }),

/***/ 2481:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "s": () => (/* binding */ useFirstRender)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

const useFirstRender = ()=>{
    const firstRender = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(true);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        firstRender.current = false;
    }, []);
    return firstRender.current;
};


/***/ })

};
;