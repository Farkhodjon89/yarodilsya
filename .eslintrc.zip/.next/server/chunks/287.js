"use strict";
exports.id = 287;
exports.ids = [287];
exports.modules = {

/***/ 287:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "b": () => (/* binding */ checkSession)
/* harmony export */ });
/* harmony import */ var jsonwebtoken__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9344);
/* harmony import */ var jsonwebtoken__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(jsonwebtoken__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var uuid__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6555);
/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9528);
/* harmony import */ var _mutations_auth__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2651);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([uuid__WEBPACK_IMPORTED_MODULE_1__]);
uuid__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];




// We need to check the cookie before to use it
// check required bcz there can be the case when
// auth token is expired
const checkSession = async (userData, request)=>{
    if (userData == null || !userData.isLoggedIn) {
        return {
            isLoggedIn: false
        };
    }
    const { exp  } = jsonwebtoken__WEBPACK_IMPORTED_MODULE_0___default().decode(userData.authToken);
    if (Date.now() / 1000 >= exp) {
        let refreshResult;
        try {
            refreshResult = await _apollo_client__WEBPACK_IMPORTED_MODULE_2__/* .client.query */ .L.query({
                query: _mutations_auth__WEBPACK_IMPORTED_MODULE_3__/* .REFRESH_TOKEN */ .z6,
                fetchPolicy: 'no-cache',
                variables: {
                    mutationId: (0,uuid__WEBPACK_IMPORTED_MODULE_1__.v4)(),
                    token: userData.refreshToken
                }
            });
        } catch (e) {
            request.session.set('user', {
                isLoggedIn: false
            });
            await request.session.save();
            return {
                isLoggedIn: false
            };
        }
        const { authToken  } = refreshResult.data.refreshJwtAuthToken;
        request.session.set('user', {
            ...userData,
            authToken
        });
        await request.session.save();
        return {
            ...userData,
            authToken
        };
    }
    return userData;
};

});

/***/ })

};
;