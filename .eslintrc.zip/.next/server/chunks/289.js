"use strict";
exports.id = 289;
exports.ids = [289];
exports.modules = {

/***/ 5289:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "eD": () => (/* binding */ CustomerFragment),
/* harmony export */   "cJ": () => (/* binding */ CUSTOMER),
/* harmony export */   "u3": () => (/* binding */ CUSTOMER_ORDERS),
/* harmony export */   "AI": () => (/* binding */ CUSTOMER_ORDER)
/* harmony export */ });
/* harmony import */ var graphql_tag__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(825);
/* harmony import */ var graphql_tag__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(graphql_tag__WEBPACK_IMPORTED_MODULE_0__);

const CustomerFragment = (graphql_tag__WEBPACK_IMPORTED_MODULE_0___default())`
  fragment _Customer on Customer {
    id
    databaseId
    firstName
    lastName
    email
    billing {
      address1
      city
      phone
    }
  }
`;
const CUSTOMER = (graphql_tag__WEBPACK_IMPORTED_MODULE_0___default())`
  query Customer($customerId: Int) {
    customer(customerId: $customerId) {
      ..._Customer
    }
  }
  ${CustomerFragment}
`;
const CUSTOMER_ORDERS = (graphql_tag__WEBPACK_IMPORTED_MODULE_0___default())`
query CustomerOrders($customerId: Int) {
  orders(first: 50, where: {customerId: $customerId}) {
    nodes {
      databaseId
      date
      status
      customerNote
      total
      paymentMethodTitle
      billing {
        address1
      }
      lineItems {
        nodes {
          product {
            ... on SimpleProduct {
              price(format: RAW)
            }
            ... on VariableProduct {
              price(format: RAW)
            }
            name
            image {
              sourceUrl
            }
          }
          quantity
          total
          color: metaData(key: "pa_color") {
            value
          }
          size: metaData(key: "pa_size") {
            value
          }
        }
      }
    }
  } 
}
`;
const CUSTOMER_ORDER = (graphql_tag__WEBPACK_IMPORTED_MODULE_0___default())`
query CustomerOrder($orderId: ID!) {
  order(id: $orderId, idType: DATABASE_ID) {
    databaseId
    date
    total
    paymentMethodTitle
    subtotal
    shippingTotal
    status
    shipping {
      address1
    }
    billing {
      firstName
      phone
    }
    customerNote
    lineItems {
      nodes {
        quantity
        subtotal
        product {
          name
        }
      }
    }
  }
}
`;


/***/ })

};
;