"use strict";
exports.id = 293;
exports.ids = [293];
exports.modules = {

/***/ 9528:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "L": () => (/* binding */ client)
/* harmony export */ });
/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9114);
/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_apollo_client__WEBPACK_IMPORTED_MODULE_0__);

const client = new _apollo_client__WEBPACK_IMPORTED_MODULE_0__.ApolloClient({
    uri: "https://kids-planet.billz.work/graphql",
    cache: new _apollo_client__WEBPACK_IMPORTED_MODULE_0__.InMemoryCache()
});


/***/ }),

/***/ 2651:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "I2": () => (/* binding */ SIGN_UP_SEND_OTP),
/* harmony export */   "qs": () => (/* binding */ LOGIN_SEND_OTP),
/* harmony export */   "$H": () => (/* binding */ OTP_AUTH),
/* harmony export */   "z6": () => (/* binding */ REFRESH_TOKEN)
/* harmony export */ });
/* harmony import */ var graphql_tag__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(825);
/* harmony import */ var graphql_tag__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(graphql_tag__WEBPACK_IMPORTED_MODULE_0__);

const SIGN_UP_SEND_OTP = (graphql_tag__WEBPACK_IMPORTED_MODULE_0___default())`
mutation SignUpSendOtp($mutationId: String!, $phone: String!, $firstName: String!, $lastName: String) {
  loginSendOtp(input: {clientMutationId: $mutationId, phone: $phone, firstName: $firstName, lastName: $lastName}) {
    exp
  }
}
`;
const LOGIN_SEND_OTP = (graphql_tag__WEBPACK_IMPORTED_MODULE_0___default())`
mutation LoginSendOtp($mutationId: String!, $phone: String!) {
  loginSendOtp(input: {clientMutationId: $mutationId, phone: $phone}) {
    exp
  }
}
`;
const OTP_AUTH = (graphql_tag__WEBPACK_IMPORTED_MODULE_0___default())`
mutation OtpAuth($mutationId: String!, $otp: String!, $phone: String!) {
  login(input: {clientMutationId: $mutationId, otp: $otp, phone: $phone}) {
    authToken
    refreshToken
    sessionToken
  }
}
`;
const REFRESH_TOKEN = (graphql_tag__WEBPACK_IMPORTED_MODULE_0___default())`
mutation RefreshAuthToken($mutationId: String!, $token: String!) {
  refreshJwtAuthToken(
    input: {
      clientMutationId: $mutationId,
      jwtRefreshToken: $token,
  }) {
    authToken
  }
}
`;


/***/ }),

/***/ 453:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ withSession)
/* harmony export */ });
/* harmony import */ var next_iron_session__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4511);
/* harmony import */ var next_iron_session__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_iron_session__WEBPACK_IMPORTED_MODULE_0__);

// add cookies to requests
function withSession(handler) {
    return (0,next_iron_session__WEBPACK_IMPORTED_MODULE_0__.withIronSession)(handler, {
        password: 'k2g37eqwhh01qn2r5fsh0l5trgqfafqo',
        cookieName: 'auth-cookie',
        cookieOptions: {
            secure: "production" === 'production'
        }
    });
};


/***/ })

};
;