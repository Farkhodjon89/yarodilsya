"use strict";
exports.id = 428;
exports.ids = [428];
exports.modules = {

/***/ 5593:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ product_card_accordion)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(5692);
// EXTERNAL MODULE: ./public/icons/arrowDown.js
var arrowDown = __webpack_require__(4687);
;// CONCATENATED MODULE: ./public/icons/DeliveryIcon.js


const DeliveryIcon = ()=>{
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
        width: "35",
        height: "26",
        viewBox: "0 0 35 26",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                d: "M0 8.56055L10 8.56055",
                stroke: "#EA56AE",
                strokeWidth: "2"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                d: "M5 19.5605L10 19.5605",
                stroke: "#EA56AE",
                strokeWidth: "2"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                d: "M24.9087 13.2049L23.7354 13.8792V25.9999L34.3012 19.9423V7.82153L24.9087 13.2049Z",
                fill: "#EA56AE"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                d: "M26.8219 2.33568L22.7586 0L11.8994 6.22489L15.9682 8.56057L26.8219 2.33568Z",
                fill: "#EA56AE"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                d: "M33.6116 6.22496L28.9289 3.57642L18.0752 9.80131L18.6945 10.1196L22.7578 12.4499L26.7995 10.1357L33.6116 6.22496Z",
                fill: "#EA56AE"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                d: "M17.2556 14.2569L15.3108 13.2644V10.1789L11.3018 7.88641V19.9208L21.7915 25.9354V13.9009L17.2556 11.3063V14.2569Z",
                fill: "#EA56AE"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                d: "M2 14.5605L10 14.5605",
                stroke: "#EA56AE",
                strokeWidth: "2"
            })
        ]
    }));
};
/* harmony default export */ const icons_DeliveryIcon = (DeliveryIcon);

;// CONCATENATED MODULE: ./public/icons/Wallet.js


const Wallet = ()=>{
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
        width: "23",
        height: "22",
        viewBox: "0 0 23 22",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                d: "M16.8883 17.1977C15.7861 17.1976 14.8895 16.3094 14.8895 15.2175V11.9291C14.8895 10.8372 15.7861 9.94898 16.8883 9.94898H22.0964C22.1279 9.94898 22.1593 9.94993 22.1905 9.95132V6.67549C22.1905 5.83225 21.5005 5.14868 20.6493 5.14868H1.54121C0.69 5.14863 0 5.8322 0 6.67544V20.4711C0 21.3144 0.69 21.998 1.54121 21.998H20.6493C21.5005 21.998 22.1905 21.3144 22.1905 20.4711V17.1953C22.1593 17.1967 22.1279 17.1977 22.0964 17.1977H16.8883Z",
                fill: "#EA56AE"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                d: "M22.096 11.0338H16.8879C16.3889 11.0338 15.9844 11.4346 15.9844 11.9289V15.2174C15.9844 15.7117 16.3889 16.1125 16.8879 16.1125H22.096C22.595 16.1125 22.9995 15.7118 22.9995 15.2174V11.9289C22.9995 11.4345 22.595 11.0338 22.096 11.0338ZM18.6825 14.8651C17.9623 14.8651 17.3784 14.2866 17.3784 13.5731C17.3784 12.8596 17.9623 12.2811 18.6825 12.2811C19.4028 12.2811 19.9866 12.8596 19.9866 13.5731C19.9866 14.2866 19.4028 14.8651 18.6825 14.8651Z",
                fill: "#EA56AE"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                d: "M17.9646 2.35165C17.6198 1.31775 16.4943 0.756521 15.4507 1.09811L7.62109 3.6607H18.4012L17.9646 2.35165Z",
                fill: "#EA56AE"
            })
        ]
    }));
};
/* harmony default export */ const icons_Wallet = (Wallet);

;// CONCATENATED MODULE: ./components/ProductCardAccordion/product-card-accordion.js






const ProductCardAccordion = ()=>{
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Accordion, {
                sx: {
                    backgroundColor: 'transparent',
                    boxShadow: 'none',
                    borderTop: '1px solid #E8E8E8'
                },
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.AccordionSummary, {
                        expandIcon: /*#__PURE__*/ jsx_runtime_.jsx(arrowDown/* default */.Z, {}),
                        "aria-controls": "panel1a-content",
                        id: "panel1a-header",
                        sx: {
                            display: 'flex',
                            alignItems: 'center'
                        },
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(material_.IconButton, {
                                "aria-label": "delivery",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(icons_DeliveryIcon, {})
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                sx: {
                                    fontWeight: 600,
                                    fontSize: '16px',
                                    color: 'text.primary'
                                },
                                children: "Доставка по Ташкенту"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.AccordionDetails, {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                            sx: {
                                fontWeight: 400,
                                fontSize: '16px',
                                color: 'grey.main'
                            },
                            children: "Формула шампуня для тела и волос Chicco Baby Moments мягко очищает нежную кожу малыша, начиная с принятия первых ванн."
                        })
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(material_.Accordion, {
                sx: {
                    backgroundColor: 'transparent',
                    boxShadow: 'none',
                    borderTop: '1px solid #E8E8E8'
                },
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.AccordionSummary, {
                    expandIcon: /*#__PURE__*/ jsx_runtime_.jsx(arrowDown/* default */.Z, {}),
                    "aria-controls": "panel1a-content",
                    id: "panel1a-header",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(material_.IconButton, {
                            "aria-label": "delivery",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(icons_DeliveryIcon, {})
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                            sx: {
                                fontWeight: 600,
                                fontSize: '16px',
                                color: 'text.primary'
                            },
                            children: "Доставка по Узбекистану"
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Accordion, {
                sx: {
                    backgroundColor: 'transparent',
                    boxShadow: 'none',
                    borderTop: '1px solid #E8E8E8'
                },
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.AccordionSummary, {
                        expandIcon: /*#__PURE__*/ jsx_runtime_.jsx(arrowDown/* default */.Z, {}),
                        "aria-controls": "panel1a-content",
                        id: "panel1a-header",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(material_.IconButton, {
                                "aria-label": "delivery",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(icons_Wallet, {})
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                sx: {
                                    fontWeight: 600,
                                    fontSize: '16px',
                                    color: 'text.primary'
                                },
                                children: "Оплата"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.AccordionDetails, {
                        sx: {
                            fontWeight: 400,
                            fontSize: '16px',
                            color: 'grey.main'
                        },
                        children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                            children: "Детское молочко содержит уникальную комбинацию ингредиентов: OPTIPRO\xae, 2’FL и BL Probiotic, которые поддержат здоровое развитие вашего ребенка"
                        })
                    })
                ]
            })
        ]
    }));
};
/* harmony default export */ const product_card_accordion = (ProductCardAccordion);


/***/ }),

/***/ 428:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ product_item)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(5692);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: ./components/QuantityCount/quantity-count.js + 1 modules
var quantity_count = __webpack_require__(7863);
// EXTERNAL MODULE: ./utility/FormatPrice.js
var FormatPrice = __webpack_require__(740);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(6022);
// EXTERNAL MODULE: ./redux/actions/cart.js
var actions_cart = __webpack_require__(6613);
// EXTERNAL MODULE: external "@mui/material/useMediaQuery"
var useMediaQuery_ = __webpack_require__(9868);
var useMediaQuery_default = /*#__PURE__*/__webpack_require__.n(useMediaQuery_);
// EXTERNAL MODULE: external "react-image-gallery"
var external_react_image_gallery_ = __webpack_require__(9585);
var external_react_image_gallery_default = /*#__PURE__*/__webpack_require__.n(external_react_image_gallery_);
// EXTERNAL MODULE: ./public/icons/Heart.js
var Heart = __webpack_require__(6842);
// EXTERNAL MODULE: ./components/ProductCardAccordion/product-card-accordion.js + 2 modules
var product_card_accordion = __webpack_require__(5593);
// EXTERNAL MODULE: ./components/SectionTitle/section-title.js
var section_title = __webpack_require__(2161);
// EXTERNAL MODULE: external "react-dom"
var external_react_dom_ = __webpack_require__(6405);
var external_react_dom_default = /*#__PURE__*/__webpack_require__.n(external_react_dom_);
;// CONCATENATED MODULE: ./components/CartModal/cart-modal.js













const CartModal = ({ product , cartModal , modal ='modal' , setCartModal  })=>{
    const { 0: selectedSize , 1: setSelectedSize  } = (0,external_react_.useState)('');
    const { 0: quantity , 1: setQuantity  } = (0,external_react_.useState)(1);
    const { 0: selectedId , 1: setSelectedId  } = (0,external_react_.useState)(0);
    const matches = useMediaQuery_default()('(max-width: 600px)');
    const dispatch = (0,external_react_redux_.useDispatch)();
    const cart = (0,external_react_redux_.useSelector)((state)=>state.cart
    );
    const wishlist = (0,external_react_redux_.useSelector)((state)=>state.wishlist
    );
    const alreadyAddedToCart = !!cart.find((item)=>item.selectedId === selectedId
    );
    const alreadyAddedToWishlist = !!wishlist.find((item)=>item.databaseId === selectedId
    );
    const sizes = product?.variations ? product.variations?.nodes?.map((variation)=>({
            databaseId: variation.databaseId,
            stockQuantity: variation.stockQuantity,
            size: variation.size?.nodes[0]?.value
        })
    ) : [
        {
            databaseId: product.databaseId,
            stockQuantity: product.stockQuantity,
            size: product?.size?.nodes[0]?.options
        }, 
    ];
    const images = [
        {
            original: product.image.sourceUrl,
            thumbnail: product.image.sourceUrl
        }, 
    ];
    return(/*#__PURE__*/ external_react_dom_default().createPortal(/*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
            sx: {
                position: 'fixed',
                width: '100vw',
                height: '100vh',
                top: '100px',
                display: cartModal ? 'block' : 'none',
                left: '0',
                backgroundColor: 'rgba(0, 0, 0, 0.4);',
                zIndex: 8
            },
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                sx: {
                    position: 'fixed',
                    top: '185px',
                    left: '50%',
                    transform: 'translate(-50%)',
                    borderRadius: '8px',
                    width: '900px',
                    height: '530px',
                    display: cartModal ? 'block' : 'none',
                    backgroundColor: '#fff',
                    padding: '20px',
                    zIndex: 9
                },
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                        sx: {
                            display: 'flex',
                            justifyContent: 'space-between',
                            alignItems: 'center',
                            cursor: 'pointer'
                        },
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(section_title/* default */.Z, {
                                modal: modal,
                                title: product.name
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                                onClick: ()=>setCartModal(false)
                                ,
                                children: "Закрыть"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                        sx: {
                            display: 'flex',
                            flexDirection: {
                                xs: 'column',
                                md: 'row'
                            },
                            marginBottom: {
                                xs: '15px',
                                md: '90px'
                            }
                        },
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                                sx: {
                                    width: {
                                        xs: '100%',
                                        marginRight: '20px',
                                        md: '45%'
                                    },
                                    mb: {
                                        xs: 2,
                                        md: 0
                                    },
                                    '.image-gallery-slide .image-gallery-image': {
                                        objectFit: 'cover !important',
                                        minHeight: {
                                            xs: '340px !important',
                                            md: '380px !important'
                                        },
                                        height: {
                                            xs: '340px !important',
                                            md: '380px !important'
                                        },
                                        maxHeight: {
                                            xs: '340px !important',
                                            md: '380px !important'
                                        }
                                    },
                                    '.image-gallery-thumbnail': {
                                        width: {
                                            md: '60px'
                                        },
                                        borderRadius: '8px'
                                    },
                                    '.image-gallery-thumbnail ': {
                                        border: '2px solid #EA56AE;'
                                    },
                                    '.image-gallery-right-nav .image-gallery-svg': {
                                        height: '72px !important',
                                        width: '36px !important'
                                    },
                                    '.image-gallery-left-nav .image-gallery-svg': {
                                        height: '72px !important',
                                        width: '36px !important'
                                    },
                                    '@media (hover: hover) and (pointer: fine)': {
                                        '.image-gallery-icon:hover': {
                                            color: '#f6a68d !important'
                                        },
                                        '.image-gallery-bullets .image-gallery-bullet:hover': {
                                            background: '#f6a68d !important',
                                            border: '1px solid #f6a68d !important'
                                        }
                                    }
                                },
                                children: /*#__PURE__*/ jsx_runtime_.jsx((external_react_image_gallery_default()), {
                                    items: images,
                                    thumbnailPosition: "left",
                                    showThumbnails: !matches,
                                    showBullets: false,
                                    showPlayButton: false,
                                    showFullscreenButton: false,
                                    autoPlay: false
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                                sx: {
                                    width: {
                                        xs: '100%',
                                        md: '40%'
                                    }
                                },
                                children: [
                                    product.onSale ? /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                        sx: {
                                            fontWeight: '600',
                                            fontSize: {
                                                xs: '16px',
                                                md: '25px'
                                            },
                                            color: 'text.primary'
                                        },
                                        children: (0,FormatPrice/* default */.Z)(product.woocsSalePrice)
                                    }) : /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                        sx: {
                                            fontWeight: 600,
                                            fontSize: '25px'
                                        },
                                        children: (0,FormatPrice/* default */.Z)(product.woocsRegularPrice)
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Typography, {
                                        sx: {
                                            color: 'grey.main',
                                            fontSize: '15px',
                                            fontWeight: '400',
                                            marginBottom: '30px'
                                        },
                                        children: [
                                            "Артикул: ",
                                            product.sku
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
                                        container: true,
                                        spacing: 1,
                                        children: sizes.map(({ databaseId , stockQuantity , size  })=>{
                                            const currentSize = selectedSize === size;
                                            return(/*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
                                                item: true,
                                                xs: 3,
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Button, {
                                                    sx: {
                                                        fontWeight: 'normal',
                                                        fontSize: 11,
                                                        padding: '6px 12px',
                                                        color: 'grey.main'
                                                    },
                                                    color: currentSize ? 'secondary' : 'primary',
                                                    variant: currentSize ? 'contained' : 'text',
                                                    onClick: ()=>{
                                                        setSelectedId(databaseId);
                                                        setSelectedSize(size);
                                                        setMaxQuantity(stockQuantity);
                                                    },
                                                    children: size
                                                })
                                            }, databaseId));
                                        })
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Stack, {
                                        direction: "row",
                                        spacing: 2,
                                        sx: {
                                            margin: '20px 0',
                                            alignItems: 'center'
                                        },
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx(quantity_count/* default */.Z, {
                                                product: product,
                                                quantity: quantity,
                                                setQuantity: setQuantity
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx(material_.Button, {
                                                variant: "contained",
                                                color: !alreadyAddedToCart ? 'primary' : 'secondary',
                                                sx: {
                                                    height: '35px',
                                                    width: {
                                                        xs: '140px',
                                                        md: '160px'
                                                    },
                                                    borderRadius: '8px',
                                                    display: 'flex',
                                                    justifyContent: 'center',
                                                    alignItems: 'center',
                                                    boxShadow: 'none',
                                                    fontSize: '10px',
                                                    color: 'white.main'
                                                },
                                                disabled: !selectedSize,
                                                onClick: ()=>{
                                                    alreadyAddedToCart ? ()=>dispatch((0,actions_cart/* removeFromCart */.h2)(selectedId))
                                                     : ()=>{
                                                        dispatch((0,actions_cart/* addToCart */.Xq)(product, selectedId, selectedSize, quantity));
                                                        setCartModal(true);
                                                    };
                                                },
                                                children: selectedSize ? alreadyAddedToCart ? 'В корзине' : 'Добавить в корзину' : 'Выбрать размер'
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx(material_.IconButton, {
                                                "aria-label": "wishlist",
                                                onClick: ()=>addToWishlist((prev)=>!prev
                                                    )
                                                ,
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(Heart/* default */.Z, {})
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(product_card_accordion/* default */.Z, {})
                                ]
                            })
                        ]
                    })
                ]
            })
        })
    }), document.getElementById('portal')));
};
/* harmony default export */ const cart_modal = (CartModal);

;// CONCATENATED MODULE: ./components/ProductItem/product-item.js










const ProductItem = ({ product , title  })=>{
    const { 0: quantity , 1: setQuantity  } = (0,external_react_.useState)(1);
    const { 0: visible , 1: setVisible  } = (0,external_react_.useState)(false);
    const { 0: cartModal , 1: setCartModal  } = (0,external_react_.useState)(false);
    const cart = (0,external_react_redux_.useSelector)((state)=>state.cart
    );
    const wishlist = (0,external_react_redux_.useSelector)((state)=>state.wishlist
    );
    const dispatch = (0,external_react_redux_.useDispatch)();
    const matches = useMediaQuery_default()('(max-width: 600px)');
    const alreadyAddedToCart = !!cart.find((item)=>item.selectedId === product.databaseId
    );
    const alreadyAddedToWishlist = !!wishlist.find((item)=>item.databaseId === product.databaseId
    );
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Card, {
        sx: {
            maxWidth: {
                xs: '180px',
                md: '200px'
            },
            boxShadow: 'none',
            position: 'relative',
            marginRight: title === 'Товар дня' || matches ? '0px' : '20px',
            borderRadius: '8px',
            transition: 'all .3s ease 0s',
            marginBottom: title === 'Товар дня' ? '0px' : '40px',
            border: '2px solid transparent',
            '&:hover': {
                border: '2px solid #F2F2F2;',
                boxShadow: '0 0 5px rgba(0,0,0,0.5)'
            }
        },
        onMouseEnter: ()=>setVisible(true)
        ,
        onMouseLeave: ()=>setVisible(false)
        ,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                sx: {
                    borderRadius: '50px',
                    backgroundColor: 'rgba(255,255,255,.9)',
                    cursor: 'pointer',
                    padding: '11px 10px',
                    border: 'none',
                    display: visible ? 'block' : 'none',
                    position: 'absolute',
                    transition: 'all .3s ease 0s',
                    top: '25%',
                    left: '12%',
                    zIndex: 6
                },
                onClick: ()=>setCartModal(!cartModal)
                ,
                children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                    sx: {
                        fontSize: '13px',
                        lineHeight: '16px'
                    },
                    children: "Быстрый просмотр"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(cart_modal, {
                product: product,
                cartModal: cartModal,
                setCartModal: setCartModal
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                href: `/product/${product.slug}`,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(material_.CardMedia, {
                            sx: {
                                height: 200,
                                borderTopLeftRadius: '8px',
                                borderTopRightRadius: '8px'
                            },
                            image: product.image.sourceUrl
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.CardContent, {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                    sx: {
                                        fontWeight: 400,
                                        fontSize: '15px',
                                        color: 'grey.main',
                                        display: 'webkitBox',
                                        webkitBoxOrient: 'vertical',
                                        webkitLineClamp: '2',
                                        textOverflow: 'ellipsis',
                                        overflow: 'hidden'
                                    },
                                    children: product.name
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                    sx: {
                                        fontWeight: 600,
                                        fontSize: {
                                            xs: '15px',
                                            md: '19px'
                                        },
                                        color: 'text.primary'
                                    },
                                    children: (0,FormatPrice/* default */.Z)(product.woocsRegularPrice)
                                })
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.CardActions, {
                sx: {
                    justifyContent: 'space-between',
                    display: 'flex'
                },
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Button, {
                        onClick: alreadyAddedToCart ? ()=>dispatch((0,actions_cart/* removeFromCart */.h2)(product.databaseId))
                         : ()=>{
                            dispatch((0,actions_cart/* addToCart */.Xq)(product, product.databaseId, quantity));
                        },
                        sx: {
                            textTransform: 'initial',
                            height: {
                                xs: 30,
                                md: '40px'
                            },
                            maxWidth: '100px',
                            fontSize: {
                                xs: 12,
                                md: 13
                            },
                            boxShadow: 'none',
                            color: 'white.main',
                            borderRadius: {
                                xs: '8px',
                                md: '5px'
                            },
                            ':hover': {
                                backgroundColor: !alreadyAddedToCart ? '#FB66BF' : '#3DCA97'
                            }
                        },
                        variant: "contained",
                        color: !alreadyAddedToCart ? 'primary' : 'secondary',
                        children: !alreadyAddedToCart ? 'В корзину' : 'В корзине'
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(quantity_count/* default */.Z, {
                        product: product,
                        quantityToCart: actions_cart/* quantityToCart */.nx,
                        quantity: quantity,
                        setQuantity: setQuantity
                    })
                ]
            })
        ]
    }));
};
/* harmony default export */ const product_item = (ProductItem);


/***/ }),

/***/ 6842:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const Heart = ()=>{
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
        width: "25",
        height: "26",
        viewBox: "0 0 25 26",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
            d: "M17.9114 2.65167C15.8259 2.64052 13.8433 3.55643 12.5 5.15164C11.165 3.54552 9.17695 2.62702 7.08857 2.65167C3.17365 2.65167 0 5.82531 0 9.74024C0 16.4491 11.7088 22.9997 12.1835 23.2529C12.3751 23.3809 12.6249 23.3809 12.8165 23.2529C13.2912 22.9997 25 16.5441 25 9.74024C25 5.82531 21.8263 2.65167 17.9114 2.65167ZM12.5 21.9871C10.6645 20.9111 1.26582 15.1833 1.26582 9.74024C1.26582 6.52443 3.87276 3.91743 7.08863 3.91743C9.05793 3.89157 10.9009 4.88488 11.962 6.544C12.1775 6.8411 12.5931 6.9073 12.8902 6.69179C12.9469 6.6506 12.9968 6.60075 13.038 6.544C14.7979 3.8525 18.4065 3.09729 21.098 4.8572C22.7456 5.93459 23.7374 7.77154 23.7341 9.74018C23.7342 15.2466 14.3354 20.9428 12.5 21.9871Z",
            fill: "#EA56AE"
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Heart);


/***/ })

};
;