"use strict";
exports.id = 667;
exports.ids = [667];
exports.modules = {

/***/ 7863:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ quantity_count)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(5692);
;// CONCATENATED MODULE: ./public/icons/arrowLeftSmall.js


const ArrowLeftSmall = ()=>{
    return(/*#__PURE__*/ jsx_runtime_.jsx("svg", {
        width: "8",
        height: "14",
        viewBox: "0 0 8 14",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
            d: "M0.319485 6.61154L6.82282 0.793229C7.03616 0.584863 7.38352 0.583446 7.59854 0.790064C7.81357 0.996666 7.81495 1.33332 7.60161 1.54169L1.4904 7.00958L7.64549 12.4274C7.86052 12.634 7.86189 12.9707 7.64856 13.179C7.43522 13.3874 7.08786 13.3888 6.87285 13.1822L0.322229 7.41715C0.207622 7.30701 0.158081 7.16057 0.165114 7.01552C0.157422 6.86998 0.20575 6.72316 0.319485 6.61154Z",
            fill: "#606060"
        })
    }));
};
/* harmony default export */ const arrowLeftSmall = (ArrowLeftSmall);

// EXTERNAL MODULE: ./public/icons/arrowRightSmall.js
var arrowRightSmall = __webpack_require__(5194);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(6022);
// EXTERNAL MODULE: ./redux/actions/cart.js
var cart = __webpack_require__(6613);
;// CONCATENATED MODULE: ./components/QuantityCount/quantity-count.js







const QuantityCount = ({ quantity , setQuantity , product  })=>{
    const dispatch = (0,external_react_redux_.useDispatch)();
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(material_.Button, {
                sx: {
                    minWidth: {
                        xs: '14px',
                        md: '20px'
                    },
                    minHeight: {
                        xs: '14px',
                        md: '20px'
                    },
                    borderRadius: '50%',
                    border: '1px solid #E8E8E8',
                    '&:hover': {
                        border: '1px solid #49D6A3;',
                        background: 'rgba(73, 214, 163, 0.1);'
                    }
                },
                onClick: ()=>dispatch((0,cart/* quantityToCart */.nx)(product.databaseId, quantity))
                ,
                children: /*#__PURE__*/ jsx_runtime_.jsx(arrowLeftSmall, {})
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                style: {
                    width: '15px',
                    border: '0',
                    outline: 'none',
                    padding: '0',
                    textAlign: 'center'
                },
                type: "text",
                value: quantity,
                readOnly: true
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(material_.Button, {
                sx: {
                    minWidth: {
                        xs: '14px',
                        md: '20px'
                    },
                    minHeight: {
                        xs: '14px',
                        md: '20px'
                    },
                    borderRadius: '50%',
                    border: '1px solid #E8E8E8',
                    '&:hover': {
                        border: '1px solid #49D6A3;',
                        background: 'rgba(73, 214, 163, 0.1);'
                    }
                },
                onClick: ()=>dispatch((0,cart/* quantityToCart */.nx)(product.databaseId, quantity))
                ,
                children: /*#__PURE__*/ jsx_runtime_.jsx(arrowRightSmall/* default */.Z, {})
            })
        ]
    }));
};
/* harmony default export */ const quantity_count = (QuantityCount);


/***/ }),

/***/ 4687:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const ArrowDown = ()=>{
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
        width: "15",
        height: "10",
        viewBox: "0 0 15 10",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
            d: "M7.03755 9.79769L0.208873 2.10206C-0.0357703 1.84953 -0.0357703 1.43998 0.208873 1.18745C0.453498 0.934914 0.850429 0.934914 1.09507 1.18745L7.51249 8.41906L13.9299 1.18809C14.1745 0.935555 14.5715 0.935555 14.8161 1.18809C15.0607 1.44062 15.0607 1.85017 14.8161 2.10268L7.98741 9.79833C7.85699 9.93292 7.6841 9.99063 7.51311 9.98164C7.34148 9.99001 7.16861 9.93232 7.03755 9.79769Z",
            fill: "#606060"
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ArrowDown);


/***/ }),

/***/ 6613:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Xq": () => (/* binding */ addToCart),
/* harmony export */   "h2": () => (/* binding */ removeFromCart),
/* harmony export */   "nx": () => (/* binding */ quantityToCart)
/* harmony export */ });
/* unused harmony export removeAllFromCart */
/* harmony import */ var redux_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9614);

const addToCart = (product, selectedId, selectedSize, quantity)=>({
        type: redux_types__WEBPACK_IMPORTED_MODULE_0__/* .ADD */ .D7,
        payload: {
            ...product,
            selectedId,
            selectedSize,
            quantity
        }
    })
;
const removeFromCart = (selectedId)=>({
        type: redux_types__WEBPACK_IMPORTED_MODULE_0__/* .REMOVE */ .Dq,
        payload: selectedId
    })
;
const removeAllFromCart = ()=>({
        type: REMOVE_ALL
    })
;
const quantityToCart = (selectedId, selectedQuantity)=>({
        type: redux_types__WEBPACK_IMPORTED_MODULE_0__/* .QUANTITY */ .uT,
        payload: {
            selectedId,
            selectedQuantity
        }
    })
;


/***/ }),

/***/ 9614:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "D7": () => (/* binding */ ADD),
/* harmony export */   "Dq": () => (/* binding */ REMOVE),
/* harmony export */   "Vo": () => (/* binding */ REMOVE_ALL),
/* harmony export */   "Cm": () => (/* binding */ ADD_TO_WISHLIST),
/* harmony export */   "Ji": () => (/* binding */ REMOVE_FROM_WISHLIST),
/* harmony export */   "uT": () => (/* binding */ QUANTITY),
/* harmony export */   "iu": () => (/* binding */ SUM)
/* harmony export */ });
/* unused harmony export DECREASE_QUANTITY */
const ADD = 'ADD';
const REMOVE = 'REMOVE';
const REMOVE_ALL = 'REMOVE_ALL';
const ADD_TO_WISHLIST = 'ADD_TO_WISHLIST';
const REMOVE_FROM_WISHLIST = 'REMOVE_FROM_WISHLIST';
const QUANTITY = 'QUANTITY';
const SUM = 'SUM';
const DECREASE_QUANTITY = 'DECREASE_QUANTITY';


/***/ }),

/***/ 740:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const FormatPrice = (price)=>price?.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ' ') + ' сум'
;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (FormatPrice);


/***/ })

};
;