"use strict";
exports.id = 701;
exports.ids = [701];
exports.modules = {

/***/ 2148:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const ArrowLeft = ()=>{
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
        width: "11",
        height: "16",
        viewBox: "0 0 11 16",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
            d: "M0.17041 7.6292C0.17041 7.36047 0.290457 7.09177 0.530046 6.88689L8.07322 0.439676C8.55305 0.0295482 9.33103 0.0295482 9.81068 0.439676C10.2903 0.849637 10.2903 1.51446 9.81068 1.92462L3.13606 7.6292L9.81044 13.3338C10.2901 13.7439 10.2901 14.4087 9.81044 14.8186C9.3308 15.2289 8.55282 15.2289 8.07298 14.8186L0.529814 8.3715C0.290185 8.16652 0.17041 7.89783 0.17041 7.6292Z",
            fill: "#1F3A8F"
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ArrowLeft);


/***/ }),

/***/ 4256:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const ArrowRight = ()=>{
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
        width: "11",
        height: "15",
        viewBox: "0 0 11 15",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
            d: "M10.9602 7.49727C10.9602 7.766 10.8402 8.03469 10.6006 8.23957L3.0574 14.6868C2.57756 15.0969 1.79958 15.0969 1.31994 14.6868C0.840294 14.2768 0.840294 13.612 1.31994 13.2018L7.99455 7.49727L1.32017 1.79265C0.840527 1.38252 0.840527 0.717773 1.32017 0.307845C1.79982 -0.102481 2.57779 -0.102481 3.05763 0.307845L10.6008 6.75496C10.8404 6.95994 10.9602 7.22864 10.9602 7.49727Z",
            fill: "#1F3A8F"
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ArrowRight);


/***/ }),

/***/ 9734:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "n": () => (/* binding */ sliderBanners)
/* harmony export */ });
const sliderBanners = [
    {
        id: 0,
        image: '/banners/Slider.png',
        mobImage: '/banners/SliderMob.png'
    },
    {
        id: 1,
        image: '/banners/Slider.png',
        mobImage: '/banners/SliderMob.png'
    }
];


/***/ })

};
;