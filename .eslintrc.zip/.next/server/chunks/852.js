"use strict";
exports.id = 852;
exports.ids = [852];
exports.modules = {

/***/ 852:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);



const OrderDetails = ()=>{
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
        sx: {
            border: '1px solid #E8E8E8',
            boxShadow: '0px 4px 40px rgba(0, 0, 0, 0.1)'
        },
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
                sx: {
                    padding: '16px',
                    borderBottom: '2px dashed #E8E8E8',
                    boxShadow: '0px 4px 40px rgba(0, 0, 0, 0.1)'
                },
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
                        sx: {
                            display: 'flex',
                            justifyContent: 'space-between',
                            marginBottom: '14px'
                        },
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                                sx: {
                                    fontSize: {
                                        xs: '13px',
                                        md: '17px'
                                    },
                                    fontWeight: 600,
                                    color: 'text.primary'
                                },
                                children: "ПОДЫТОГ:"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                                sx: {
                                    fontSize: {
                                        xs: '13px',
                                        md: '17px'
                                    },
                                    fontWeight: 600,
                                    color: 'text.primary'
                                },
                                children: "534 000 сум"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
                        sx: {
                            display: 'flex',
                            justifyContent: 'space-between',
                            marginBottom: '7px'
                        },
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                                sx: {
                                    fontSize: {
                                        xs: '13px',
                                        md: '17px'
                                    },
                                    fontWeight: 400,
                                    color: 'grey.main',
                                    fontStyle: 'italic'
                                },
                                children: "Кэшбэк:"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                                sx: {
                                    fontSize: {
                                        xs: '13px',
                                        md: '17px'
                                    },
                                    fontWeight: 400,
                                    color: 'grey.main',
                                    fontStyle: 'italic'
                                },
                                children: "-5 000 сум"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
                        sx: {
                            display: 'flex',
                            justifyContent: 'space-between',
                            marginBottom: '7px'
                        },
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                                sx: {
                                    fontSize: {
                                        xs: '13px',
                                        md: '17px'
                                    },
                                    fontWeight: 400,
                                    color: 'grey.main',
                                    fontStyle: 'italic'
                                },
                                children: "Скидка:"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                                sx: {
                                    fontSize: {
                                        xs: '13px',
                                        md: '17px'
                                    },
                                    fontWeight: 400,
                                    color: 'grey.main',
                                    fontStyle: 'italic'
                                },
                                children: "-66 785 сум"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
                        sx: {
                            display: 'flex',
                            justifyContent: 'space-between',
                            marginBottom: '7px'
                        },
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                                sx: {
                                    fontSize: {
                                        xs: '13px',
                                        md: '17px'
                                    },
                                    fontWeight: 400,
                                    color: 'grey.main',
                                    fontStyle: 'italic'
                                },
                                children: "Товаров:"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                                sx: {
                                    fontSize: {
                                        xs: '13px',
                                        md: '17px'
                                    },
                                    fontWeight: 400,
                                    color: 'grey.main',
                                    fontStyle: 'italic'
                                },
                                children: "2 шт"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
                        sx: {
                            display: 'flex',
                            justifyContent: 'space-between',
                            marginBottom: '7px'
                        },
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                                sx: {
                                    fontSize: {
                                        xs: '13px',
                                        md: '17px'
                                    },
                                    fontWeight: 400,
                                    color: 'grey.main',
                                    fontStyle: 'italic'
                                },
                                children: "Доставка:"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                                sx: {
                                    fontSize: {
                                        xs: '13px',
                                        md: '17px'
                                    },
                                    fontWeight: 400,
                                    color: 'grey.main',
                                    fontStyle: 'italic'
                                },
                                children: "+15 000 сум"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
                sx: {
                    padding: '16px',
                    boxShadow: '0px 4px 40px rgba(0, 0, 0, 0.1)'
                },
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
                        sx: {
                            display: 'flex',
                            justifyContent: 'space-between',
                            marginBottom: '7px'
                        },
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                                sx: {
                                    fontWeight: 700,
                                    fontSize: {
                                        xs: '13px',
                                        md: '18px'
                                    },
                                    color: 'text.primary'
                                },
                                children: "ИТОГО:"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                                sx: {
                                    fontWeight: 700,
                                    fontSize: {
                                        xs: '13px',
                                        md: '18px'
                                    },
                                    color: 'text.primary'
                                },
                                children: "482 215 сум"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
                        sx: {
                            display: 'flex',
                            justifyContent: 'space-between',
                            marginBottom: '7px'
                        },
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                                sx: {
                                    fontWeight: 400,
                                    fontSize: {
                                        xs: '13px',
                                        md: '18px'
                                    },
                                    color: 'btn.main',
                                    fontStyle: 'italic'
                                },
                                children: "Кэшбэк на карту:"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                                sx: {
                                    fontWeight: 400,
                                    fontSize: {
                                        xs: '13px',
                                        md: '18px'
                                    },
                                    color: 'btn.main',
                                    fontStyle: 'italic'
                                },
                                children: "+ 4 672 сум"
                            })
                        ]
                    })
                ]
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (OrderDetails);


/***/ })

};
;