"use strict";
exports.id = 889;
exports.ids = [889];
exports.modules = {

/***/ 9589:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "a": () => (/* binding */ CATEGORIES)
/* harmony export */ });
/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9114);
/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_apollo_client__WEBPACK_IMPORTED_MODULE_0__);

const CATEGORIES = _apollo_client__WEBPACK_IMPORTED_MODULE_0__.gql`
query MyQuery {
  productCategories(
  where: {
  hideEmpty: true,
  slug: ["detskaya-komnata", "dlya-mamy", "igrushki-i-igry", "knigi", "odezhda-i-obuv",
         "pitanie-i-kormlenie","progulki-i-puteshestviya","uhod-i-gigiena"]
   }) {
    nodes {
      databaseId
      name
      slug
      children(first: 100, where: {hideEmpty: true}) {
        nodes {
          databaseId
          name
          slug
          children(first: 100, where: {hideEmpty: true}) {
            nodes {
              databaseId
              name
              slug
            }
          }
        }
      }
    }
  }
}
`;


/***/ }),

/***/ 9271:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "b": () => (/* binding */ PRODUCTS)
/* harmony export */ });
/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9114);
/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_apollo_client__WEBPACK_IMPORTED_MODULE_0__);

const PRODUCTS = _apollo_client__WEBPACK_IMPORTED_MODULE_0__.gql`
query MyQuery(
    $first: Int
    $after: String
    $categories: [String]
    $filters: [ProductTaxonomyFilterInput]
    $onSale: Boolean
    $search: String
    $orderBy: [ProductsOrderbyInput]
  ) {
    products(
      first: $first
      after: $after
      where: {
        status: "publish"
        stockStatus: IN_STOCK
        onSale: $onSale
        categoryIn: $categories
        taxonomyFilter: { and: $filters }
        search: $search
        orderby: $orderBy
      }
    ) {
      pageInfo {
        endCursor
        hasNextPage
      }
      activeTerms {
        paColors {
          databaseId
          name
          slug
          color
        }
        paSizes {
          databaseId
          name
          slug
        }
        paBrands {
        name
        slug
        databaseId
      }
      }
      
      nodes {
        databaseId
        slug
        name
        onSale
        image {
          sourceUrl
        }
        ... on SimpleProduct {
          woocsRegularPrice
          woocsSalePrice
        }
        ... on VariableProduct {
          woocsRegularPrice
          woocsSalePrice
          variations(where: { stockStatus: IN_STOCK }) {
            nodes {
              size: attributes(where: { taxonomy: "pa_size" }) {
                nodes {
                  value
                }
              }
            }
          }
        }
      }
    }
  }

`;


/***/ })

};
;