"use strict";
(() => {
var exports = {};
exports.id = 908;
exports.ids = [908];
exports.modules = {

/***/ 9114:
/***/ ((module) => {

module.exports = require("@apollo/client");

/***/ }),

/***/ 825:
/***/ ((module) => {

module.exports = require("graphql-tag");

/***/ }),

/***/ 9344:
/***/ ((module) => {

module.exports = require("jsonwebtoken");

/***/ }),

/***/ 4511:
/***/ ((module) => {

module.exports = require("next-iron-session");

/***/ }),

/***/ 6555:
/***/ ((module) => {

module.exports = import("uuid");;

/***/ }),

/***/ 2495:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var uuid__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6555);
/* harmony import */ var jsonwebtoken__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9344);
/* harmony import */ var jsonwebtoken__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(jsonwebtoken__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _utility_session__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(453);
/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9528);
/* harmony import */ var _mutations_auth__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2651);
/* harmony import */ var _GRAPHQL_customer__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5289);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([uuid__WEBPACK_IMPORTED_MODULE_0__]);
uuid__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];






/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,_utility_session__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z)(async (req, res)=>{
    const { phone , otp  } = req.body;
    try {
        const otpResult = await _apollo_client__WEBPACK_IMPORTED_MODULE_3__/* .client.query */ .L.query({
            query: _mutations_auth__WEBPACK_IMPORTED_MODULE_4__/* .OTP_AUTH */ .$H,
            fetchPolicy: "no-cache",
            variables: {
                mutationId: (0,uuid__WEBPACK_IMPORTED_MODULE_0__.v4)(),
                phone,
                otp
            }
        });
        const { authToken , refreshToken  } = otpResult.data.login;
        const decoded = jsonwebtoken__WEBPACK_IMPORTED_MODULE_1___default().decode(authToken);
        const userResult = await _apollo_client__WEBPACK_IMPORTED_MODULE_3__/* .client.query */ .L.query({
            query: _GRAPHQL_customer__WEBPACK_IMPORTED_MODULE_5__/* .CUSTOMER */ .cJ,
            fetchPolicy: "no-cache",
            variables: {
                customerId: parseInt(decoded.data.user.id)
            }
        });
        const userData = {
            user: userResult.data.customer,
            isLoggedIn: true
        };
        req.session.set("user", {
            ...userData,
            refreshToken,
            authToken
        });
        await req.session.save();
        delete userData.user.id;
        res.json({
            status: true,
            userData
        });
    } catch (error) {
        console.log("L41 error.graphQLErrors:", error.graphQLErrors);
        console.log("L42 error.networkError:", error.networkError);
        console.log("L43 error.extraInfo:", error.extraInfo);
        console.log("L44 error.message:", error.message);
        const translatedErrorMessages = {
            "GraphQL error: invalid otp": "Неверный код"
        };
        res.json({
            status: false,
            message: translatedErrorMessages[error.message] || error.message
        });
    }
}));

});

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [293,289], () => (__webpack_exec__(2495)));
module.exports = __webpack_exports__;

})();