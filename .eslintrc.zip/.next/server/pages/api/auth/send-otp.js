"use strict";
(() => {
var exports = {};
exports.id = 698;
exports.ids = [698];
exports.modules = {

/***/ 9114:
/***/ ((module) => {

module.exports = require("@apollo/client");

/***/ }),

/***/ 825:
/***/ ((module) => {

module.exports = require("graphql-tag");

/***/ }),

/***/ 4511:
/***/ ((module) => {

module.exports = require("next-iron-session");

/***/ }),

/***/ 6555:
/***/ ((module) => {

module.exports = import("uuid");;

/***/ }),

/***/ 1898:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var uuid__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6555);
/* harmony import */ var _utility_session__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(453);
/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9528);
/* harmony import */ var _mutations_auth__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2651);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([uuid__WEBPACK_IMPORTED_MODULE_0__]);
uuid__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];




/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,_utility_session__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z)(async (req, res)=>{
    const { phone , firstName , lastName  } = req.body;
    await _apollo_client__WEBPACK_IMPORTED_MODULE_2__/* .client.query */ .L.query({
        query: firstName ? _mutations_auth__WEBPACK_IMPORTED_MODULE_3__/* .SIGN_UP_SEND_OTP */ .I2 : _mutations_auth__WEBPACK_IMPORTED_MODULE_3__/* .LOGIN_SEND_OTP */ .qs,
        fetchPolicy: "no-cache",
        variables: {
            mutationId: (0,uuid__WEBPACK_IMPORTED_MODULE_0__.v4)(),
            phone,
            ...firstName ? {
                firstName
            } : {}
        }
    });
    res.statusCode = 200;
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify({
        status: true
    }));
}));

});

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [293], () => (__webpack_exec__(1898)));
module.exports = __webpack_exports__;

})();