"use strict";
(() => {
var exports = {};
exports.id = 873;
exports.ids = [873];
exports.modules = {

/***/ 9114:
/***/ ((module) => {

module.exports = require("@apollo/client");

/***/ }),

/***/ 825:
/***/ ((module) => {

module.exports = require("graphql-tag");

/***/ }),

/***/ 9344:
/***/ ((module) => {

module.exports = require("jsonwebtoken");

/***/ }),

/***/ 4511:
/***/ ((module) => {

module.exports = require("next-iron-session");

/***/ }),

/***/ 6555:
/***/ ((module) => {

module.exports = import("uuid");;

/***/ }),

/***/ 3151:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _utility_session__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(453);
/* harmony import */ var _utility_checkSession__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(287);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utility_checkSession__WEBPACK_IMPORTED_MODULE_1__]);
_utility_checkSession__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,_utility_session__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)(async (req, res)=>{
    const user = await (0,_utility_checkSession__WEBPACK_IMPORTED_MODULE_1__/* .checkSession */ .b)(req.session.get('user'), req);
    if (user.isLoggedIn) {
        delete user.authToken;
        delete user.refreshToken;
        delete user.user.id;
        res.json({
            isLoggedIn: true,
            ...user
        });
    } else {
        res.json({
            isLoggedIn: false
        });
    }
}));

});

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [293,287], () => (__webpack_exec__(3151)));
module.exports = __webpack_exports__;

})();