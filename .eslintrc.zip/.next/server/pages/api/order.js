"use strict";
(() => {
var exports = {};
exports.id = 626;
exports.ids = [626];
exports.modules = {

/***/ 1602:
/***/ ((module) => {


module.exports = {
    reactStrictMode: true,
    images: {
        domains: [
            'kids-planet.billz.work'
        ]
    },
    env: {
        WP_URL: 'https://kids-planet.billz.work',
        GRAPHQL: 'https://kids-planet.billz.work/graphql',
        CONSUMER_KEY: 'ck_ed4f0d99e580b886ac7582d4112b2d46cda896f5',
        CONSUMER_SECRET: 'cs_4827030eb0fef53488e5b2b778cc9821440ccec1',
        WP_TOKEN: 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJodHRwczovL2tpZHMtcGxhbmV0LmJpbGx6LndvcmsiLCJpYXQiOjE2MDQ2NjMwMDUsIm5iZiI6MTYwNDY2MzAwNSwiZXhwIjoxNzYyNDI5NDIwLCJkYXRhIjp7InVzZXIiOnsiaWQiOiIxIn19fQ.EfOdjLOAu78KDqvIdwTzhYJABoHXtXQPUzat26dx_Dk'
    }
};


/***/ }),

/***/ 9786:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ order)
});

;// CONCATENATED MODULE: external "@woocommerce/woocommerce-rest-api"
const woocommerce_rest_api_namespaceObject = require("@woocommerce/woocommerce-rest-api");
var woocommerce_rest_api_default = /*#__PURE__*/__webpack_require__.n(woocommerce_rest_api_namespaceObject);
// EXTERNAL MODULE: ./next.config.js
var next_config = __webpack_require__(1602);
;// CONCATENATED MODULE: ./pages/api/order.js


const wc = new (woocommerce_rest_api_default())({
    url: next_config.WP_URL,
    consumerKey: next_config.CONSUMER_KEY,
    consumerSecret: next_config.CONSUMER_SECRET,
    version: 'wc/v3'
});
/* harmony default export */ const order = (async (req, res)=>{
    if (req.method === 'POST') {
        const { order  } = req.body;
        console.log(order);
        let response;
        try {
            response = await wc.post('orders', order);
        } catch (e) {
            res.end(JSON.stringify({
                status: false,
                message: e.message
            }));
            // console.log(e.response.data)
            return;
        }
        res.statusCode = 200;
        res.setHeader('Content-Type', 'application/json');
        res.end(JSON.stringify({
            status: true,
            order: response.data
        }));
    } else {
        res.setHeader('Allow', [
            'POST'
        ]);
        res.statusCode = 404;
        res.end();
    }
});


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(9786));
module.exports = __webpack_exports__;

})();