"use strict";
(() => {
var exports = {};
exports.id = 146;
exports.ids = [146];
exports.modules = {

/***/ 9114:
/***/ ((module) => {

module.exports = require("@apollo/client");

/***/ }),

/***/ 825:
/***/ ((module) => {

module.exports = require("graphql-tag");

/***/ }),

/***/ 9344:
/***/ ((module) => {

module.exports = require("jsonwebtoken");

/***/ }),

/***/ 4511:
/***/ ((module) => {

module.exports = require("next-iron-session");

/***/ }),

/***/ 6555:
/***/ ((module) => {

module.exports = import("uuid");;

/***/ }),

/***/ 413:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "W": () => (/* binding */ UPDATE_CUSTOMER)
/* harmony export */ });
/* harmony import */ var graphql_tag__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(825);
/* harmony import */ var graphql_tag__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(graphql_tag__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _GRAPHQL_customer__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5289);


const UPDATE_CUSTOMER = (graphql_tag__WEBPACK_IMPORTED_MODULE_0___default())`
mutation UpdateCustomer($mutationId: String!, $id: ID!, $firstName: String, $lastName: String, $country: CountriesEnum, $city: String, $address: String, $phone: String, $email: String) {
  updateCustomer(input: {clientMutationId: $mutationId, id: $id, firstName: $firstName, lastName: $lastName, email: $email, billing: {phone: $phone, address1: $address, city: $city, country: $country}}) {
    customer {
      ..._Customer
    }
  }
}
${_GRAPHQL_customer__WEBPACK_IMPORTED_MODULE_1__/* .CustomerFragment */ .eD}
`;


/***/ }),

/***/ 7603:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var uuid__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6555);
/* harmony import */ var _utility_session__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(453);
/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9528);
/* harmony import */ var _GRAPHQL_customer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5289);
/* harmony import */ var _mutations_customer__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(413);
/* harmony import */ var _utility_checkSession__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(287);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([uuid__WEBPACK_IMPORTED_MODULE_0__, _utility_checkSession__WEBPACK_IMPORTED_MODULE_5__]);
([uuid__WEBPACK_IMPORTED_MODULE_0__, _utility_checkSession__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);






/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,_utility_session__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z)(async (req, res)=>{
    let userData = await (0,_utility_checkSession__WEBPACK_IMPORTED_MODULE_5__/* .checkSession */ .b)(req.session.get("user"), req);
    if (userData == null || !userData.isLoggedIn) {
        return res.json({
            isLoggedIn: false
        });
    }
    const { firstName , lastName , phone , email , country , city , address  } = req.body;
    try {
        const _userResult = await _apollo_client__WEBPACK_IMPORTED_MODULE_2__/* .client.query */ .L.query({
            query: _mutations_customer__WEBPACK_IMPORTED_MODULE_4__/* .UPDATE_CUSTOMER */ .W,
            fetchPolicy: "no-cache",
            context: {
                customerToken: userData.authToken
            },
            variables: {
                mutationId: (0,uuid__WEBPACK_IMPORTED_MODULE_0__.v4)(),
                id: userData.user.id,
                firstName,
                lastName,
                phone,
                email,
                city,
                address
            }
        });
        const newUserData = {
            ...userData,
            isLoggedIn: true,
            user: _userResult.data.updateCustomer.customer
        };
        req.session.set('user', newUserData);
        await req.session.save();
        delete newUserData.user.id;
        delete newUserData.refreshToken;
        delete newUserData.authToken;
        return res.json(newUserData);
    } catch (e) {
        console.log('l53', e);
        return res.json({});
    }
}));

});

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [293,289,287], () => (__webpack_exec__(7603)));
module.exports = __webpack_exports__;

})();