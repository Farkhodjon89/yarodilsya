"use strict";
(() => {
var exports = {};
exports.id = 307;
exports.ids = [307];
exports.modules = {

/***/ 9114:
/***/ ((module) => {

module.exports = require("@apollo/client");

/***/ }),

/***/ 825:
/***/ ((module) => {

module.exports = require("graphql-tag");

/***/ }),

/***/ 9344:
/***/ ((module) => {

module.exports = require("jsonwebtoken");

/***/ }),

/***/ 4511:
/***/ ((module) => {

module.exports = require("next-iron-session");

/***/ }),

/***/ 6555:
/***/ ((module) => {

module.exports = import("uuid");;

/***/ }),

/***/ 8835:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _utility_session__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(453);
/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9528);
/* harmony import */ var _utility__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5351);
/* harmony import */ var _GRAPHQL_customer__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5289);
/* harmony import */ var _utility_checkSession__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(287);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utility_checkSession__WEBPACK_IMPORTED_MODULE_3__]);
_utility_checkSession__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];





/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,_utility_session__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)(async (req, res)=>{
    const userData = await (0,_utility_checkSession__WEBPACK_IMPORTED_MODULE_3__/* .checkSession */ .b)(req.session.get("user"), req);
    const { first  } = req.body;
    if (!userData.isLoggedIn) {
        res.json({
            status: false
        });
        return;
    }
    const response = await _apollo_client__WEBPACK_IMPORTED_MODULE_1__/* .client.query */ .L.query({
        query: _GRAPHQL_customer__WEBPACK_IMPORTED_MODULE_2__/* .CUSTOMER_ORDERS */ .u3,
        fetchPolicy: "no-cache",
        context: {
            customerToken: userData.authToken
        },
        variables: {
            customerId: userData.user.databaseId
        }
    });
    let orders = response.data.orders.nodes.map(_utility__WEBPACK_IMPORTED_MODULE_4__/* .formatOrder */ .iV);
    if (first) {
        orders = orders.slice(0, first);
    }
    res.json({
        status: true,
        orders
    });
}));

});

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [293,289,287,351], () => (__webpack_exec__(8835)));
module.exports = __webpack_exports__;

})();