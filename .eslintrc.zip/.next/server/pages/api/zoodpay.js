"use strict";
(() => {
var exports = {};
exports.id = 781;
exports.ids = [781];
exports.modules = {

/***/ 1869:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ zoodpay)
});

;// CONCATENATED MODULE: external "axios"
const external_axios_namespaceObject = require("axios");
var external_axios_default = /*#__PURE__*/__webpack_require__.n(external_axios_namespaceObject);
;// CONCATENATED MODULE: ./pages/api/zoodpay.js

/* harmony default export */ const zoodpay = (async (req, res)=>{
    if (req.method === 'POST') {
        const { data  } = req.body;
        let response;
        try {
            response = await external_axios_default().post('https://sandbox-api.zoodpay.com/v0/transactions', data, {
                auth: {
                    username: 'B!LLZ_W@rk',
                    password: 'Q4n3f})pUJ~#.3X{'
                }
            });
        } catch (e) {
            res.end(JSON.stringify({
                status: false,
                message: e.message
            }));
            return;
        }
        res.statusCode = 200;
        res.setHeader('Content-Type', 'application/json');
        res.end(JSON.stringify({
            status: true,
            data: response.data
        }));
    } else {
        res.setHeader('Allow', [
            'POST'
        ]);
        res.statusCode = 404;
        res.end();
    }
});


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(1869));
module.exports = __webpack_exports__;

})();