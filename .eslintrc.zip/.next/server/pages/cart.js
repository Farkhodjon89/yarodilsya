"use strict";
(() => {
var exports = {};
exports.id = 190;
exports.ids = [190];
exports.modules = {

/***/ 9674:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);


const Empty = ({ title =''  })=>{
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
        sx: {
            border: 1,
            borderRadius: 1,
            textAlign: 'center',
            py: {
                xs: 8,
                md: 16
            },
            my: 4
        },
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
            variant: "h6",
            children: [
                " ",
                title
            ]
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Empty);


/***/ }),

/***/ 7972:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Cart),
  "getStaticProps": () => (/* binding */ getStaticProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./components/Layout/layout.js + 22 modules
var layout = __webpack_require__(4829);
// EXTERNAL MODULE: ./components/Breadcrumbs/breadcrumbs.js
var Breadcrumbs_breadcrumbs = __webpack_require__(741);
// EXTERNAL MODULE: ./components/SectionTitle/section-title.js
var section_title = __webpack_require__(2161);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(5692);
// EXTERNAL MODULE: ./components/QuantityCount/quantity-count.js + 1 modules
var quantity_count = __webpack_require__(7863);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
// EXTERNAL MODULE: ./utility/FormatPrice.js
var FormatPrice = __webpack_require__(740);
;// CONCATENATED MODULE: ./public/icons/Garbage.js


const Garbage = ()=>{
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
        width: "13",
        height: "17",
        viewBox: "0 0 13 17",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                d: "M9.64283 6.73658C9.3795 6.71318 9.14734 6.91104 9.1243 7.17848L8.45406 14.959C8.43102 15.2265 8.62583 15.4623 8.88916 15.4857C9.15249 15.5091 9.38466 15.3112 9.4077 15.0438L10.0779 7.26322C10.101 6.99577 9.90616 6.75998 9.64283 6.73658Z",
                fill: "#AAAAAA"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                d: "M6.77747 6.72717C6.51313 6.72717 6.29883 6.94482 6.29883 7.21329V15.0236C6.29883 15.292 6.51313 15.5097 6.77747 15.5097C7.0418 15.5097 7.25611 15.292 7.25611 15.0236V7.21329C7.25611 6.94482 7.0418 6.72717 6.77747 6.72717Z",
                fill: "#AAAAAA"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                d: "M4.03932 6.7495C3.77599 6.7729 3.58118 7.00869 3.60422 7.27614L4.27445 15.0567C4.29749 15.3241 4.52966 15.522 4.79299 15.4986C5.05632 15.4752 5.25113 15.2394 5.22809 14.972L4.55785 7.1914C4.53481 6.92396 4.30265 6.7261 4.03932 6.7495Z",
                fill: "#AAAAAA"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                d: "M11.5634 2.3841H9.17018V1.86558C9.17018 1.06144 8.52603 0.407227 7.73427 0.407227H5.81971C5.02795 0.407227 4.3838 1.06144 4.3838 1.86558V2.3841H1.9906C1.19884 2.3841 0.554688 3.03832 0.554688 3.84246V4.81469C0.554688 5.08316 0.76899 5.30081 1.03333 5.30081H1.55006L2.39773 15.6628C2.45929 16.4126 3.08784 17 3.8287 17H9.72528C10.4661 17 11.0947 16.4126 11.1562 15.6627L12.0039 5.30081H12.5207C12.785 5.30081 12.9993 5.08316 12.9993 4.81469V3.84246C12.9993 3.03832 12.3551 2.3841 11.5634 2.3841ZM5.34107 1.86558C5.34107 1.59753 5.55579 1.37946 5.81971 1.37946H7.73427C7.99819 1.37946 8.21291 1.59753 8.21291 1.86558V2.3841H5.34107V1.86558ZM10.2023 15.582C10.1817 15.832 9.97222 16.0278 9.72528 16.0278H3.8287C3.58176 16.0278 3.37221 15.832 3.35172 15.5822L2.51066 5.30081H11.0433L10.2023 15.582ZM12.042 4.32857H1.51196V3.84246C1.51196 3.57441 1.72668 3.35634 1.9906 3.35634H11.5634C11.8273 3.35634 12.042 3.57441 12.042 3.84246V4.32857Z",
                fill: "#AAAAAA"
            })
        ]
    }));
};
/* harmony default export */ const icons_Garbage = (Garbage);

// EXTERNAL MODULE: ./components/OrderDetails/order-details.js
var order_details = __webpack_require__(852);
// EXTERNAL MODULE: ./public/icons/arrowDown.js
var arrowDown = __webpack_require__(4687);
;// CONCATENATED MODULE: ./components/AccordionPromoCode/accordion-promo-code.js




const AccordionPromoCode = ()=>{
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Accordion, {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.AccordionSummary, {
                        expandIcon: /*#__PURE__*/ jsx_runtime_.jsx(arrowDown/* default */.Z, {}),
                        "aria-controls": "panel1a-content",
                        id: "panel1a-header",
                        sx: {
                            height: '55px'
                        },
                        children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                            sx: {
                                fontWeight: 600,
                                fontSize: {
                                    xs: '13px',
                                    md: '17px'
                                },
                                color: 'btn.main'
                            },
                            children: "Промокод"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.AccordionDetails, {
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                            sx: {
                                width: 'inherit',
                                display: 'flex',
                                justifyContent: 'space-between'
                            },
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                                    sx: {
                                        width: '65%'
                                    },
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(material_.TextField, {
                                        id: "name",
                                        label: "Введите № купона",
                                        required: true,
                                        fullWidth: true
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                                    sx: {
                                        width: '30%'
                                    },
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Button, {
                                        variant: "contained",
                                        sx: {
                                            height: '50px',
                                            borderRadius: '8px',
                                            backgroundColor: 'btn.main',
                                            fontSize: '14px',
                                            fontWeight: 400,
                                            textTransform: 'capitalize'
                                        },
                                        children: "Применить"
                                    })
                                })
                            ]
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Accordion, {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.AccordionSummary, {
                        expandIcon: /*#__PURE__*/ jsx_runtime_.jsx(arrowDown/* default */.Z, {}),
                        "aria-controls": "panel1a-content",
                        id: "panel1a-header",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                            sx: {
                                fontWeight: 600,
                                fontSize: {
                                    xs: '13px',
                                    md: '17px'
                                },
                                color: 'btn.main'
                            },
                            children: "Оплатить часть суммы кэшбэком"
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.AccordionDetails, {
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                                sx: {
                                    width: 'inherit',
                                    display: 'flex',
                                    justifyContent: 'space-between'
                                },
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                                        sx: {
                                            width: '65%'
                                        },
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(material_.TextField, {
                                            id: "name",
                                            label: "Введите сумму",
                                            required: true,
                                            fullWidth: true
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                                        sx: {
                                            width: '30%'
                                        },
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Button, {
                                            variant: "contained",
                                            sx: {
                                                height: '50px',
                                                borderRadius: '8px',
                                                backgroundColor: 'btn.main',
                                                fontSize: '14px',
                                                fontWeight: 400,
                                                textTransform: 'capitalize'
                                            },
                                            children: "Применить"
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                sx: {
                                    fontWeight: 400,
                                    lineHeight: '19px',
                                    fontSize: '14px',
                                    color: 'grey.main'
                                },
                                children: "Оплатить можно не более 50% от стоимости товара"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(material_.Paper, {
                                sx: {
                                    background: 'linear-gradient(90.01deg, #EA56AE 16.09%, #1F3A8F 84.36%);',
                                    maxWidth: {
                                        xs: '100%',
                                        md: '230px'
                                    },
                                    height: '40px',
                                    borderRadius: '8px',
                                    display: 'flex',
                                    justifyContent: 'center',
                                    alignItems: 'center',
                                    cursor: 'pointer',
                                    margin: '15px 0'
                                },
                                square: true,
                                children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                    sx: {
                                        color: 'white.main',
                                        fontSize: '14px',
                                        fontWeight: 500
                                    },
                                    children: "Баланс кэшбэка: 1 000 000 сум"
                                })
                            })
                        ]
                    })
                ]
            })
        ]
    }));
};
/* harmony default export */ const accordion_promo_code = (AccordionPromoCode);

// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(6022);
;// CONCATENATED MODULE: ./components/CartMain/cart-main.js











const CartMain = ({ products =[] , remove  })=>{
    const matches = (0,material_.useMediaQuery)('(max-width: 600px)');
    const { 0: quantity , 1: setQuantity  } = (0,external_react_.useState)(1);
    const dispatch = (0,external_react_redux_.useDispatch)();
    const productsInfo = [
        {
            id: 0,
            name: 'МОДЕЛЬ'
        },
        {
            id: 1,
            name: 'НАИМЕНОВАНИЕ'
        },
        {
            id: 2,
            name: 'РАЗМЕР'
        },
        {
            id: 3,
            name: 'ЦЕНА'
        },
        {
            id: 4,
            name: 'КОЛИЧЕСТВО'
        },
        {
            id: 5,
            name: 'ИТОГО'
        }, 
    ];
    const productsInfoMoB = [
        {
            id: 0,
            name: 'МОДЕЛЬ'
        },
        {
            id: 1,
            name: 'НАИМЕНОВАНИЕ'
        },
        {
            id: 2,
            name: 'ЦЕНА'
        }, 
    ];
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
        sx: {
            display: 'flex',
            justifyContent: 'space-between',
            flexDirection: {
                xs: 'column',
                md: 'row'
            },
            marginBottom: '50px'
        },
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                sx: {
                    width: {
                        xs: '100%',
                        md: '65%'
                    },
                    marginBottom: {
                        xs: '30px',
                        md: '0'
                    }
                },
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
                        container: true,
                        spacing: 0,
                        sx: {
                            cursor: 'pointer'
                        },
                        children: !matches ? productsInfo.map(({ id , name  })=>/*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
                                item: true,
                                xs: 4,
                                md: 2,
                                children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                    sx: {
                                        fontWeight: 600,
                                        fontSize: {
                                            xs: '10px',
                                            md: '13px'
                                        },
                                        color: 'text.primary',
                                        padding: '5px 0',
                                        borderBottom: ' 1px solid #E8E8E8'
                                    },
                                    children: name
                                })
                            }, id)
                        ) : productsInfoMoB.map(({ id , name  })=>/*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
                                item: true,
                                xs: 4,
                                md: 2,
                                children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                    sx: {
                                        fontWeight: 600,
                                        fontSize: {
                                            xs: '10px',
                                            md: '13px'
                                        },
                                        color: 'text.primary',
                                        padding: '5px 0',
                                        borderBottom: ' 1px solid #E8E8E8'
                                    },
                                    children: name
                                })
                            }, id)
                        )
                    }),
                    products.map(({ id , image , name , databaseId , woocsRegularPrice , size  }, index)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Grid, {
                            sx: {
                                cursor: 'pointer'
                            },
                            container: true,
                            spacing: 0,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
                                    item: true,
                                    xs: 4,
                                    md: 2,
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                                                sx: {
                                                    padding: '10px 0'
                                                },
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                                                    alt: "",
                                                    src: image.sourceUrl,
                                                    width: 90,
                                                    height: 110
                                                })
                                            }),
                                            matches ? /*#__PURE__*/ jsx_runtime_.jsx(quantity_count/* default */.Z, {
                                                quantity: quantity,
                                                setQuantity: setQuantity
                                            }) : ''
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
                                    item: true,
                                    xs: 4,
                                    md: 2,
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                                sx: {
                                                    padding: '10px 0',
                                                    fontWeight: 400,
                                                    fontSize: {
                                                        xs: '12px',
                                                        md: '16px'
                                                    },
                                                    color: 'grey.main'
                                                },
                                                children: name
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                                                sx: {
                                                    display: 'flex',
                                                    alignItems: 'center'
                                                },
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                                        sx: {
                                                            fontWeight: 400,
                                                            display: {
                                                                xs: 'block',
                                                                md: 'none'
                                                            },
                                                            fontSize: {
                                                                xs: '12px',
                                                                md: '16px'
                                                            },
                                                            color: 'grey.main'
                                                        },
                                                        children: "Цвет:"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                                        sx: {
                                                            display: {
                                                                xs: 'block',
                                                                md: 'none'
                                                            },
                                                            fontWeight: 400,
                                                            fontSize: '11px',
                                                            color: 'text.primary'
                                                        },
                                                        children: "Красный"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                                                sx: {
                                                    display: 'flex',
                                                    alignItems: 'center'
                                                },
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                                        sx: {
                                                            fontWeight: 400,
                                                            display: {
                                                                xs: 'block',
                                                                md: 'none'
                                                            },
                                                            fontSize: {
                                                                xs: '12px',
                                                                md: '16px'
                                                            },
                                                            color: 'grey.main'
                                                        },
                                                        children: "РАЗМЕР:"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                                        sx: {
                                                            display: {
                                                                xs: 'block',
                                                                md: 'none'
                                                            },
                                                            fontWeight: 400,
                                                            fontSize: '11px',
                                                            color: 'text.primary'
                                                        },
                                                        children: "9-12 мес"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                                                sx: {
                                                    display: 'flex',
                                                    alignItems: 'center'
                                                },
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                                        sx: {
                                                            fontWeight: 600,
                                                            display: {
                                                                xs: 'block',
                                                                md: 'none'
                                                            },
                                                            fontSize: {
                                                                xs: '12px',
                                                                md: '16px'
                                                            },
                                                            color: 'text.primary'
                                                        },
                                                        children: "ИТОГО:"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                                        sx: {
                                                            display: {
                                                                xs: 'block',
                                                                md: 'none'
                                                            },
                                                            fontWeight: 600,
                                                            fontSize: '11px',
                                                            color: 'text.primary'
                                                        },
                                                        children: "200 215 сум"
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
                                    item: true,
                                    xs: 2,
                                    sx: {
                                        display: {
                                            xs: 'none',
                                            md: 'block'
                                        }
                                    },
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                            sx: {
                                                padding: '10px 0',
                                                fontWeight: 400,
                                                fontSize: {
                                                    xs: '12px',
                                                    md: '16px'
                                                },
                                                color: 'grey.main'
                                            },
                                            children: size
                                        })
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
                                    item: true,
                                    xs: 4,
                                    md: 2,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                            sx: {
                                                padding: '10px 0',
                                                fontWeight: 400,
                                                fontSize: {
                                                    xs: '12px',
                                                    md: '16px'
                                                },
                                                color: 'grey.main'
                                            },
                                            children: (0,FormatPrice/* default */.Z)(woocsRegularPrice)
                                        })
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
                                    item: true,
                                    xs: 2,
                                    sx: {
                                        display: {
                                            xs: 'none',
                                            md: 'block'
                                        }
                                    },
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                                            sx: {
                                                padding: '10px 0'
                                            },
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(quantity_count/* default */.Z, {
                                                quantity: quantity,
                                                setQuantity: setQuantity
                                            })
                                        })
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
                                    item: true,
                                    xs: 2,
                                    sx: {
                                        display: {
                                            xs: 'none',
                                            md: 'block'
                                        }
                                    },
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                                        sx: {
                                            display: 'flex'
                                        },
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                                                sx: {
                                                    display: {
                                                        xs: 'none',
                                                        md: 'block'
                                                    }
                                                },
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                                    sx: {
                                                        padding: '10px 0',
                                                        fontWeight: 600,
                                                        fontSize: '18px',
                                                        color: 'text.primary'
                                                    },
                                                    children: (0,FormatPrice/* default */.Z)(woocsRegularPrice)
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                                                onClick: ()=>dispatch(remove(databaseId))
                                                ,
                                                sx: {
                                                    padding: '15px 0',
                                                    marginLeft: '20px',
                                                    display: {
                                                        xs: 'none',
                                                        md: 'block'
                                                    }
                                                },
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(icons_Garbage, {})
                                            })
                                        ]
                                    })
                                })
                            ]
                        }, id)
                    )
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                sx: {
                    width: {
                        xs: '100%',
                        md: '33%'
                    }
                },
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                        sx: {
                            width: '100%'
                        },
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(accordion_promo_code, {}),
                            /*#__PURE__*/ jsx_runtime_.jsx(order_details/* default */.Z, {})
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                        sx: {
                            textAlign: 'center',
                            marginTop: '20px'
                        },
                        children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                            href: "/checkout",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Button, {
                                    variant: "contained",
                                    sx: {
                                        fontSize: {
                                            xs: '13px',
                                            md: '18px'
                                        },
                                        width: '300px',
                                        height: '50px',
                                        borderRadius: '8px'
                                    },
                                    children: "ОФОРМИТЬ ЗАКАЗ"
                                })
                            })
                        })
                    })
                ]
            })
        ]
    }));
};
/* harmony default export */ const cart_main = (CartMain);

// EXTERNAL MODULE: ./apollo-client.js
var apollo_client = __webpack_require__(9999);
// EXTERNAL MODULE: ./GRAPHQL/products.js
var products = __webpack_require__(9271);
// EXTERNAL MODULE: ./GRAPHQL/categories.js
var GRAPHQL_categories = __webpack_require__(9589);
// EXTERNAL MODULE: ./components/Empty/empty.js
var empty = __webpack_require__(9674);
// EXTERNAL MODULE: ./redux/actions/cart.js
var actions_cart = __webpack_require__(6613);
;// CONCATENATED MODULE: ./pages/cart.js












function Cart({ products , categories  }) {
    const breadcrumbs = [
        {
            name: 'Главная',
            slug: '/'
        },
        {
            name: 'Корзина',
            slug: `/cart`
        }, 
    ];
    const cart = (0,external_react_redux_.useSelector)((state)=>state.cart
    );
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(layout/* default */.Z, {
        categories: categories,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(Breadcrumbs_breadcrumbs/* default */.Z, {
                breadcrumbs: breadcrumbs
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(section_title/* default */.Z, {
                title: "Корзина"
            }),
            cart.length ? /*#__PURE__*/ jsx_runtime_.jsx(cart_main, {
                products: cart,
                remove: actions_cart/* removeFromCart */.h2
            }) : /*#__PURE__*/ jsx_runtime_.jsx(empty/* default */.Z, {
                title: "Нет товаров в корзине"
            })
        ]
    }));
};
;
async function getStaticProps() {
    const categories = await apollo_client/* client.query */.L.query({
        query: GRAPHQL_categories/* CATEGORIES */.a
    });
    // const products = await client.query({
    //   query: PRODUCTS,
    //   variables: {
    //     first: 12
    //   }
    // })
    return {
        props: {
            // products: products?.data?.products?.nodes,
            categories: categories?.data?.productCategories?.nodes
        }
    };
}


/***/ }),

/***/ 9114:
/***/ ((module) => {

module.exports = require("@apollo/client");

/***/ }),

/***/ 5692:
/***/ ((module) => {

module.exports = require("@mui/material");

/***/ }),

/***/ 9868:
/***/ ((module) => {

module.exports = require("@mui/material/useMediaQuery");

/***/ }),

/***/ 562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 8028:
/***/ ((module) => {

module.exports = require("next/dist/server/image-config.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 4365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 3018:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/to-base-64.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 6022:
/***/ ((module) => {

module.exports = require("react-redux");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [730,61,278,925,667,889,852], () => (__webpack_exec__(7972)));
module.exports = __webpack_exports__;

})();