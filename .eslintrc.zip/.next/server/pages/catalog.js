"use strict";
(() => {
var exports = {};
exports.id = 65;
exports.ids = [65];
exports.modules = {

/***/ 3505:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Catalog),
  "getStaticProps": () => (/* binding */ getStaticProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "@apollo/client"
var client_ = __webpack_require__(9114);
// EXTERNAL MODULE: ./hooks/useFirstRender.js
var useFirstRender = __webpack_require__(2481);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: external "react-infinite-scroller"
var external_react_infinite_scroller_ = __webpack_require__(5030);
var external_react_infinite_scroller_default = /*#__PURE__*/__webpack_require__.n(external_react_infinite_scroller_);
// EXTERNAL MODULE: ./components/Breadcrumbs/breadcrumbs.js
var Breadcrumbs_breadcrumbs = __webpack_require__(741);
// EXTERNAL MODULE: ./components/Empty/empty.js
var empty = __webpack_require__(9674);
// EXTERNAL MODULE: ./components/SectionTitle/section-title.js
var section_title = __webpack_require__(2161);
// EXTERNAL MODULE: ./components/ProductsList/index.js
var ProductsList = __webpack_require__(9296);
// EXTERNAL MODULE: ./apollo-client.js
var apollo_client = __webpack_require__(9999);
// EXTERNAL MODULE: ./GRAPHQL/categories.js
var GRAPHQL_categories = __webpack_require__(9589);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(5692);
;// CONCATENATED MODULE: ./components/ProductsList/Skeleton.js



const Skeleton = ()=>{
    const router = (0,router_.useRouter)();
    return(/*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
        container: true,
        spacing: {
            xs: 2,
            md: 4
        },
        sx: {
            mb: 4
        },
        children: Array.from(new Array(6)).map((product, index)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Grid, {
                item: true,
                xs: 6,
                md: 4,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Skeleton, {
                        variant: "rectangular",
                        sx: {
                            height: {
                                xs: '220px',
                                md: router.pathname === '/' ? '460px' : '330px'
                            },
                            mb: 2
                        }
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Skeleton, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Skeleton, {
                        sx: {
                            my: 1
                        }
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Skeleton, {})
                ]
            }, index)
        )
    }));
};
/* harmony default export */ const ProductsList_Skeleton = (Skeleton);

// EXTERNAL MODULE: ./components/CatalogActions/index.js + 11 modules
var CatalogActions = __webpack_require__(2471);
// EXTERNAL MODULE: ./components/Layout/layout.js + 22 modules
var layout = __webpack_require__(4829);
// EXTERNAL MODULE: ./GRAPHQL/products.js
var GRAPHQL_products = __webpack_require__(9271);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./pages/catalog/index.js

















const first = 8;
function Catalog({ categories , initialData  }) {
    const router = (0,router_.useRouter)();
    const onSale = !!router?.query?.onSale;
    const onSearch = router?.query?.search;
    const firstRender = (0,useFirstRender/* useFirstRender */.s)();
    const { 0: filters , 1: setFilters  } = (0,external_react_.useState)([]);
    const { 0: colorTerms , 1: setColorTerms  } = (0,external_react_.useState)([]);
    const { 0: sizeTerms , 1: setSizeTerms  } = (0,external_react_.useState)([]);
    const { 0: brandTerms , 1: setBrandTerms  } = (0,external_react_.useState)([]);
    const { 0: sortBy , 1: setSortBy  } = (0,external_react_.useState)('');
    const { 0: data , 1: setData  } = (0,external_react_.useState)({
        products: initialData?.nodes || [],
        endCursor: initialData?.pageInfo?.endCursor,
        hasNextPage: !!initialData?.pageInfo?.hasNextPage,
        colors: initialData?.activeTerms?.paColors,
        sizes: initialData?.activeTerms?.paSizes,
        brands: initialData?.activeTerms?.paBrands
    });
    const breadcrumbs = [
        {
            databaseId: 'main',
            name: 'Главная',
            slug: '/'
        },
        // ...(category?.parent
        //     ? [
        //       {
        //         databaseId: category?.parent?.node?.databaseId,
        //         name: category?.parent?.node?.name,
        //         slug: '/catalog/' + category?.parent?.node?.slug,
        //       },
        //     ]
        //     : []),
        {
            // databaseId: category?.databaseId,
            name: 'Каталог',
            slug: '/catalog'
        }, 
    ];
    const [loadData, { data: moreData , loading: loadingData  }] = (0,client_.useLazyQuery)(GRAPHQL_products/* PRODUCTS */.b, {
        client: apollo_client/* client */.L,
        fetchPolicy: 'network-only',
        notifyOnNetworkStatusChange: true,
        onCompleted: ()=>{
            setData((oldData)=>oldData && {
                    products: [
                        ...oldData?.products,
                        ...moreData?.products?.nodes
                    ],
                    endCursor: moreData?.products?.pageInfo?.endCursor,
                    hasNextPage: moreData?.products?.pageInfo?.hasNextPage,
                    colors: moreData?.products?.activeTerms?.paColors,
                    sizes: moreData?.products?.activeTerms?.paSizes,
                    brands: moreData?.products?.activeTerms?.paBrands
                }
            );
        }
    });
    const customLoadData = ()=>loadData({
            variables: {
                first,
                onSale: onSale,
                after: data?.endCursor || undefined,
                filters: filters.length ? filters : undefined,
                search: onSearch || undefined,
                orderBy: sortBy ? [
                    {
                        field: 'PRICE',
                        order: sortBy
                    }, 
                ] : undefined
            }
        })
    ;
    (0,external_react_.useEffect)(()=>{
        if (!firstRender) {
            setFilters([
                ...colorTerms.length ? [
                    {
                        taxonomy: 'PACOLOR',
                        terms: colorTerms.map((color)=>color.slug
                        )
                    }, 
                ] : [],
                ...sizeTerms.length ? [
                    {
                        taxonomy: 'PASIZE',
                        terms: sizeTerms.map((size)=>size.slug
                        )
                    }, 
                ] : [],
                ...brandTerms.length ? [
                    {
                        taxonomy: 'PABRAND',
                        terms: brandTerms.map((brand)=>brand.slug
                        )
                    }, 
                ] : [], 
            ]);
        }
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        colorTerms,
        sizeTerms,
        brandTerms
    ]);
    (0,external_react_.useEffect)(()=>{
        if (!firstRender) {
            setData({
                products: [],
                endCursor: '',
                hasNextPage: false,
                colors: [],
                sizes: [],
                brands: []
            });
            customLoadData();
        }
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        filters
    ]);
    (0,external_react_.useEffect)(()=>{
        if (onSale) {
            setData({
                products: [],
                endCursor: '',
                hasNextPage: false,
                colors: [],
                sizes: [],
                brands: []
            });
            customLoadData();
        }
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        onSale
    ]);
    (0,external_react_.useEffect)(()=>{
        if (onSearch) {
            setData({
                products: [],
                endCursor: '',
                hasNextPage: false,
                colors: [],
                sizes: [],
                brands: []
            });
            customLoadData();
        }
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        onSearch
    ]);
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(layout/* default */.Z, {
        categories: categories,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(Breadcrumbs_breadcrumbs/* default */.Z, {
                breadcrumbs: breadcrumbs
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(section_title/* default */.Z, {
                title: "Каталог"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Grid, {
                container: true,
                spacing: {
                    xs: 2,
                    md: 4
                },
                sx: {
                    mb: 4
                },
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(CatalogActions/* default */.Z, {
                        onSale: onSale,
                        onSearch: onSearch,
                        sortBy: sortBy,
                        setSortBy: setSortBy,
                        category: categories,
                        filters: filters,
                        colors: data?.colors,
                        colorTerms: colorTerms,
                        setColorTerms: setColorTerms,
                        sizes: data?.sizes,
                        sizeTerms: sizeTerms,
                        setSizeTerms: setSizeTerms,
                        brands: data?.brands,
                        brandTerms: brandTerms,
                        setBrandTerms: setBrandTerms
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
                        item: true,
                        xs: 12,
                        md: 9,
                        children: loadingData && !data?.products?.length ? /*#__PURE__*/ jsx_runtime_.jsx(ProductsList_Skeleton, {}) : data?.products?.length ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)((external_react_infinite_scroller_default()), {
                            pageStart: 0,
                            loadMore: customLoadData,
                            hasMore: data?.hasNextPage,
                            initialLoad: false,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(ProductsList/* default */.Z, {
                                    products: data?.products
                                }),
                                loadingData && /*#__PURE__*/ jsx_runtime_.jsx(ProductsList_Skeleton, {})
                            ]
                        }) : /*#__PURE__*/ jsx_runtime_.jsx(empty/* default */.Z, {
                            title: "Товары не найдены"
                        })
                    })
                ]
            })
        ]
    }));
};
async function getStaticProps({ params  }) {
    const categories = await apollo_client/* client.query */.L.query({
        query: GRAPHQL_categories/* CATEGORIES */.a
    });
    const products = await apollo_client/* client.query */.L.query({
        query: GRAPHQL_products/* PRODUCTS */.b,
        variables: {
            first: 8
        }
    });
    return {
        props: {
            categories: categories?.data?.productCategories?.nodes,
            initialData: products?.data?.products
        }
    };
}


/***/ }),

/***/ 9114:
/***/ ((module) => {

module.exports = require("@apollo/client");

/***/ }),

/***/ 5692:
/***/ ((module) => {

module.exports = require("@mui/material");

/***/ }),

/***/ 9868:
/***/ ((module) => {

module.exports = require("@mui/material/useMediaQuery");

/***/ }),

/***/ 562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 8028:
/***/ ((module) => {

module.exports = require("next/dist/server/image-config.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 4365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 3018:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/to-base-64.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 6405:
/***/ ((module) => {

module.exports = require("react-dom");

/***/ }),

/***/ 9585:
/***/ ((module) => {

module.exports = require("react-image-gallery");

/***/ }),

/***/ 5030:
/***/ ((module) => {

module.exports = require("react-infinite-scroller");

/***/ }),

/***/ 6022:
/***/ ((module) => {

module.exports = require("react-redux");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [730,61,278,925,667,428,889,233], () => (__webpack_exec__(3505)));
module.exports = __webpack_exports__;

})();