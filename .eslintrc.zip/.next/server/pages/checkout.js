"use strict";
(() => {
var exports = {};
exports.id = 222;
exports.ids = [222];
exports.modules = {

/***/ 9589:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "a": () => (/* binding */ CATEGORIES)
/* harmony export */ });
/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9114);
/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_apollo_client__WEBPACK_IMPORTED_MODULE_0__);

const CATEGORIES = _apollo_client__WEBPACK_IMPORTED_MODULE_0__.gql`
query MyQuery {
  productCategories(
  where: {
  hideEmpty: true,
  slug: ["detskaya-komnata", "dlya-mamy", "igrushki-i-igry", "knigi", "odezhda-i-obuv",
         "pitanie-i-kormlenie","progulki-i-puteshestviya","uhod-i-gigiena"]
   }) {
    nodes {
      databaseId
      name
      slug
      children(first: 100, where: {hideEmpty: true}) {
        nodes {
          databaseId
          name
          slug
          children(first: 100, where: {hideEmpty: true}) {
            nodes {
              databaseId
              name
              slug
            }
          }
        }
      }
    }
  }
}
`;


/***/ }),

/***/ 4780:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "F": () => (/* binding */ Autocomplete)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(5692);
;// CONCATENATED MODULE: external "use-places-autocomplete"
const external_use_places_autocomplete_namespaceObject = require("use-places-autocomplete");
var external_use_places_autocomplete_default = /*#__PURE__*/__webpack_require__.n(external_use_places_autocomplete_namespaceObject);
;// CONCATENATED MODULE: external "react-cool-onclickoutside"
const external_react_cool_onclickoutside_namespaceObject = require("react-cool-onclickoutside");
var external_react_cool_onclickoutside_default = /*#__PURE__*/__webpack_require__.n(external_react_cool_onclickoutside_namespaceObject);
;// CONCATENATED MODULE: ./components/AutoComplete/autocomplete.js





const Autocomplete = ({ isLoaded  })=>{
    const { ready , value , init , suggestions: { status , data  } , setValue , clearSuggestions ,  } = external_use_places_autocomplete_default()({
        initOnMount: false,
        debounce: 300
    });
    const ref = external_react_cool_onclickoutside_default()(()=>{
        clearSuggestions();
    });
    const handleInput = (e)=>{
        // Update the keyword of the input element
        setValue(e.target.value);
    };
    const handleSelect = ({ description  })=>()=>{
            // When user selects a place, we can replace the keyword without request data from API
            // by setting the second parameter to "false"
            setValue(description, false);
            clearSuggestions();
            // Get latitude and longitude via utility functions
            (0,external_use_places_autocomplete_namespaceObject.getGeocode)({
                address: description
            }).then((results)=>(0,external_use_places_autocomplete_namespaceObject.getLatLng)(results[0])
            ).then(({ lat , lng  })=>{
                console.log('📍 Coordinates: ', {
                    lat,
                    lng
                });
            }).catch((error)=>{
                console.log('😱 Error: ', error);
            });
        }
    ;
    const renderSuggestions = ()=>data.map((suggestion)=>{
            const { place_id , structured_formatting: { main_text , secondary_text  } ,  } = suggestion;
            return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                onClick: handleSelect(suggestion),
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                        children: main_text
                    }),
                    " ",
                    /*#__PURE__*/ jsx_runtime_.jsx("small", {
                        children: secondary_text
                    })
                ]
            }, place_id));
        })
    ;
    external_react_default().useEffect(()=>{
        if (isLoaded) {
            init();
        }
    }, [
        isLoaded,
        init
    ]);
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
        sx: {
            position: 'relative'
        },
        ref: ref,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                type: "text",
                value: value,
                onChange: handleInput,
                disabled: !ready,
                placeholder: "*Найдите на карте адрес доставки и кликнете на него."
            }),
            status === 'OK' && /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                children: renderSuggestions()
            })
        ]
    }));
};


/***/ }),

/***/ 7341:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _OrderDetails_order_details__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(852);
/* harmony import */ var _GoogleMaps_google_maps__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5624);
/* harmony import */ var _react_google_maps_api__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2433);
/* harmony import */ var _react_google_maps_api__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_react_google_maps_api__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _AutoComplete_autocomplete__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4780);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5641);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _utility_useUser__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(697);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_11__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utility_useUser__WEBPACK_IMPORTED_MODULE_9__, react_hook_form__WEBPACK_IMPORTED_MODULE_7__]);
([_utility_useUser__WEBPACK_IMPORTED_MODULE_9__, react_hook_form__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);












const API_KEY = process.env.NEXT_PUBLIC_API_KEY;
const defaultCenter = {
    lat: 51.509865,
    lng: -0.118092
};
const libraries = [
    'places'
];
const CheckoutMain = ()=>{
    const { isLoaded  } = (0,_react_google_maps_api__WEBPACK_IMPORTED_MODULE_5__.useJsApiLoader)({
        id: 'google-map-script',
        googleMapsApiKey: API_KEY,
        libraries
    });
    const { register , errors , handleSubmit , setValue  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_7__.useForm)();
    const { 0: isLoading , 1: setIsLoading  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const user =  false && 0;
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_8__.useRouter)();
    const lineItems = [];
    const { 0: name , 1: setName  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)('');
    const { 0: surname , 1: setSurname  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)('');
    const { 0: phone , 1: setPhone  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)('');
    const { 0: email , 1: setEmail  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)('');
    const { 0: city , 1: setCity  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(user && user.city ? user.city : 'Toshkent shahri');
    const { 0: country , 1: setCountry  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(user && user.country ? user.country : 'Uzbekistan');
    const { 0: address , 1: setAddress  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)('');
    const { 0: delivery , 1: setDelivery  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(`Доставка курьером`);
    const { 0: comment , 1: setComment  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)('');
    const { 0: checkboxTicked , 1: setCheckboxTicked  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(true);
    const { 0: selectMethod , 1: setSelectMethod  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)('cash');
    const { 0: order , 1: setOrder  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const { userData  } = (0,_utility_useUser__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z)();
    const cart = (0,react_redux__WEBPACK_IMPORTED_MODULE_10__.useSelector)((state)=>state.cart
    );
    for (const product of cart){
        lineItems.push({
            product_id: product.databaseId,
            name: product.name,
            price: product.onSale ? product.woocsSalePrice : product.woocsRegularPrice,
            quantity: product.quantity,
            variation_id: product.variations && product.selectedProductId
        });
    }
    let cartTotalPrice = 0;
    cart.map(({ woocsRegularPrice , woocsSalePrice , onSale  })=>{
        cartTotalPrice += onSale ? woocsSalePrice * 1 : woocsRegularPrice * 1;
    });
    const getDeliveryPrice = ()=>delivery === 'Доставка курьером' ? 15000 : 0
    ;
    const sendInfo = async ()=>{
        setIsLoading(true);
        const orderData = {
            customer_id: userData?.isLoggedIn ? userData.user.databaseId : 0,
            set_paid: false,
            currency: 'UZS',
            status: selectMethod === 'cash' ? 'processing' : 'pending',
            total: cartTotalPrice,
            // coupon_lines: discount && [{code: discount.code}],
            payment_method_title: selectMethod === 'cash' ? 'Оплата наличными или картой при доставке' : selectMethod,
            line_items: lineItems,
            billing: {
                country: country,
                address_1: address,
                city: city,
                first_name: name,
                last_name: surname,
                phone: phone
            },
            shipping_lines: [
                {
                    method_id: delivery === 'Доставка курьером' ? 'flat_rate' : 'local_pickup',
                    method_title: delivery === 'Доставка курьером' ? 'Доставка курьером' : 'Самовывоз из магазина',
                    total: getDeliveryPrice().toLocaleString()
                }, 
            ],
            customer_note: comment && comment
        };
        const response = await axios__WEBPACK_IMPORTED_MODULE_11___default().post('/api/order', {
            order: orderData
        });
        if (response.data.status) {
            setOrder(response.data.order);
            if (selectMethod === 'cash') {
                await window.location.assign(`/order/${response.data.order.order_key}`);
                localStorage.clear();
            } else {
                const form = document.querySelector(`#${selectMethod}-form`);
                if (form) {
                    form.submit();
                }
                localStorage.clear();
            }
        } else {
            alert(response.data.message);
            router.reload();
        }
        setIsLoading(false);
    };
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
        sx: {
            width: '100%',
            display: {
                xs: 'block',
                md: 'flex'
            },
            justifyContent: 'space-between',
            mb: 6
        },
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
                sx: {
                    width: {
                        xs: '100%',
                        md: '68%'
                    }
                },
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
                        sx: {
                            padding: '25px 20px',
                            border: '1px solid #E8E8E8',
                            borderRadius: '8px'
                        },
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
                                sx: {
                                    display: 'flex',
                                    marginBottom: '30px'
                                },
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
                                        sx: {
                                            width: '33.3%',
                                            height: '50px'
                                        },
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.TextField, {
                                            id: "name",
                                            label: "Имя",
                                            variant: "outlined",
                                            required: true,
                                            fullWidth: true,
                                            sx: {
                                                maxWidth: '260px',
                                                border: '1px solid #E8E8E8',
                                                borderRadius: '8px',
                                                boxShadow: '0px 4px 40px rgba(0, 0, 0, 0.1)'
                                            }
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
                                        sx: {
                                            width: '33.3%'
                                        },
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.TextField, {
                                            id: "surname",
                                            label: "Фамилия",
                                            variant: "outlined",
                                            required: true,
                                            fullWidth: true,
                                            sx: {
                                                maxWidth: '260px',
                                                border: '1px solid #E8E8E8',
                                                borderRadius: '8px',
                                                boxShadow: '0px 4px 40px rgba(0, 0, 0, 0.1)'
                                            }
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
                                        sx: {
                                            width: '33.3%'
                                        },
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.TextField, {
                                            id: "number",
                                            label: "Номер телефона",
                                            variant: "outlined",
                                            required: true,
                                            fullWidth: true,
                                            sx: {
                                                maxWidth: '260px',
                                                border: '1px solid #E8E8E8',
                                                borderRadius: '8px',
                                                boxShadow: '0px 4px 40px rgba(0, 0, 0, 0.1)'
                                            }
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
                                sx: {
                                    display: 'flex'
                                },
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
                                        sx: {
                                            width: '50%'
                                        },
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.TextField, {
                                            id: "city",
                                            label: "Город",
                                            variant: "outlined",
                                            required: true,
                                            fullWidth: true,
                                            sx: {
                                                maxWidth: '400px',
                                                border: '1px solid #E8E8E8',
                                                borderRadius: '8px',
                                                boxShadow: '0px 4px 40px rgba(0, 0, 0, 0.1)'
                                            }
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
                                        sx: {
                                            width: '50%'
                                        },
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.TextField, {
                                            id: "district",
                                            label: "Город / Район",
                                            variant: "outlined",
                                            required: true,
                                            fullWidth: true,
                                            sx: {
                                                maxWidth: '400px',
                                                border: '1px solid #E8E8E8',
                                                borderRadius: '8px',
                                                boxShadow: '0px 4px 40px rgba(0, 0, 0, 0.1)'
                                            }
                                        })
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_AutoComplete_autocomplete__WEBPACK_IMPORTED_MODULE_6__/* .Autocomplete */ .F, {
                        isLoaded: isLoaded
                    }),
                    isLoaded ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_GoogleMaps_google_maps__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                        center: defaultCenter
                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                        children: "is loading..."
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
                        sx: {
                            padding: '25px 20px',
                            border: '1px solid #E8E8E8',
                            borderRadius: '8px'
                        },
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
                                sx: {
                                    display: 'flex',
                                    marginBottom: '30px'
                                },
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
                                        sx: {
                                            width: '50%'
                                        },
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.TextField, {
                                            id: "street",
                                            label: "Улица",
                                            variant: "outlined",
                                            required: true,
                                            fullWidth: true,
                                            sx: {
                                                maxWidth: '400px',
                                                border: '1px solid #E8E8E8',
                                                borderRadius: '8px',
                                                boxShadow: '0px 4px 40px rgba(0, 0, 0, 0.1)'
                                            }
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
                                        sx: {
                                            width: '50%'
                                        },
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.TextField, {
                                            id: "home",
                                            label: "Дом",
                                            variant: "outlined",
                                            required: true,
                                            fullWidth: true,
                                            sx: {
                                                maxWidth: '400px',
                                                border: '1px solid #E8E8E8',
                                                borderRadius: '8px',
                                                boxShadow: '0px 4px 40px rgba(0, 0, 0, 0.1)'
                                            }
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
                                sx: {
                                    display: 'flex'
                                },
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
                                        sx: {
                                            width: '33.3%',
                                            height: '50px'
                                        },
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.TextField, {
                                            id: "department",
                                            label: "Квартира",
                                            variant: "outlined",
                                            required: true,
                                            fullWidth: true,
                                            sx: {
                                                maxWidth: '260px',
                                                border: '1px solid #E8E8E8',
                                                borderRadius: '8px',
                                                boxShadow: '0px 4px 40px rgba(0, 0, 0, 0.1)'
                                            }
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
                                        sx: {
                                            width: '33.3%'
                                        },
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.TextField, {
                                            id: "entrance",
                                            label: "Подъезд",
                                            variant: "outlined",
                                            required: true,
                                            fullWidth: true,
                                            sx: {
                                                maxWidth: '260px',
                                                border: '1px solid #E8E8E8',
                                                borderRadius: '8px',
                                                boxShadow: '0px 4px 40px rgba(0, 0, 0, 0.1)'
                                            }
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
                                        sx: {
                                            width: '33.3%'
                                        },
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.TextField, {
                                            id: "floor",
                                            label: "Этаж",
                                            variant: "outlined",
                                            required: true,
                                            fullWidth: true,
                                            sx: {
                                                maxWidth: '260px',
                                                border: '1px solid #E8E8E8',
                                                borderRadius: '8px',
                                                boxShadow: '0px 4px 40px rgba(0, 0, 0, 0.1)'
                                            }
                                        })
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.TextareaAutosize, {
                        "aria-label": "textarea",
                        placeholder: "Комментарий к заказу (необязательно)",
                        style: {
                            width: '100%',
                            height: '180px',
                            padding: '20px',
                            border: '1px solid #E8E8E8',
                            borderRadius: '8px',
                            marginTop: '35px',
                            fontSize: '16px',
                            fontWeight: 400,
                            color: '#999999'
                        }
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Button, {
                        variant: "contained",
                        sx: {
                            width: {
                                xs: '280px',
                                md: '200px'
                            },
                            height: {
                                xs: '45px',
                                md: '50px'
                            },
                            borderRadius: '8px',
                            display: 'flex',
                            justifyContent: 'center',
                            alignItems: 'center',
                            margin: '35px 0'
                        },
                        onClick: handleSubmit(sendInfo),
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                            sx: {
                                fontSize: '18px',
                                fontWeight: 500,
                                lineHeight: '24px'
                            },
                            children: "ЗАКАЗАТЬ"
                        })
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
                sx: {
                    width: {
                        xs: '100%',
                        md: '30%'
                    }
                },
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_OrderDetails_order_details__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {})
                })
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CheckoutMain);

});

/***/ }),

/***/ 5624:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _react_google_maps_api__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2433);
/* harmony import */ var _react_google_maps_api__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_react_google_maps_api__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_3__);




const containerStyle = {
    width: '100%',
    height: '100%'
};
const GoogleMaps = ({ center  })=>{
    let mapRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(undefined);
    const onLoad = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(function callback(map) {
        mapRef.current = map;
    }, []);
    const onUnmount = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(function callback(map) {
        mapRef.current = undefined;
    }, []);
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Box, {
        sx: {
            width: '100%',
            height: '450px',
            margin: '40px 0',
            borderRadius: '8px'
        },
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_react_google_maps_api__WEBPACK_IMPORTED_MODULE_2__.GoogleMap, {
            mapContainerStyle: containerStyle,
            center: center,
            zoom: 10,
            onLoad: onLoad,
            onUnmount: onUnmount,
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {})
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (GoogleMaps);


/***/ }),

/***/ 8283:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Checkout),
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_Layout_layout__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4829);
/* harmony import */ var _components_Breadcrumbs_breadcrumbs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(741);
/* harmony import */ var _components_SectionTitle_section_title__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2161);
/* harmony import */ var _components_Checkout_checkout__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7341);
/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9999);
/* harmony import */ var _GRAPHQL_categories__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9589);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_Checkout_checkout__WEBPACK_IMPORTED_MODULE_5__]);
_components_Checkout_checkout__WEBPACK_IMPORTED_MODULE_5__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];








function Checkout({ categories  }) {
    const breadcrumbs = [
        {
            name: 'Главная',
            slug: '/'
        },
        {
            name: 'Оформление заказа',
            slug: `/checkout`
        }, 
    ];
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_Layout_layout__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
        categories: categories,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Breadcrumbs_breadcrumbs__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                breadcrumbs: breadcrumbs
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_SectionTitle_section_title__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                title: "Оформление заказа"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Checkout_checkout__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {})
        ]
    }));
};
async function getStaticProps() {
    const categories = await _apollo_client__WEBPACK_IMPORTED_MODULE_6__/* .client.query */ .L.query({
        query: _GRAPHQL_categories__WEBPACK_IMPORTED_MODULE_7__/* .CATEGORIES */ .a
    });
    return {
        props: {
            categories: categories?.data?.productCategories?.nodes
        }
    };
}

});

/***/ }),

/***/ 697:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ useUser)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var swr__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5941);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([swr__WEBPACK_IMPORTED_MODULE_2__]);
swr__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];



function useUser({ redirectTo =false , redirectIfFound =false ,  } = {}) {
    // request user data from backend and cache it
    // for more details check swr plugin
    const { data: userData , mutate: mutateUser  } = (0,swr__WEBPACK_IMPORTED_MODULE_2__["default"])('/api/auth/user', {
        focusThrottleInterval: 5 * 60 * 1000
    });
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        // if no redirect needed, just return (example: already on /dashboard)
        // if user data not yet there (fetch in progress, logged in or not) then don't do anything yet
        if (!redirectTo || !userData) return;
        if (// If redirectTo is set, redirect if the user was not found.
        (redirectTo && !redirectIfFound && !userData?.isLoggedIn) || // If redirectIfFound is also set, redirect if the user was found
        (redirectIfFound && userData?.isLoggedIn)) {
            next_router__WEBPACK_IMPORTED_MODULE_1___default().replace(redirectTo);
        }
    }, [
        userData,
        redirectIfFound,
        redirectTo
    ]);
    return {
        userData,
        mutateUser
    };
};

});

/***/ }),

/***/ 9114:
/***/ ((module) => {

module.exports = require("@apollo/client");

/***/ }),

/***/ 5692:
/***/ ((module) => {

module.exports = require("@mui/material");

/***/ }),

/***/ 9868:
/***/ ((module) => {

module.exports = require("@mui/material/useMediaQuery");

/***/ }),

/***/ 2433:
/***/ ((module) => {

module.exports = require("@react-google-maps/api");

/***/ }),

/***/ 2167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 8028:
/***/ ((module) => {

module.exports = require("next/dist/server/image-config.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 4365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 3018:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/to-base-64.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 6022:
/***/ ((module) => {

module.exports = require("react-redux");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 5641:
/***/ ((module) => {

module.exports = import("react-hook-form");;

/***/ }),

/***/ 5941:
/***/ ((module) => {

module.exports = import("swr");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [730,61,278,925,852], () => (__webpack_exec__(8283)));
module.exports = __webpack_exports__;

})();