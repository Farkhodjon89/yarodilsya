"use strict";
(() => {
var exports = {};
exports.id = 331;
exports.ids = [331];
exports.modules = {

/***/ 9589:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "a": () => (/* binding */ CATEGORIES)
/* harmony export */ });
/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9114);
/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_apollo_client__WEBPACK_IMPORTED_MODULE_0__);

const CATEGORIES = _apollo_client__WEBPACK_IMPORTED_MODULE_0__.gql`
query MyQuery {
  productCategories(
  where: {
  hideEmpty: true,
  slug: ["detskaya-komnata", "dlya-mamy", "igrushki-i-igry", "knigi", "odezhda-i-obuv",
         "pitanie-i-kormlenie","progulki-i-puteshestviya","uhod-i-gigiena"]
   }) {
    nodes {
      databaseId
      name
      slug
      children(first: 100, where: {hideEmpty: true}) {
        nodes {
          databaseId
          name
          slug
          children(first: 100, where: {hideEmpty: true}) {
            nodes {
              databaseId
              name
              slug
            }
          }
        }
      }
    }
  }
}
`;


/***/ }),

/***/ 5543:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Order),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./components/OrderMain/order-main.js


const OrderMain = ()=>{
    return(/*#__PURE__*/ jsx_runtime_.jsx("div", {}));
};
/* harmony default export */ const order_main = (OrderMain);

// EXTERNAL MODULE: ./apollo-client.js
var apollo_client = __webpack_require__(9999);
;// CONCATENATED MODULE: external "graphql-tag"
const external_graphql_tag_namespaceObject = require("graphql-tag");
var external_graphql_tag_default = /*#__PURE__*/__webpack_require__.n(external_graphql_tag_namespaceObject);
;// CONCATENATED MODULE: ./GRAPHQL/order.js

const ORDER = (external_graphql_tag_default())`
  query ORDER($id: ID!) {
    order(id: $id, idType: ORDER_NUMBER) {
      databaseId
      orderKey
      date
      customerNote
      total(format: RAW)
      status
      paymentMethodTitle
      billing {
        firstName
        lastName
        phone
        address1
      }
      shippingLines {
        nodes {
          methodTitle
          total
        }
      }
      lineItems {
        nodes {
          product {
            name
            image {
              sourceUrl
            }
          }
          quantity
          total
          color: metaData(key: "pa_color") {
            value
          }
          size: metaData(key: "pa_size") {
            value
          }
        }
      }
    }
  }
`;
/* harmony default export */ const GRAPHQL_order = (ORDER);

// EXTERNAL MODULE: ./components/Layout/layout.js + 22 modules
var layout = __webpack_require__(4829);
// EXTERNAL MODULE: ./GRAPHQL/categories.js
var GRAPHQL_categories = __webpack_require__(9589);
;// CONCATENATED MODULE: ./pages/order/[slug].js







function Order({ order , categories  }) {
    return(/*#__PURE__*/ jsx_runtime_.jsx(layout/* default */.Z, {
        categories: categories,
        children: /*#__PURE__*/ jsx_runtime_.jsx(order_main, {
            order: order
        })
    }));
};
const getServerSideProps = async ({ params  })=>{
    const order = await apollo_client/* client.query */.L.query({
        query: GRAPHQL_order,
        variables: {
            id: params.slug
        }
    });
    const categories = await apollo_client/* client.query */.L.query({
        query: GRAPHQL_categories/* CATEGORIES */.a
    });
    return {
        props: {
            order: order.data.order,
            categories: categories.data.productCategories.nodes
        }
    };
};


/***/ }),

/***/ 9114:
/***/ ((module) => {

module.exports = require("@apollo/client");

/***/ }),

/***/ 5692:
/***/ ((module) => {

module.exports = require("@mui/material");

/***/ }),

/***/ 9868:
/***/ ((module) => {

module.exports = require("@mui/material/useMediaQuery");

/***/ }),

/***/ 562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 8028:
/***/ ((module) => {

module.exports = require("next/dist/server/image-config.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 4365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 3018:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/to-base-64.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 6022:
/***/ ((module) => {

module.exports = require("react-redux");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [730,61,278], () => (__webpack_exec__(5543)));
module.exports = __webpack_exports__;

})();