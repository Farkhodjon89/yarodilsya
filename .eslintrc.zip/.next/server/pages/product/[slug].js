"use strict";
(() => {
var exports = {};
exports.id = 915;
exports.ids = [915];
exports.modules = {

/***/ 9589:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "a": () => (/* binding */ CATEGORIES)
/* harmony export */ });
/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9114);
/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_apollo_client__WEBPACK_IMPORTED_MODULE_0__);

const CATEGORIES = _apollo_client__WEBPACK_IMPORTED_MODULE_0__.gql`
query MyQuery {
  productCategories(
  where: {
  hideEmpty: true,
  slug: ["detskaya-komnata", "dlya-mamy", "igrushki-i-igry", "knigi", "odezhda-i-obuv",
         "pitanie-i-kormlenie","progulki-i-puteshestviya","uhod-i-gigiena"]
   }) {
    nodes {
      databaseId
      name
      slug
      children(first: 100, where: {hideEmpty: true}) {
        nodes {
          databaseId
          name
          slug
          children(first: 100, where: {hideEmpty: true}) {
            nodes {
              databaseId
              name
              slug
            }
          }
        }
      }
    }
  }
}
`;


/***/ }),

/***/ 1639:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Product),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./components/Layout/layout.js + 22 modules
var layout = __webpack_require__(4829);
// EXTERNAL MODULE: ./components/Breadcrumbs/breadcrumbs.js
var Breadcrumbs_breadcrumbs = __webpack_require__(741);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(5692);
// EXTERNAL MODULE: external "react-image-gallery"
var external_react_image_gallery_ = __webpack_require__(9585);
var external_react_image_gallery_default = /*#__PURE__*/__webpack_require__.n(external_react_image_gallery_);
// EXTERNAL MODULE: ./components/SectionTitle/section-title.js
var section_title = __webpack_require__(2161);
// EXTERNAL MODULE: ./utility/FormatPrice.js
var FormatPrice = __webpack_require__(740);
// EXTERNAL MODULE: ./components/QuantityCount/quantity-count.js + 1 modules
var quantity_count = __webpack_require__(7863);
// EXTERNAL MODULE: ./public/icons/Heart.js
var Heart = __webpack_require__(6842);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(6022);
// EXTERNAL MODULE: ./components/ProductCardAccordion/product-card-accordion.js + 2 modules
var product_card_accordion = __webpack_require__(5593);
// EXTERNAL MODULE: external "@mui/material/useMediaQuery"
var useMediaQuery_ = __webpack_require__(9868);
var useMediaQuery_default = /*#__PURE__*/__webpack_require__.n(useMediaQuery_);
// EXTERNAL MODULE: ./redux/actions/cart.js
var actions_cart = __webpack_require__(6613);
// EXTERNAL MODULE: ./components/ProductItem/product-item.js + 1 modules
var product_item = __webpack_require__(428);
;// CONCATENATED MODULE: ./components/SimilarProducts/similar-products.js





const SimilarProducts = ({ products , title  })=>{
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(section_title/* default */.Z, {
                title: title
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
                container: true,
                spacing: 0,
                children: products.map((product, index)=>index < 6 ? /*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
                        item: true,
                        xs: 6,
                        md: 2,
                        children: /*#__PURE__*/ jsx_runtime_.jsx(product_item/* default */.Z, {
                            product: product
                        })
                    }) : ''
                )
            })
        ]
    }));
};
/* harmony default export */ const similar_products = (SimilarProducts);

;// CONCATENATED MODULE: ./components/ProductCard/product-card.js














const ProductCard = ({ product: product1  })=>{
    const { 0: cartModal , 1: setCartModal  } = (0,external_react_.useState)(false);
    const { 0: addedToWishlist , 1: addToWishlist  } = (0,external_react_.useState)(false);
    const { 0: open , 1: setOpen  } = (0,external_react_.useState)(false);
    const { 0: quantity , 1: setQuantity  } = (0,external_react_.useState)(1);
    const { 0: selectedSize , 1: setSelectedSize  } = (0,external_react_.useState)('');
    const { 0: maxQuantity , 1: setMaxQuantity  } = (0,external_react_.useState)(1);
    const { 0: selectedId , 1: setSelectedId  } = (0,external_react_.useState)(0);
    const matches = useMediaQuery_default()('(max-width: 600px)');
    const dispatch = (0,external_react_redux_.useDispatch)();
    const cart = (0,external_react_redux_.useSelector)((state)=>state.cart
    );
    const wishlist = (0,external_react_redux_.useSelector)((state)=>state.wishlist
    );
    const alreadyAddedToCart = !!cart.find((item)=>item.selectedId === selectedId
    );
    const alreadyAddedToWishlist = !!wishlist.find((item)=>item.databaseId === selectedId
    );
    const sizes = product1?.variations ? product1.variations?.nodes?.map((variation)=>({
            databaseId: variation.databaseId,
            stockQuantity: variation.stockQuantity,
            size: variation.size?.nodes[0]?.value
        })
    ) : [
        {
            databaseId: product1.databaseId,
            stockQuantity: product1.stockQuantity,
            size: product1?.size?.nodes[0]?.options
        }, 
    ];
    const images = [
        {
            original: product1.image.sourceUrl,
            thumbnail: product1.image.sourceUrl
        },
        ...product1?.galleryImages?.nodes?.map(({ sourceUrl  })=>({
                original: sourceUrl,
                thumbnail: sourceUrl
            })
        ), 
    ];
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(section_title/* default */.Z, {
                title: product1.name
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                sx: {
                    display: 'flex',
                    flexDirection: {
                        xs: 'column',
                        md: 'row'
                    },
                    marginBottom: {
                        xs: '15px',
                        md: '90px'
                    }
                },
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                        sx: {
                            width: {
                                xs: '100%',
                                marginRight: '20px',
                                md: '45%'
                            },
                            mb: {
                                xs: 2,
                                md: 0
                            },
                            '.image-gallery-slide .image-gallery-image': {
                                objectFit: 'cover !important',
                                minHeight: {
                                    xs: '340px !important',
                                    md: '580px !important'
                                },
                                height: {
                                    xs: '340px !important',
                                    md: '580px !important'
                                },
                                maxHeight: {
                                    xs: '340px !important',
                                    md: '580px !important'
                                }
                            },
                            '.image-gallery-thumbnail': {
                                width: {
                                    md: '90px'
                                },
                                borderRadius: '8px'
                            },
                            '.image-gallery-thumbnail ': {
                                border: '2px solid #EA56AE;'
                            },
                            '.image-gallery-right-nav .image-gallery-svg': {
                                height: '72px !important',
                                width: '36px !important'
                            },
                            '.image-gallery-left-nav .image-gallery-svg': {
                                height: '72px !important',
                                width: '36px !important'
                            },
                            '@media (hover: hover) and (pointer: fine)': {
                                '.image-gallery-icon:hover': {
                                    color: '#f6a68d !important'
                                },
                                '.image-gallery-bullets .image-gallery-bullet:hover': {
                                    background: '#f6a68d !important',
                                    border: '1px solid #f6a68d !important'
                                }
                            }
                        },
                        children: /*#__PURE__*/ jsx_runtime_.jsx((external_react_image_gallery_default()), {
                            items: images,
                            thumbnailPosition: "left",
                            showThumbnails: !matches,
                            showBullets: false,
                            showPlayButton: false,
                            showFullscreenButton: false,
                            autoPlay: false
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                        sx: {
                            width: {
                                xs: '100%',
                                md: '40%'
                            }
                        },
                        children: [
                            product1.onSale ? /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                sx: {
                                    fontWeight: '600',
                                    fontSize: {
                                        xs: '17px',
                                        md: '25px'
                                    },
                                    color: 'text.primary'
                                },
                                children: (0,FormatPrice/* default */.Z)(product1.woocsSalePrice)
                            }) : /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                sx: {
                                    fontWeight: 600,
                                    fontSize: '25px'
                                },
                                children: (0,FormatPrice/* default */.Z)(product1.woocsRegularPrice)
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Typography, {
                                sx: {
                                    color: 'grey.main',
                                    fontSize: '15px',
                                    fontWeight: '400',
                                    marginBottom: '30px'
                                },
                                children: [
                                    "Артикул: ",
                                    product1.sku
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
                                container: true,
                                spacing: 1,
                                children: sizes.map(({ databaseId , stockQuantity , size  })=>{
                                    const currentSize = selectedSize === size;
                                    return(/*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
                                        item: true,
                                        xs: 3,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Button, {
                                            sx: {
                                                fontWeight: 'normal',
                                                fontSize: 16,
                                                padding: '6px 12px',
                                                color: 'grey.main'
                                            },
                                            color: currentSize ? 'secondary' : 'primary',
                                            variant: currentSize ? 'contained' : 'text',
                                            onClick: ()=>{
                                                setSelectedId(databaseId);
                                                setSelectedSize(size);
                                                setMaxQuantity(stockQuantity);
                                            },
                                            children: size
                                        })
                                    }, databaseId));
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Stack, {
                                direction: "row",
                                spacing: 2,
                                sx: {
                                    margin: '20px 0',
                                    alignItems: 'center'
                                },
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(quantity_count/* default */.Z, {
                                        product: product1,
                                        quantity: quantity,
                                        setQuantity: setQuantity
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Button, {
                                        variant: "contained",
                                        color: !alreadyAddedToCart ? 'primary' : 'secondary',
                                        sx: {
                                            height: '45px',
                                            width: {
                                                xs: '200px',
                                                md: '240px'
                                            },
                                            borderRadius: '8px',
                                            display: 'flex',
                                            justifyContent: 'center',
                                            alignItems: 'center',
                                            boxShadow: 'none',
                                            color: 'white.main'
                                        },
                                        disabled: !selectedSize,
                                        onClick: ()=>{
                                            alreadyAddedToCart ? ()=>dispatch((0,actions_cart/* removeFromCart */.h2)(selectedId))
                                             : ()=>{
                                                dispatch((0,actions_cart/* addToCart */.Xq)(product1, selectedId, selectedSize, quantity));
                                                setCartModal(true);
                                            };
                                        },
                                        children: selectedSize ? alreadyAddedToCart ? 'В корзине' : 'Добавить в корзину' : 'Выбрать размер'
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(material_.IconButton, {
                                        "aria-label": "wishlist",
                                        onClick: ()=>addToWishlist((prev)=>!prev
                                            )
                                        ,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(Heart/* default */.Z, {})
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(product_card_accordion/* default */.Z, {})
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Grid, {
                container: true,
                spacing: 3,
                sx: {
                    marginBottom: '90px'
                },
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Grid, {
                        item: true,
                        sx: 12,
                        md: 6,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                                sx: {
                                    marginBottom: '40px'
                                },
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(section_title/* default */.Z, {
                                        title: "Описание"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                        sx: {
                                            fontWeight: 400,
                                            fontSize: '16px',
                                            color: 'grey.main',
                                            display: !open ? 'webkitBox' : '',
                                            '-webkitBoxOrient': !open ? 'vertical' : '',
                                            '-webkitLineClamp': !open ? '3' : '',
                                            textOverflow: 'ellipsis',
                                            overflow: !open ? 'hidden' : ''
                                        },
                                        children: "Женственные балетки базовых цветов подойдут почти под все элементы гардероба. Балетки хорошо сочетаются с джинсами для создания более повседневного стиля, так и с юбками и брюками для более официальных мероприятий. При разработке модели использовалась уникальная технология, которая способствует улучшенному воздухообмену. Балетки дышат, поэтому ноги не потеют даже в жаркие сезоны. Внут..."
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                        sx: {
                                            fontWeight: 600,
                                            fontSize: '15px',
                                            color: 'primary.main',
                                            lineHeight: '17px'
                                        },
                                        onClick: ()=>setOpen((prev)=>!prev
                                            )
                                        ,
                                        children: "Развернуть описание"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(section_title/* default */.Z, {
                                        title: "Характеристики:"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Stack, {
                                        sx: {
                                            maxWidth: '400px',
                                            width: '100%'
                                        },
                                        direction: "column",
                                        spacing: 1,
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                                                sx: {
                                                    display: 'flex',
                                                    justifyContent: 'space-between'
                                                },
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                                        sx: {
                                                            fontWeight: 400,
                                                            fontSize: '16px',
                                                            color: 'grey.main'
                                                        },
                                                        children: "Бренд:"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                                        sx: {
                                                            fontWeight: 400,
                                                            fontSize: '16px',
                                                            color: 'text.primary'
                                                        },
                                                        children: "Attitude"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                                                sx: {
                                                    display: 'flex',
                                                    justifyContent: 'space-between'
                                                },
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                                        sx: {
                                                            fontWeight: 400,
                                                            fontSize: '16px',
                                                            color: 'grey.main'
                                                        },
                                                        children: "Артикул:"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                                        sx: {
                                                            fontWeight: 400,
                                                            fontSize: '16px',
                                                            color: 'text.primary'
                                                        },
                                                        children: "FRW65646"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                                                sx: {
                                                    display: 'flex',
                                                    justifyContent: 'space-between'
                                                },
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                                        sx: {
                                                            fontWeight: 400,
                                                            fontSize: '16px',
                                                            color: 'grey.main'
                                                        },
                                                        children: "Производитель:"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                                        sx: {
                                                            fontWeight: 400,
                                                            fontSize: '16px',
                                                            color: 'text.primary'
                                                        },
                                                        children: "Россия"
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                        sx: {
                                            fontWeight: 600,
                                            fontSize: '15px',
                                            color: 'primary.main',
                                            lineHeight: '17px'
                                        },
                                        onClick: ()=>setOpen((prev)=>!prev
                                            )
                                        ,
                                        children: "Развернуть все характеристики"
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Grid, {
                        item: true,
                        sx: 12,
                        md: 6,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(section_title/* default */.Z, {
                                title: "С этим товаром рекомендуют"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
                                container: true,
                                children: product1.related.nodes.map((product, index)=>index < 3 ? /*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
                                        item: true,
                                        xs: 6,
                                        md: 4,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(product_item/* default */.Z, {
                                            product: product
                                        })
                                    }) : ''
                                )
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(similar_products, {
                title: "Похожие товары",
                products: product1.related.nodes
            })
        ]
    }));
};
/* harmony default export */ const product_card = (ProductCard);

// EXTERNAL MODULE: ./apollo-client.js
var apollo_client = __webpack_require__(9999);
// EXTERNAL MODULE: external "@apollo/client"
var client_ = __webpack_require__(9114);
;// CONCATENATED MODULE: ./GRAPHQL/product.js

const PRODUCT = client_.gql`
  query MyQuery($id: ID!) {
    product(id: $id, idType: SLUG) {
      databaseId
      slug
      name
      sku
      onSale
      image {
        sourceUrl
      }
      description
      galleryImages {
        nodes {
          sourceUrl
        }
      }
      productCategories(where: { orderby: TERM_GROUP }) {
        nodes {
          name
          slug
          databaseId
        }
      }
      ... on SimpleProduct {
        woocsRegularPrice
        woocsSalePrice
        stockQuantity
      }
      ... on VariableProduct {
        woocsRegularPrice
        woocsSalePrice
        variations(where: { stockStatus: IN_STOCK }) {
          nodes {
            stockQuantity
            databaseId
          }
        }
      }
      related(first: 6, where: { shuffle: true, stockStatus: IN_STOCK }) {
        nodes {
          databaseId
          slug
          name
          onSale
          image {
            sourceUrl
          }
          ... on SimpleProduct {
            woocsRegularPrice
            woocsSalePrice
          }
          ... on VariableProduct {
            woocsRegularPrice
            woocsSalePrice
            variations(where: { stockStatus: IN_STOCK }) {
              nodes {
                name
              }
            }
          }
        }
      }
    }
  }
`;

// EXTERNAL MODULE: ./GRAPHQL/categories.js
var GRAPHQL_categories = __webpack_require__(9589);
;// CONCATENATED MODULE: ./pages/product/[slug].js








function Product({ product , categories  }) {
    const breadcrumbs = [
        {
            name: 'Главная',
            slug: '/'
        },
        {
            name: product.name,
            slug: product.slug
        }, 
    ];
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(layout/* default */.Z, {
        categories: categories,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(Breadcrumbs_breadcrumbs/* default */.Z, {
                breadcrumbs: breadcrumbs
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(product_card, {
                product: product
            })
        ]
    }));
};
async function getServerSideProps({ params  }) {
    const categories = await apollo_client/* client.query */.L.query({
        query: GRAPHQL_categories/* CATEGORIES */.a
    });
    const product = await apollo_client/* client.query */.L.query({
        query: PRODUCT,
        variables: {
            id: params.slug
        }
    });
    return {
        props: {
            product: product?.data?.product,
            categories: categories?.data?.productCategories?.nodes
        }
    };
}


/***/ }),

/***/ 9114:
/***/ ((module) => {

module.exports = require("@apollo/client");

/***/ }),

/***/ 5692:
/***/ ((module) => {

module.exports = require("@mui/material");

/***/ }),

/***/ 9868:
/***/ ((module) => {

module.exports = require("@mui/material/useMediaQuery");

/***/ }),

/***/ 562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 8028:
/***/ ((module) => {

module.exports = require("next/dist/server/image-config.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 4365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 3018:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/to-base-64.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 6405:
/***/ ((module) => {

module.exports = require("react-dom");

/***/ }),

/***/ 9585:
/***/ ((module) => {

module.exports = require("react-image-gallery");

/***/ }),

/***/ 6022:
/***/ ((module) => {

module.exports = require("react-redux");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [730,61,278,925,667,428], () => (__webpack_exec__(1639)));
module.exports = __webpack_exports__;

})();