export const brands = [
  {
    id: 0,
    image: '/brand.png',
    slug: '/catalog'
  },
  {
    id: 1,
    image: '/brand.png',
    slug: '/catalog'
  },
  {
    id: 2,
    image: '/brand.png',
    slug: '/catalog'
  },
  {
    id: 3,
    image: '/brand.png',
    slug: '/catalog'
  },
  {
    id: 4,
    image: '/brand.png',
    slug: '/catalog'
  },
  {
    id: 5,
    image: '/brand.png',
    slug: '/catalog'
  },
  {
    id: 6,
    image: '/brand.png',
    slug: '/catalog'
  },
  {
    id: 7,
    image: '/brand.png',
    slug: '/catalog'
  },
  {
    id: 8,
    image: '/brand.png',
    slug: '/catalog'
  },
  {
    id: 9,
    image: '/brand.png',
    slug: '/catalog'
  },
  {
    id: 10,
    image: '/brand.png',
    slug: '/catalog'
  },
  {
    id: 11,
    image: '/brand.png',
    slug: '/catalog'
  },
  {
    id: 12,
    image: '/brand.png',
    slug: '/catalog'
  },
  {
    id: 13,
    image: '/brand.png',
    slug: '/catalog'
  },
  {
    id: 14,
    image: '/brand.png',
    slug: '/catalog'
  },
  {
    id: 15,
    image: '/brand.png',
    slug: '/catalog'
  },
]