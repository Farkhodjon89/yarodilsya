export const categoriesBanners = [
  {
    id: 0,
    image: '/banners/Подгузники.jpg',
    mobImage: '/banners/ПодгузникиМоб.png'
  },
  {
    id: 1,
    image: '/banners/Подгузникитрусики.jpg',
    mobImage: '/banners/ПодгузникиТрусикиМоб.png'
  },
  {
    id: 2,
    image: '/banners/Детскоепитание.jpg',
    mobImage: '/banners/ПодгузникиМоб.png'
  },
  {
    id: 3,
    image: '/banners/Одеждадлямалышей.jpg',
    mobImage: '/banners/ПодгузникиТрусикиМоб.png'
  },
  {
    id: 4,
    image: '/banners/Стульчикидлякормления.jpg',
    mobImage: '/banners/ПодгузникиМоб.png'
  },
  {
    id: 5,
    image: '/banners/Одеждадлямалышей.jpg',
    mobImage: '/banners/ПодгузникиТрусикиМоб.png'
  },

]