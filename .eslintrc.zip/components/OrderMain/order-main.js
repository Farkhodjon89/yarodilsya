import React from 'react';

const OrderMain = () => {
  return (
      <div>

      </div>
  );
};

export default OrderMain;