module.exports = {
  reactStrictMode: true,
  images: {
    domains: ['kids-planet.billz.work'],
  },
  env: {
    WP_URL: 'https://kids-planet.billz.work',
    GRAPHQL: 'https://kids-planet.billz.work/graphql',
    CONSUMER_KEY: 'ck_ed4f0d99e580b886ac7582d4112b2d46cda896f5',
    CONSUMER_SECRET: 'cs_4827030eb0fef53488e5b2b778cc9821440ccec1',
    WP_TOKEN: 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJodHRwczovL2tpZHMtcGxhbmV0LmJpbGx6LndvcmsiLCJpYXQiOjE2MDQ2NjMwMDUsIm5iZiI6MTYwNDY2MzAwNSwiZXhwIjoxNzYyNDI5NDIwLCJkYXRhIjp7InVzZXIiOnsiaWQiOiIxIn19fQ.EfOdjLOAu78KDqvIdwTzhYJABoHXtXQPUzat26dx_Dk'
  },
}
