"use strict";
exports.id = 158;
exports.ids = [158];
exports.modules = {

/***/ 6158:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ NewProductsList_Product)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(5692);
// EXTERNAL MODULE: external "@mui/system"
var system_ = __webpack_require__(7986);
// EXTERNAL MODULE: ./components/Link.js
var Link = __webpack_require__(4373);
// EXTERNAL MODULE: ./components/NewSetQuantity.js + 1 modules
var NewSetQuantity = __webpack_require__(9987);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(6022);
// EXTERNAL MODULE: ./redux/actions/cart.js
var actions_cart = __webpack_require__(6613);
// EXTERNAL MODULE: ./utility/formatPrice.js
var formatPrice = __webpack_require__(1770);
;// CONCATENATED MODULE: ./utility/getDiscount.js
const getDiscount = (price, salePrice)=>{
    const finalPrice = 100 * (price - salePrice) / price;
    return `-${finalPrice}%`;
};

;// CONCATENATED MODULE: ./components/NewProductsList/Product.js











const Product = ({ product  })=>{
    const dispatch = (0,external_react_redux_.useDispatch)();
    const cart = (0,external_react_redux_.useSelector)((state)=>state.cart
    );
    const { 0: quantity , 1: setQuantity  } = (0,external_react_.useState)(1);
    const alreadyAddedToCart = !!cart.find((item)=>item.selectedId === product.databaseId
    );
    const quantityInCart = cart.find((item)=>item.selectedId === product.databaseId
    )?.selectedQuantity;
    (0,external_react_.useEffect)(()=>{
        if (quantityInCart) {
            setQuantity(quantityInCart);
        }
    }, [
        quantityInCart
    ]);
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(system_.Box, {
        sx: {
            display: 'flex',
            height: '100%',
            flexDirection: 'column',
            p: {
                xs: 0,
                lg: 1
            },
            border: '2px solid transparent',
            borderRadius: '8px',
            '&:hover': {
                border: {
                    xs: 'none',
                    lg: '2px solid #F2F2F2'
                }
            }
        },
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Link/* default */.Z, {
                href: `/product/${product.slug}`,
                sx: {
                    display: 'flex',
                    height: '100%',
                    flexDirection: 'column'
                },
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(system_.Box, {
                        position: "relative",
                        width: "100%",
                        height: {
                            xs: 165,
                            lg: 200
                        },
                        borderRadius: "8px",
                        overflow: "hidden",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                                alt: product?.name,
                                src: product?.image?.sourceUrl,
                                layout: "fill"
                            }),
                            product?.onSale && /*#__PURE__*/ jsx_runtime_.jsx(system_.Box, {
                                position: "absolute",
                                top: 10,
                                left: 10,
                                bgcolor: "#FF3030",
                                borderRadius: "8px",
                                sx: {
                                    color: 'common.white',
                                    fontWeight: 700,
                                    fontSize: 13,
                                    lineHeight: '18px',
                                    filter: 'drop-shadow(0px 4px 4px rgba(0, 0, 0, 0.25))',
                                    px: 0.5
                                },
                                children: getDiscount(product?.woocsRegularPrice, product?.woocsSalePrice)
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(system_.Box, {
                        sx: {
                            color: 'grey.main',
                            display: '-webkit-box',
                            WebkitBoxOrient: 'vertical',
                            WebkitLineClamp: '3',
                            textOverflow: 'ellipsis',
                            overflow: 'hidden',
                            mt: 0.5,
                            mb: {
                                xs: 2,
                                lg: 5
                            }
                        },
                        children: product?.name
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(system_.Box, {
                        sx: {
                            fontSize: {
                                xs: 15,
                                lg: 19
                            },
                            lineHeight: {
                                xs: '20px',
                                lg: '26px'
                            },
                            fontWeight: 600,
                            color: 'text.primary',
                            mt: 'auto',
                            mb: 1
                        },
                        children: [
                            product?.onSale && /*#__PURE__*/ jsx_runtime_.jsx(system_.Box, {
                                sx: {
                                    fontSize: {
                                        xs: 15,
                                        lg: 16
                                    },
                                    lineHeight: {
                                        xs: '20px',
                                        lg: '22px'
                                    },
                                    textDecoration: 'line-through',
                                    textDecorationColor: 'red',
                                    color: '#606060',
                                    fontWeight: 400
                                },
                                children: (0,formatPrice/* formatPrice */.T)(product?.woocsRegularPrice)
                            }),
                            (0,formatPrice/* formatPrice */.T)(product?.onSale ? product?.woocsSalePrice : product?.woocsRegularPrice)
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(system_.Box, {
                display: "flex",
                alignItems: "center",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(NewSetQuantity/* default */.Z, {
                        quantity: quantity,
                        setQuantity: setQuantity,
                        max: product?.stockQuantity,
                        id: product?.databaseId,
                        mr: {
                            xs: 1,
                            lg: 1.5
                        }
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Button, {
                        fullWidth: true,
                        color: alreadyAddedToCart ? 'secondary' : 'primary',
                        onClick: alreadyAddedToCart ? ()=>dispatch((0,actions_cart/* removeFromCart */.h2)(product?.databaseId))
                         : ()=>dispatch((0,actions_cart/* addToCart */.Xq)(product, product?.databaseId, quantity))
                        ,
                        sx: {
                            color: 'common.white'
                        },
                        children: alreadyAddedToCart ? 'В корзине' : 'В корзину'
                    })
                ]
            })
        ]
    }));
};
/* harmony default export */ const NewProductsList_Product = (Product);


/***/ })

};
;