"use strict";
exports.id = 614;
exports.ids = [614];
exports.modules = {

/***/ 9614:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "r": () => (/* binding */ theme)
/* harmony export */ });
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8442);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mui_material_styles__WEBPACK_IMPORTED_MODULE_0__);

let theme = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_0__.createTheme)({
    components: {
        MuiTextField: {
            defaultProps: {
                label: 'white'
            }
        }
    },
    typography: {
        fontFamily: `'Open Sans', sans-serif`
    },
    palette: {
        primary: {
            main: '#EA56AE'
        },
        secondary: {
            main: '#49D6A3'
        },
        text: {
            primary: '#303030'
        },
        white: {
            main: '#fff'
        },
        grey: {
            main: '#606060'
        },
        btn: {
            main: '#1F3A8F'
        }
    },
    components: {
        MuiButton: {
            defaultProps: {
                disableElevation: true,
                disableFocusRipple: true,
                disableRipple: true,
                variant: 'contained'
            },
            styleOverrides: {
                root: {
                    textTransform: 'none',
                    borderRadius: '8px',
                    fontWeight: 600,
                    padding: '8px'
                }
            }
        }
    }
});
theme = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_0__.createTheme)(theme, {
    components: {
        MuiCssBaseline: {
            styleOverrides: {
                body: {
                    [theme.breakpoints.down('lg')]: {
                        fontSize: 13,
                        lineHeight: '17px'
                    },
                    [theme.breakpoints.up('lg')]: {
                        fontSize: 15,
                        lineHeight: '18px'
                    }
                }
            }
        },
        MuiButton: {
            styleOverrides: {
                root: {
                    [theme.breakpoints.down('lg')]: {
                        fontSize: 13,
                        lineHeight: '17px'
                    },
                    [theme.breakpoints.up('lg')]: {
                        fontSize: 16,
                        lineHeight: '22px'
                    }
                }
            }
        },
        MuiLink: {
            styleOverrides: {
                root: {
                    color: '#303030'
                }
            }
        }
    }
});


/***/ })

};
;