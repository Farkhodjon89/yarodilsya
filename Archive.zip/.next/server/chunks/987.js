"use strict";
exports.id = 987;
exports.ids = [987];
exports.modules = {

/***/ 9987:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ components_NewSetQuantity)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(5692);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./public/icons/QuantityArrow.js


const QuantityArrow = ()=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
        width: "25",
        height: "26",
        viewBox: "0 0 25 26",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("circle", {
                cx: "12.5",
                cy: "13",
                r: "12",
                fill: "white",
                stroke: "#E8E8E8"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                d: "M8.31973 12.612L14.8231 6.79372C15.0364 6.58535 15.3838 6.58393 15.5988 6.79055C15.8138 6.99715 15.8152 7.33381 15.6019 7.54217L9.49064 13.0101L15.6457 18.4279C15.8608 18.6345 15.8621 18.9712 15.6488 19.1795C15.4355 19.3879 15.0881 19.3893 14.8731 19.1827L8.32247 13.4176C8.20787 13.3075 8.15833 13.1611 8.16536 13.016C8.15767 12.8705 8.20599 12.7236 8.31973 12.612Z",
                fill: "#606060"
            })
        ]
    })
;
/* harmony default export */ const icons_QuantityArrow = (QuantityArrow);

// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(6022);
// EXTERNAL MODULE: ./redux/actions/cart.js
var cart = __webpack_require__(6613);
;// CONCATENATED MODULE: ./components/NewSetQuantity.js





const NewSetQuantity = ({ quantity , setQuantity , max , id , ml , mr , justifyContent ='space-between' ,  })=>{
    const dispatch = (0,external_react_redux_.useDispatch)();
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
        display: "flex",
        alignItems: "center",
        justifyContent: justifyContent,
        ml: ml,
        mr: mr,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                sx: {
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    cursor: 'pointer'
                },
                onClick: ()=>{
                    if (quantity !== 1) {
                        setQuantity(--quantity);
                        dispatch((0,cart/* quantityToCart */.nx)(id, quantity));
                    }
                },
                children: /*#__PURE__*/ jsx_runtime_.jsx(icons_QuantityArrow, {})
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                mx: 0.5,
                children: quantity
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                sx: {
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    cursor: 'pointer',
                    svg: {
                        transform: 'rotate(180deg)'
                    }
                },
                onClick: ()=>{
                    if (quantity !== max) {
                        setQuantity(++quantity);
                        dispatch((0,cart/* quantityToCart */.nx)(id, quantity));
                    }
                },
                children: /*#__PURE__*/ jsx_runtime_.jsx(icons_QuantityArrow, {})
            })
        ]
    }));
};
/* harmony default export */ const components_NewSetQuantity = (NewSetQuantity);


/***/ }),

/***/ 6613:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Xq": () => (/* binding */ addToCart),
/* harmony export */   "h2": () => (/* binding */ removeFromCart),
/* harmony export */   "nx": () => (/* binding */ quantityToCart)
/* harmony export */ });
/* unused harmony export removeAllFromCart */
/* harmony import */ var redux_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4001);

const addToCart = (product, selectedId, selectedQuantity)=>({
        type: redux_types__WEBPACK_IMPORTED_MODULE_0__/* .ADD */ .D7,
        payload: {
            ...product,
            selectedId,
            selectedQuantity
        }
    })
;
const removeFromCart = (selectedId)=>({
        type: redux_types__WEBPACK_IMPORTED_MODULE_0__/* .REMOVE */ .Dq,
        payload: selectedId
    })
;
const removeAllFromCart = ()=>({
        type: REMOVE_ALL
    })
;
const quantityToCart = (selectedId, selectedQuantity)=>({
        type: redux_types__WEBPACK_IMPORTED_MODULE_0__/* .QUANTITY */ .uT,
        payload: {
            selectedId,
            selectedQuantity
        }
    })
;


/***/ })

};
;