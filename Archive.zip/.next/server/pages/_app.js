"use strict";
(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 9773:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _app)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: external "@emotion/react"
const react_namespaceObject = require("@emotion/react");
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(5692);
// EXTERNAL MODULE: external "@emotion/cache"
var cache_ = __webpack_require__(1913);
var cache_default = /*#__PURE__*/__webpack_require__.n(cache_);
;// CONCATENATED MODULE: ./utility/createEmotionCache.js

const createEmotionCache = ()=>{
    return cache_default()({
        key: 'css'
    });
};
/* harmony default export */ const utility_createEmotionCache = (createEmotionCache);

// EXTERNAL MODULE: ./theme.js
var theme = __webpack_require__(9614);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(6022);
;// CONCATENATED MODULE: external "redux-persist"
const external_redux_persist_namespaceObject = require("redux-persist");
;// CONCATENATED MODULE: external "redux"
const external_redux_namespaceObject = require("redux");
;// CONCATENATED MODULE: external "redux-devtools-extension"
const external_redux_devtools_extension_namespaceObject = require("redux-devtools-extension");
;// CONCATENATED MODULE: external "redux-persist/lib/storage/createWebStorage"
const createWebStorage_namespaceObject = require("redux-persist/lib/storage/createWebStorage");
// EXTERNAL MODULE: ./redux/types.js
var types = __webpack_require__(4001);
;// CONCATENATED MODULE: ./redux/reducers/cart.js

const cart = (state = [], { type , payload  })=>{
    switch(type){
        case types/* ADD */.D7:
            return [
                payload,
                ...state
            ];
        case types/* REMOVE */.Dq:
            return state.filter((item)=>item.selectedId !== payload
            );
        case types/* REMOVE_ALL */.Vo:
            return [];
        case types/* QUANTITY */.uT:
            return state.map((item)=>item.selectedId === payload.selectedId ? {
                    ...item,
                    selectedQuantity: payload.selectedQuantity
                } : item
            );
        default:
            return state;
    }
};

;// CONCATENATED MODULE: ./redux/reducers/wishlist.js

const wishlist = (state = [], { type , payload  })=>{
    switch(type){
        case types/* ADD_TO_WISHLIST */.Cm:
            return [
                ...state,
                payload
            ];
        case types/* REMOVE_FROM_WISHLIST */.Ji:
            return state.filter((item)=>item.databaseId !== payload
            );
        default:
            return state;
    }
};

;// CONCATENATED MODULE: ./redux/reducers/purchaseAmount.js

let deliveryPrice = 15000;
const purchaseAmount = (state = {
    subtotal: {
        name: 'Подытог',
        price: 0
    },
    delivery: {
        name: 'Доставка',
        price: deliveryPrice
    },
    sale: {
        name: 'Скидка',
        price: 0
    },
    total: {
        name: 'Итого',
        price: 0
    }
}, { type , payload  })=>{
    switch(type){
        case types/* SUM */.iu:
            let subtotalPrice = 0;
            let salePrice = 0;
            payload.forEach((product)=>{
                subtotalPrice += product.woocsRegularPrice * product.selectedQuantity;
                salePrice += product.onSale ? product.woocsSalePrice * product.selectedQuantity : 0;
            });
            let totalPrice = subtotalPrice - salePrice + deliveryPrice;
            return {
                subtotal: {
                    name: 'Подытог',
                    price: subtotalPrice
                },
                delivery: {
                    name: 'Доставка',
                    price: deliveryPrice
                },
                sale: {
                    name: 'Скидка',
                    price: salePrice
                },
                total: {
                    name: 'Итого',
                    price: totalPrice
                }
            };
        default:
            return state;
    }
};

;// CONCATENATED MODULE: ./redux/reducers/index.js




const reducers = (0,external_redux_namespaceObject.combineReducers)({
    cart: cart,
    wishlist: wishlist,
    purchaseAmount: purchaseAmount
});
/* harmony default export */ const redux_reducers = (reducers);

;// CONCATENATED MODULE: ./redux/store.js






const createNoopStorage = ()=>{
    return {
        getItem (_key) {
            return Promise.resolve(null);
        },
        setItem (_key, value) {
            return Promise.resolve(value);
        },
        removeItem (_key) {
            return Promise.resolve();
        }
    };
};
const storage =  false ? 0 : createNoopStorage();
let store;
const persistConfig = {
    key: 'root',
    storage
};
const persistedReducer = (0,external_redux_persist_namespaceObject.persistReducer)(persistConfig, redux_reducers);
function makeStore(initialState) {
    return (0,external_redux_namespaceObject.createStore)(persistedReducer, initialState, (0,external_redux_devtools_extension_namespaceObject.composeWithDevTools)((0,external_redux_namespaceObject.applyMiddleware)()));
}
const initializeStore = (preloadedState)=>{
    let _store = store ?? makeStore(preloadedState);
    if (preloadedState && store) {
        _store = makeStore({
            ...store.getState(),
            ...preloadedState
        });
        store = undefined;
    }
    if (true) return _store;
    if (!store) store = _store;
    return _store;
};
function useStore(initialState) {
    const store1 = (0,external_react_.useMemo)(()=>initializeStore(initialState)
    , [
        initialState
    ]);
    return store1;
}

;// CONCATENATED MODULE: external "redux-persist/integration/react"
const integration_react_namespaceObject = require("redux-persist/integration/react");
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
;// CONCATENATED MODULE: ./components/Loader.js


const Loader = ()=>/*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
        width: "100vw",
        height: "100vh",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
            sx: {
                display: 'inline-block',
                position: 'relative',
                width: 80,
                height: 80,
                div: {
                    animation: 'lds-roller 1.2s cubic-bezier(0.5, 0, 0.5, 1) infinite',
                    transformOrigin: '40px 40px'
                },
                '& div:after': {
                    content: '""',
                    display: 'block',
                    position: 'absolute',
                    width: 7,
                    height: 7,
                    borderRadius: '50%',
                    bgcolor: 'primary.main',
                    margin: '-4px 0 0 -4px'
                },
                '& div:nth-of-type(1)': {
                    animationDelay: '-0.036s'
                },
                '& div:nth-of-type(1):after': {
                    top: 63,
                    left: 63
                },
                '& div:nth-of-type(2)': {
                    animationDelay: '-0.072s'
                },
                '& div:nth-of-type(2):after': {
                    top: 68,
                    left: 56
                },
                '& div:nth-of-type(3)': {
                    animationDelay: '-0.108s'
                },
                '& div:nth-of-type(3):after': {
                    top: 71,
                    left: 48
                },
                '& div:nth-of-type(4)': {
                    animationDelay: '-0.144s'
                },
                '& div:nth-of-type(4):after': {
                    top: 72,
                    left: 40
                },
                '& div:nth-of-type(5)': {
                    animationDelay: '-0.18s'
                },
                '& div:nth-of-type(5):after': {
                    top: 71,
                    left: 32
                },
                '& div:nth-of-type(6)': {
                    animationDelay: '-0.216s'
                },
                '& div:nth-of-type(6):after': {
                    top: 68,
                    left: 24
                },
                '& div:nth-of-type(7)': {
                    animationDelay: '-0.252s'
                },
                '& div:nth-of-type(7):after': {
                    top: 63,
                    left: 17
                },
                '& div:nth-of-type(8)': {
                    animationDelay: '-0.288s'
                },
                '& div:nth-of-type(8):after': {
                    top: 56,
                    left: 12
                },
                '@keyframes lds-roller': {
                    '0%': {
                        transform: 'rotate(0deg)'
                    },
                    '100%': {
                        transform: 'rotate(360deg)'
                    }
                }
            },
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {}),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {}),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {}),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {}),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {}),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {}),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {}),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {})
            ]
        })
    })
;
/* harmony default export */ const components_Loader = (Loader);

;// CONCATENATED MODULE: ./pages/_app.js














const clientSideEmotionCache = utility_createEmotionCache();
const MyApp = ({ Component , pageProps , emotionCache =clientSideEmotionCache ,  })=>{
    const store = useStore(pageProps.initialReduxState);
    const persistor = (0,external_redux_persist_namespaceObject.persistStore)(store, {}, function() {
        persistor.persist();
    });
    const router = (0,router_.useRouter)();
    const { 0: loading , 1: setLoading  } = (0,external_react_.useState)(false);
    (0,external_react_.useEffect)(()=>{
        const start = ()=>{
            setLoading(true);
        };
        const end = ()=>{
            setLoading(false);
        };
        router.events.on('routeChangeStart', start);
        router.events.on('routeChangeComplete', end);
        router.events.on('routeChangeError', end);
        return ()=>{
            router.events.off('routeChangeStart', start);
            router.events.off('routeChangeComplete', end);
            router.events.off('routeChangeError', end);
        };
    }, [
        router.events
    ]);
    return(/*#__PURE__*/ jsx_runtime_.jsx(react_namespaceObject.CacheProvider, {
        value: emotionCache,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.ThemeProvider, {
            theme: theme/* theme */.r,
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(material_.CssBaseline, {}),
                /*#__PURE__*/ jsx_runtime_.jsx(external_react_redux_.Provider, {
                    store: store,
                    children: /*#__PURE__*/ jsx_runtime_.jsx(integration_react_namespaceObject.PersistGate, {
                        loading: /*#__PURE__*/ jsx_runtime_.jsx(components_Loader, {}),
                        persistor: persistor,
                        children: loading || router.isFallback ? /*#__PURE__*/ jsx_runtime_.jsx(components_Loader, {}) : /*#__PURE__*/ (0,external_react_.createElement)(Component, {
                            ...pageProps,
                            key: router.asPath
                        })
                    })
                })
            ]
        })
    }));
};
/* harmony default export */ const _app = (MyApp);


/***/ }),

/***/ 4001:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "D7": () => (/* binding */ ADD),
/* harmony export */   "Dq": () => (/* binding */ REMOVE),
/* harmony export */   "Vo": () => (/* binding */ REMOVE_ALL),
/* harmony export */   "Cm": () => (/* binding */ ADD_TO_WISHLIST),
/* harmony export */   "Ji": () => (/* binding */ REMOVE_FROM_WISHLIST),
/* harmony export */   "uT": () => (/* binding */ QUANTITY),
/* harmony export */   "iu": () => (/* binding */ SUM)
/* harmony export */ });
const ADD = 'ADD';
const REMOVE = 'REMOVE';
const REMOVE_ALL = 'REMOVE_ALL';
const ADD_TO_WISHLIST = 'ADD_TO_WISHLIST';
const REMOVE_FROM_WISHLIST = 'REMOVE_FROM_WISHLIST';
const QUANTITY = 'QUANTITY';
const SUM = 'SUM';


/***/ }),

/***/ 1913:
/***/ ((module) => {

module.exports = require("@emotion/cache");

/***/ }),

/***/ 5692:
/***/ ((module) => {

module.exports = require("@mui/material");

/***/ }),

/***/ 8442:
/***/ ((module) => {

module.exports = require("@mui/material/styles");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 6022:
/***/ ((module) => {

module.exports = require("react-redux");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [614], () => (__webpack_exec__(9773)));
module.exports = __webpack_exports__;

})();