"use strict";
(() => {
var exports = {};
exports.id = 417;
exports.ids = [417];
exports.modules = {

/***/ 9674:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);


const Empty = ({ title =''  })=>{
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
        sx: {
            border: 1,
            borderRadius: 1,
            textAlign: 'center',
            py: {
                xs: 8,
                md: 16
            },
            my: 4
        },
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
            variant: "h6",
            children: [
                " ",
                title
            ]
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Empty);


/***/ }),

/***/ 4083:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Catalog),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./components/Layout/layout.js + 21 modules
var layout = __webpack_require__(9758);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(5692);
// EXTERNAL MODULE: ./apollo-client.js
var apollo_client = __webpack_require__(9999);
// EXTERNAL MODULE: external "@apollo/client"
var client_ = __webpack_require__(9114);
;// CONCATENATED MODULE: ./graphql/category.js

const CATEGORY = client_.gql`
  query MyQuery($id: ID!) {
    productCategory(id: $id, idType: SLUG) {
      databaseId
      name
      slug
      parent {
        node {
          databaseId
          name
          slug
        }
      }
      children(first: 100, where: { hideEmpty: true }) {
        nodes {
          databaseId
          name
          slug
        }
      }
    }
  }
`;

// EXTERNAL MODULE: ./graphql/categories.js
var graphql_categories = __webpack_require__(3610);
// EXTERNAL MODULE: ./graphql/products.js
var graphql_products = __webpack_require__(3552);
;// CONCATENATED MODULE: ./hooks/useFirstRender.js

const useFirstRender = ()=>{
    const firstRender = (0,external_react_.useRef)(true);
    (0,external_react_.useEffect)(()=>{
        firstRender.current = false;
    }, []);
    return firstRender.current;
};

// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
;// CONCATENATED MODULE: external "react-infinite-scroller"
const external_react_infinite_scroller_namespaceObject = require("react-infinite-scroller");
var external_react_infinite_scroller_default = /*#__PURE__*/__webpack_require__.n(external_react_infinite_scroller_namespaceObject);
// EXTERNAL MODULE: ./components/Breadcrumbs/breadcrumbs.js
var Breadcrumbs_breadcrumbs = __webpack_require__(741);
// EXTERNAL MODULE: ./components/Empty/empty.js
var empty = __webpack_require__(9674);
// EXTERNAL MODULE: ./components/SectionTitle/section-title.js
var section_title = __webpack_require__(2161);
// EXTERNAL MODULE: ./components/NewProductsList/index.js
var NewProductsList = __webpack_require__(733);
;// CONCATENATED MODULE: ./public/icons/Cross.js


const Cross = ()=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
        width: "24",
        height: "24",
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                d: "M18.75 5.25L5.25 18.75",
                stroke: "#888281",
                strokeWidth: "2",
                strokeLinecap: "round",
                strokeLinejoin: "round"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                d: "M18.75 18.75L5.25 5.25",
                stroke: "#888281",
                strokeWidth: "2",
                strokeLinecap: "round",
                strokeLinejoin: "round"
            })
        ]
    })
;
/* harmony default export */ const icons_Cross = (Cross);

;// CONCATENATED MODULE: ./utility/AddToArray.js
const AddToArray = (item1, array, setArray)=>{
    if (array.map((item)=>item.slug
    ).includes(item1.slug)) {
        const newItems = array.filter((el)=>el.slug !== item1.slug
        );
        setArray(newItems);
    } else if (array) {
        setArray([
            ...array,
            item1
        ]);
    }
};
/* harmony default export */ const utility_AddToArray = (AddToArray);

;// CONCATENATED MODULE: ./public/icons/ArrowDown.js


const ArrowDown = ()=>{
    return(/*#__PURE__*/ jsx_runtime_.jsx("svg", {
        width: "15",
        height: "10",
        viewBox: "0 0 15 10",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
            d: "M7.03755 9.79769L0.208873 2.10206C-0.0357703 1.84953 -0.0357703 1.43998 0.208873 1.18745C0.453498 0.934914 0.850429 0.934914 1.09507 1.18745L7.51249 8.41906L13.9299 1.18809C14.1745 0.935555 14.5715 0.935555 14.8161 1.18809C15.0607 1.44062 15.0607 1.85017 14.8161 2.10268L7.98741 9.79833C7.85699 9.93292 7.6841 9.99063 7.51311 9.98164C7.34148 9.99001 7.16861 9.93232 7.03755 9.79769Z",
            fill: "#606060"
        })
    }));
};
/* harmony default export */ const icons_ArrowDown = (ArrowDown);

;// CONCATENATED MODULE: ./components/Accordion/Accordion.js



const Accordion = ({ title ='' , children  })=>{
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Accordion, {
        defaultExpanded: true,
        disableGutters: true,
        square: true,
        sx: {
            boxShadow: 'none'
        },
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(material_.AccordionSummary, {
                expandIcon: /*#__PURE__*/ jsx_runtime_.jsx(material_.IconButton, {
                    "aria-label": "ArrowDown",
                    children: /*#__PURE__*/ jsx_runtime_.jsx(icons_ArrowDown, {})
                }),
                "aria-controls": title + 'content',
                id: title + 'header',
                sx: {
                    padding: 0,
                    fontWeight: 600
                },
                children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                    children: title
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(material_.AccordionDetails, {
                sx: {
                    px: 0,
                    maxHeight: 300,
                    overflowY: 'auto'
                },
                children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                    children: children
                })
            })
        ]
    }));
};
/* harmony default export */ const Accordion_Accordion = (Accordion);

;// CONCATENATED MODULE: ./components/Filters/Categories.js




const Categories = ({ category: category1  })=>{
    const router = (0,router_.useRouter)();
    return(/*#__PURE__*/ jsx_runtime_.jsx(Accordion_Accordion, {
        title: "Подгатегории",
        children: category1?.children?.nodes.map((category)=>/*#__PURE__*/ jsx_runtime_.jsx(material_.Button, {
                onClick: ()=>router.push({
                        pathname: '/catalog/' + category?.slug,
                        query: !!router?.query?.onSale ? {
                            onSale: true
                        } : undefined
                    })
                ,
                fullWidth: true,
                sx: {
                    textAlign: 'start',
                    justifyContent: 'start',
                    fontWeight: 400,
                    fontSize: 16,
                    lineHeight: '22px',
                    color: '#999999'
                },
                variant: "text",
                children: category.name
            }, category.databaseId)
        )
    }));
};
/* harmony default export */ const Filters_Categories = (Categories);

;// CONCATENATED MODULE: ./public/icons/Checked.js


const Checked = ()=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
        width: "18",
        height: "18",
        viewBox: "0 0 18 18",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                width: "18",
                height: "18",
                rx: "5",
                fill: "#EA56AE"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                d: "M8.99998 12.6994C8.80116 12.6994 8.60236 12.6106 8.45078 12.4334L3.6807 6.85242C3.37727 6.49741 3.37727 5.92181 3.6807 5.56694C3.98402 5.21206 4.4759 5.21206 4.77936 5.56694L8.99998 10.5053L13.2206 5.56711C13.5241 5.21224 14.0159 5.21224 14.3192 5.56711C14.6228 5.92198 14.6228 6.49758 14.3192 6.8526L9.54919 12.4335C9.39753 12.6108 9.19873 12.6994 8.99998 12.6994Z",
                fill: "white"
            })
        ]
    })
;
/* harmony default export */ const icons_Checked = (Checked);

;// CONCATENATED MODULE: ./public/icons/NotChecked.js


const NotChecked = ()=>/*#__PURE__*/ jsx_runtime_.jsx("svg", {
        width: "18",
        height: "18",
        viewBox: "0 0 18 18",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: /*#__PURE__*/ jsx_runtime_.jsx("rect", {
            x: "0.5",
            y: "0.5",
            width: "17",
            height: "17",
            rx: "4.5",
            fill: "white",
            stroke: "#999999"
        })
    })
;
/* harmony default export */ const icons_NotChecked = (NotChecked);

;// CONCATENATED MODULE: ./components/Filters/Colors.js







const Colors = ({ colors =[] , colorTerms , setColorTerms  })=>{
    const { 0: open , 1: setOpen  } = (0,external_react_.useState)(false);
    const { 0: data , 1: setData  } = (0,external_react_.useState)([]);
    const checkLength = colors.length !== data.length;
    (0,external_react_.useEffect)(()=>{
        if (open) {
            setData(colors);
        } else {
            setData(colors.slice(0, 4));
        }
    }, [
        colors,
        open
    ]);
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(Accordion_Accordion, {
        title: "Цвет",
        children: [
            data?.map((color1)=>/*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Button, {
                        fullWidth: true,
                        sx: {
                            fontWeight: '400',
                            justifyContent: 'start',
                            color: 'text.primary',
                            mb: 0.5
                        },
                        onClick: ()=>utility_AddToArray(color1, colorTerms, setColorTerms)
                        ,
                        variant: "text",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                                display: "flex",
                                alignItems: "center",
                                mr: 1,
                                children: colorTerms.map((color)=>color.slug
                                ).includes(color1.slug) ? /*#__PURE__*/ jsx_runtime_.jsx(icons_Checked, {}) : /*#__PURE__*/ jsx_runtime_.jsx(icons_NotChecked, {})
                            }),
                            color1.name
                        ]
                    })
                }, color1.databaseId)
            ),
            colors?.length > 4 && checkLength && /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                onClick: ()=>setOpen(true)
                ,
                sx: {
                    textAlign: 'center',
                    width: 110,
                    color: '#EA56AE',
                    backgroundColor: 'rgba(234, 86, 174, 0.1)',
                    borderRadius: '25px',
                    py: 0.5,
                    fontSize: 13,
                    lineHeight: '18px',
                    mx: 'auto',
                    cursor: 'pointer'
                },
                children: "Показать еще"
            })
        ]
    }));
};
/* harmony default export */ const Filters_Colors = (Colors);

// EXTERNAL MODULE: external "@mui/system"
var system_ = __webpack_require__(7986);
;// CONCATENATED MODULE: ./components/Filters/Sizes.js








const Sizes = ({ sizes =[] , sizeTerms , setSizeTerms  })=>{
    const { 0: open , 1: setOpen  } = (0,external_react_.useState)(false);
    const { 0: data , 1: setData  } = (0,external_react_.useState)([]);
    const checkLength = sizes.length !== data.length;
    (0,external_react_.useEffect)(()=>{
        if (open) {
            setData(sizes);
        } else {
            setData(sizes.slice(0, 4));
        }
    }, [
        sizes,
        open
    ]);
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(Accordion_Accordion, {
        title: "Размер",
        children: [
            data?.map((size1)=>/*#__PURE__*/ jsx_runtime_.jsx(system_.Box, {
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Button, {
                        fullWidth: true,
                        size: "large",
                        sx: {
                            fontWeight: '400',
                            justifyContent: 'start',
                            color: 'text.primary',
                            mb: 0.5
                        },
                        variant: "text",
                        onClick: ()=>utility_AddToArray(size1, sizeTerms, setSizeTerms)
                        ,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(system_.Box, {
                                display: "flex",
                                alignItems: "center",
                                mr: 1,
                                children: sizeTerms.map((size)=>size.slug
                                ).includes(size1.slug) ? /*#__PURE__*/ jsx_runtime_.jsx(icons_Checked, {}) : /*#__PURE__*/ jsx_runtime_.jsx(icons_NotChecked, {})
                            }),
                            size1.name
                        ]
                    })
                }, size1.databaseId)
            ),
            sizes?.length > 4 && checkLength && /*#__PURE__*/ jsx_runtime_.jsx(system_.Box, {
                onClick: ()=>setOpen(true)
                ,
                sx: {
                    textAlign: 'center',
                    width: 110,
                    color: '#EA56AE',
                    backgroundColor: 'rgba(234, 86, 174, 0.1)',
                    borderRadius: '25px',
                    py: 0.5,
                    fontSize: 13,
                    lineHeight: '18px',
                    mx: 'auto',
                    cursor: 'pointer'
                },
                children: "Показать еще"
            })
        ]
    }));
};
/* harmony default export */ const Filters_Sizes = (Sizes);

;// CONCATENATED MODULE: ./components/Filters/index.js




const Filters = ({ category , colors , colorTerms , setColorTerms , sizes , sizeTerms , setSizeTerms ,  })=>{
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(Filters_Categories, {
                category: category
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Filters_Colors, {
                colors: colors,
                colorTerms: colorTerms,
                setColorTerms: setColorTerms
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Filters_Sizes, {
                sizes: sizes,
                sizeTerms: sizeTerms,
                setSizeTerms: setSizeTerms
            })
        ]
    }));
};
/* harmony default export */ const components_Filters = (Filters);

;// CONCATENATED MODULE: ./public/icons/Filter.js


const Filter = ()=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
        width: "19",
        height: "16",
        viewBox: "0 0 19 16",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                d: "M17.3833 3.2423H5.82815C5.64788 3.2423 5.47499 3.17069 5.34752 3.04321C5.22005 2.91574 5.14844 2.74286 5.14844 2.56259C5.14844 2.38231 5.22005 2.20943 5.34752 2.08196C5.47499 1.95449 5.64788 1.88287 5.82815 1.88287H17.3833C17.5635 1.88287 17.7364 1.95449 17.8639 2.08196C17.9914 2.20943 18.063 2.38231 18.063 2.56259C18.063 2.74286 17.9914 2.91574 17.8639 3.04321C17.7364 3.17069 17.5635 3.2423 17.3833 3.2423Z",
                fill: "#EA56AE"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                d: "M3.10947 3.2423H1.07034C0.890066 3.2423 0.717179 3.17069 0.589708 3.04321C0.462237 2.91574 0.390625 2.74286 0.390625 2.56259C0.390625 2.38231 0.462237 2.20943 0.589708 2.08196C0.717179 1.95449 0.890066 1.88287 1.07034 1.88287H3.10947C3.28975 1.88287 3.46263 1.95449 3.5901 2.08196C3.71757 2.20943 3.78919 2.38231 3.78919 2.56259C3.78919 2.74286 3.71757 2.91574 3.5901 3.04321C3.46263 3.17069 3.28975 3.2423 3.10947 3.2423Z",
                fill: "#EA56AE"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                d: "M12.6254 8.68007H1.07034C0.890066 8.68007 0.717179 8.60846 0.589708 8.48099C0.462237 8.35352 0.390625 8.18063 0.390625 8.00036C0.390625 7.82009 0.462237 7.6472 0.589708 7.51973C0.717179 7.39226 0.890066 7.32065 1.07034 7.32065H12.6254C12.8057 7.32065 12.9786 7.39226 13.1061 7.51973C13.2335 7.6472 13.3052 7.82009 13.3052 8.00036C13.3052 8.18063 13.2335 8.35352 13.1061 8.48099C12.9786 8.60846 12.8057 8.68007 12.6254 8.68007Z",
                fill: "#EA56AE"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                d: "M5.82832 14.1178H1.07034C0.890066 14.1178 0.717179 14.0462 0.589708 13.9188C0.462237 13.7913 0.390625 13.6184 0.390625 13.4381C0.390625 13.2579 0.462237 13.085 0.589708 12.9575C0.717179 12.83 0.890066 12.7584 1.07034 12.7584H5.82832C6.00859 12.7584 6.18148 12.83 6.30895 12.9575C6.43642 13.085 6.50804 13.2579 6.50804 13.4381C6.50804 13.6184 6.43642 13.7913 6.30895 13.9188C6.18148 14.0462 6.00859 14.1178 5.82832 14.1178Z",
                fill: "#EA56AE"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                d: "M4.46883 4.60171C4.06552 4.60171 3.67128 4.48212 3.33594 4.25806C3.00061 4.03399 2.73925 3.71552 2.58491 3.34292C2.43057 2.97032 2.39019 2.56031 2.46887 2.16476C2.54755 1.76921 2.74176 1.40587 3.02694 1.12069C3.31212 0.835509 3.67546 0.6413 4.07101 0.56262C4.46656 0.483939 4.87657 0.524321 5.24917 0.678659C5.62177 0.832996 5.94024 1.09436 6.16431 1.42969C6.38837 1.76503 6.50796 2.15927 6.50796 2.56258C6.50796 3.10339 6.29313 3.62205 5.91071 4.00446C5.5283 4.38688 5.00964 4.60171 4.46883 4.60171ZM4.46883 1.88286C4.33439 1.88286 4.20298 1.92273 4.0912 1.99742C3.97942 2.0721 3.8923 2.17826 3.84085 2.30246C3.78941 2.42666 3.77595 2.56333 3.80217 2.69518C3.8284 2.82703 3.89314 2.94815 3.9882 3.0432C4.08326 3.13826 4.20437 3.203 4.33622 3.22923C4.46807 3.25545 4.60474 3.24199 4.72894 3.19055C4.85314 3.1391 4.9593 3.05198 5.03399 2.9402C5.10867 2.82843 5.14854 2.69701 5.14854 2.56258C5.14854 2.3823 5.07693 2.20942 4.94945 2.08195C4.82198 1.95448 4.6491 1.88286 4.46883 1.88286Z",
                fill: "#EA56AE"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                d: "M13.9845 10.0395C13.5811 10.0395 13.1869 9.91989 12.8516 9.69583C12.5162 9.47177 12.2549 9.1533 12.1005 8.78069C11.9462 8.40809 11.9058 7.99809 11.9845 7.60253C12.0632 7.20698 12.2574 6.84364 12.5426 6.55846C12.8277 6.27328 13.1911 6.07908 13.5866 6.00039C13.9822 5.92171 14.3922 5.9621 14.7648 6.11643C15.1374 6.27077 15.4559 6.53213 15.6799 6.86747C15.904 7.2028 16.0236 7.59705 16.0236 8.00035C16.0236 8.54116 15.8088 9.05983 15.4263 9.44224C15.0439 9.82465 14.5253 10.0395 13.9845 10.0395ZM13.9845 7.32064C13.85 7.32064 13.7186 7.3605 13.6068 7.43519C13.495 7.50988 13.4079 7.61603 13.3565 7.74024C13.305 7.86444 13.2916 8.00111 13.3178 8.13296C13.344 8.26481 13.4088 8.38592 13.5038 8.48098C13.5989 8.57604 13.72 8.64078 13.8518 8.667C13.9837 8.69323 14.1204 8.67977 14.2446 8.62832C14.3688 8.57688 14.4749 8.48976 14.5496 8.37798C14.6243 8.2662 14.6642 8.13478 14.6642 8.00035C14.6642 7.82008 14.5926 7.64719 14.4651 7.51972C14.3376 7.39225 14.1647 7.32064 13.9845 7.32064Z",
                fill: "#EA56AE"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                d: "M7.18758 15.4772C6.78427 15.4772 6.39003 15.3577 6.05469 15.1336C5.71936 14.9095 5.458 14.5911 5.30366 14.2185C5.14932 13.8458 5.10894 13.4358 5.18762 13.0403C5.2663 12.6447 5.46051 12.2814 5.74569 11.9962C6.03087 11.711 6.39421 11.5168 6.78976 11.4382C7.18531 11.3595 7.59532 11.3999 7.96792 11.5542C8.34052 11.7085 8.65899 11.9699 8.88306 12.3052C9.10712 12.6406 9.22671 13.0348 9.22671 13.4381C9.22671 13.9789 9.01188 14.4976 8.62946 14.88C8.24705 15.2624 7.72839 15.4772 7.18758 15.4772ZM7.18758 12.7584C7.05314 12.7584 6.92173 12.7983 6.80995 12.8729C6.69817 12.9476 6.61105 13.0538 6.5596 13.178C6.50816 13.3022 6.4947 13.4389 6.52092 13.5707C6.54715 13.7026 6.61189 13.8237 6.70695 13.9187C6.80201 14.0138 6.92312 14.0785 7.05497 14.1048C7.18682 14.131 7.32349 14.1175 7.44769 14.0661C7.57189 14.0146 7.67805 13.9275 7.75274 13.8157C7.82742 13.704 7.86729 13.5725 7.86729 13.4381C7.86729 13.2578 7.79568 13.085 7.6682 12.9575C7.54073 12.83 7.36785 12.7584 7.18758 12.7584Z",
                fill: "#EA56AE"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                d: "M17.3839 8.68007H15.3448C15.1645 8.68007 14.9916 8.60846 14.8641 8.48099C14.7367 8.35352 14.665 8.18063 14.665 8.00036C14.665 7.82009 14.7367 7.6472 14.8641 7.51973C14.9916 7.39226 15.1645 7.32065 15.3448 7.32065H17.3839C17.5642 7.32065 17.737 7.39226 17.8645 7.51973C17.992 7.6472 18.0636 7.82009 18.0636 8.00036C18.0636 8.18063 17.992 8.35352 17.8645 8.48099C17.737 8.60846 17.5642 8.68007 17.3839 8.68007Z",
                fill: "#EA56AE"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                d: "M17.3832 14.1178H8.5469C8.36663 14.1178 8.19374 14.0462 8.06627 13.9188C7.9388 13.7913 7.86719 13.6184 7.86719 13.4381C7.86719 13.2579 7.9388 13.085 8.06627 12.9575C8.19374 12.83 8.36663 12.7584 8.5469 12.7584H17.3832C17.5634 12.7584 17.7363 12.83 17.8638 12.9575C17.9913 13.085 18.0629 13.2579 18.0629 13.4381C18.0629 13.6184 17.9913 13.7913 17.8638 13.9188C17.7363 14.0462 17.5634 14.1178 17.3832 14.1178Z",
                fill: "#EA56AE"
            })
        ]
    })
;
/* harmony default export */ const icons_Filter = (Filter);

;// CONCATENATED MODULE: ./pages/catalog/[slug].js




















const first = 8;
const ButtonComponent = ({ key , action , name  })=>/*#__PURE__*/ jsx_runtime_.jsx(material_.Button, {
        variant: "contained",
        endIcon: /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
            borderRadius: "50%",
            backgroundColor: "common.white",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            p: 0.25,
            children: /*#__PURE__*/ jsx_runtime_.jsx(icons_Cross, {})
        }),
        onClick: action,
        sx: {
            fontWeight: 400,
            fontSize: 13,
            lineHeight: '18px',
            mr: 1,
            color: '#606060',
            backgroundColor: '#E8E8E8',
            py: 0.5,
            px: 1.5,
            borderRadius: '25px',
            '&:hover': {
                color: '#606060',
                backgroundColor: '#E8E8E8'
            }
        },
        children: name
    }, key)
;
function Catalog({ categories , category , initialData  }) {
    const router = (0,router_.useRouter)();
    const onSale = !!router?.query?.onSale;
    const onSearch = router?.query?.search;
    const firstRender = useFirstRender();
    const { 0: openMobileFilter , 1: setOpenMobileFilter  } = (0,external_react_.useState)(false);
    const { 0: filters , 1: setFilters  } = (0,external_react_.useState)([]);
    const { 0: colorTerms , 1: setColorTerms  } = (0,external_react_.useState)([]);
    const { 0: sizeTerms , 1: setSizeTerms  } = (0,external_react_.useState)([]);
    const { 0: sortBy , 1: setSortBy  } = (0,external_react_.useState)('');
    const { 0: data , 1: setData  } = (0,external_react_.useState)({
        products: initialData?.nodes || [],
        endCursor: initialData?.pageInfo?.endCursor,
        hasNextPage: !!initialData?.pageInfo?.hasNextPage,
        colors: initialData?.activeTerms?.paColors,
        sizes: initialData?.activeTerms?.paSizes,
        brands: initialData?.activeTerms?.paBrands
    });
    const breadcrumbs = [
        {
            databaseId: 'main',
            name: 'Главная',
            slug: '/'
        },
        ...category?.parent ? [
            {
                databaseId: category?.parent?.node?.databaseId,
                name: category?.parent?.node?.name,
                slug: '/catalog/' + category?.parent?.node?.slug
            }, 
        ] : [],
        {
            databaseId: category?.databaseId,
            name: category?.name,
            slug: '/catalog/' + category?.slug
        }, 
    ];
    const [loadData, { data: moreData , loading: loadingData  }] = (0,client_.useLazyQuery)(graphql_products/* PRODUCTS */.b, {
        client: apollo_client/* client */.L,
        fetchPolicy: 'network-only',
        notifyOnNetworkStatusChange: true,
        onCompleted: ()=>{
            setData((oldData)=>oldData && {
                    products: [
                        ...oldData?.products,
                        ...moreData?.products?.nodes
                    ],
                    endCursor: moreData?.products?.pageInfo?.endCursor,
                    hasNextPage: moreData?.products?.pageInfo?.hasNextPage,
                    colors: moreData?.products?.activeTerms?.paColors,
                    sizes: moreData?.products?.activeTerms?.paSizes
                }
            );
        }
    });
    const customLoadData = ()=>loadData({
            variables: {
                first,
                categories: category.slug === 'all' ? categories?.data?.productCategories?.nodes.map(({ slug  })=>slug
                ) : [
                    category.slug
                ],
                onSale: onSale,
                after: data?.endCursor || undefined,
                filters: filters.length ? filters : undefined,
                search: onSearch || undefined,
                orderBy: sortBy ? [
                    {
                        field: 'PRICE',
                        order: sortBy
                    }, 
                ] : undefined
            }
        })
    ;
    (0,external_react_.useEffect)(()=>{
        if (!firstRender) {
            setFilters([
                ...colorTerms.length ? [
                    {
                        taxonomy: 'PACOLOR',
                        terms: colorTerms.map((color)=>color.slug
                        )
                    }, 
                ] : [],
                ...sizeTerms.length ? [
                    {
                        taxonomy: 'PASIZE',
                        terms: sizeTerms.map((size)=>size.slug
                        )
                    }, 
                ] : [], 
            ]);
        }
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        colorTerms,
        sizeTerms
    ]);
    (0,external_react_.useEffect)(()=>{
        if (!firstRender) {
            setData({
                products: [],
                endCursor: '',
                hasNextPage: false,
                colors: [],
                sizes: []
            });
            customLoadData();
        }
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        filters
    ]);
    (0,external_react_.useEffect)(()=>{
        if (onSale) {
            setData({
                products: [],
                endCursor: '',
                hasNextPage: false,
                colors: [],
                sizes: []
            });
            customLoadData();
        }
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        onSale
    ]);
    (0,external_react_.useEffect)(()=>{
        if (onSearch) {
            setData({
                products: [],
                endCursor: '',
                hasNextPage: false,
                colors: [],
                sizes: []
            });
            customLoadData();
        }
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        onSearch
    ]);
    const sortByItems = [
        {
            value: 'new',
            name: 'Новинке'
        },
        {
            value: 'DESC',
            name: 'Цене ниже'
        },
        {
            value: 'ASC',
            name: 'Цене выше'
        },
        {
            value: 'sale',
            name: 'Скидкам'
        }, 
    ];
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(layout/* default */.Z, {
        categories: categories,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(Breadcrumbs_breadcrumbs/* default */.Z, {
                breadcrumbs: breadcrumbs
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(section_title/* default */.Z, {
                title: category?.name
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                display: {
                    xs: 'flex',
                    lg: 'none'
                },
                alignItems: "center",
                justifyContent: "space-between",
                mb: 2,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("select", {
                            name: "sort",
                            style: {
                                border: 'none',
                                outline: 'none'
                            },
                            onChange: (e)=>setSortBy(e.target.value)
                            ,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                    value: "",
                                    disabled: true,
                                    defaultValue: true,
                                    children: "Сортировать по:"
                                }),
                                sortByItems.map((item)=>/*#__PURE__*/ jsx_runtime_.jsx("option", {
                                        value: item.value,
                                        children: item.name
                                    }, item.name)
                                )
                            ]
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                        display: "flex",
                        alignItems: "center",
                        sx: {
                            svg: {
                                mr: 0.5
                            }
                        },
                        onClick: ()=>setOpenMobileFilter(true)
                        ,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(icons_Filter, {}),
                            " Фильтр"
                        ]
                    }),
                    openMobileFilter && /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                        sx: {
                            position: 'fixed',
                            top: 0,
                            left: 0,
                            right: 0,
                            bottom: 0,
                            width: '100%',
                            height: '100%',
                            bgcolor: 'common.white',
                            zIndex: 10000,
                            py: 2,
                            px: 3,
                            overflowY: 'auto'
                        },
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                                display: "flex",
                                alignItems: "center",
                                justifyContent: "space-between",
                                mb: 3,
                                fontWeight: 600,
                                fontSize: 17,
                                lineHeight: "23px",
                                children: [
                                    "Фильтр",
                                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                                        onClick: ()=>setOpenMobileFilter(false)
                                        ,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(icons_Cross, {})
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(components_Filters, {
                                category: category,
                                colors: data?.colors,
                                colorTerms: colorTerms,
                                setColorTerms: setColorTerms,
                                sizes: data?.sizes,
                                sizeTerms: sizeTerms,
                                setSizeTerms: setSizeTerms
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                                mt: 3
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(material_.Button, {
                                fullWidth: true,
                                onClick: ()=>setOpenMobileFilter(false)
                                ,
                                children: "Показать товары"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Grid, {
                container: true,
                spacing: {
                    xs: 2,
                    md: 4
                },
                sx: {
                    mb: 4
                },
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
                        item: true,
                        xs: 3,
                        sx: {
                            display: {
                                xs: 'none',
                                md: 'block'
                            }
                        },
                        children: /*#__PURE__*/ jsx_runtime_.jsx(components_Filters, {
                            category: category,
                            colors: data?.colors,
                            colorTerms: colorTerms,
                            setColorTerms: setColorTerms,
                            sizes: data?.sizes,
                            sizeTerms: sizeTerms,
                            setSizeTerms: setSizeTerms
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Grid, {
                        item: true,
                        xs: 12,
                        md: 9,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                                display: {
                                    xs: 'none',
                                    lg: 'block'
                                },
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                                        sx: {
                                            display: 'flex',
                                            alignItems: 'center',
                                            mb: 2,
                                            div: {
                                                '&:first-of-type': {
                                                    color: '#303030'
                                                },
                                                color: '#999999',
                                                mr: 2,
                                                cursor: 'pointer'
                                            }
                                        },
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                                                children: "Cортировать по:"
                                            }),
                                            sortByItems.map((item)=>/*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                                                    onClick: ()=>setSortBy(item.value)
                                                    ,
                                                    sx: {
                                                        textDecoration: sortBy === item.value ? 'underline' : 'none'
                                                    },
                                                    children: item.name
                                                }, item.name)
                                            )
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                                        sx: {
                                            display: 'flex',
                                            flexWrap: 'wrap',
                                            mb: 2
                                        },
                                        children: [
                                            colorTerms.map((color)=>/*#__PURE__*/ jsx_runtime_.jsx(ButtonComponent, {
                                                    name: color.name,
                                                    action: ()=>utility_AddToArray(color, colorTerms, setColorTerms)
                                                }, color.databaseId)
                                            ),
                                            sizeTerms.map((size)=>/*#__PURE__*/ jsx_runtime_.jsx(ButtonComponent, {
                                                    name: size.name,
                                                    action: ()=>utility_AddToArray(size, sizeTerms, setSizeTerms)
                                                }, size.databaseId)
                                            )
                                        ]
                                    })
                                ]
                            }),
                            loadingData && !data?.products?.length ? /*#__PURE__*/ jsx_runtime_.jsx(material_.Skeleton, {}) : data?.products?.length ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)((external_react_infinite_scroller_default()), {
                                pageStart: 0,
                                loadMore: customLoadData,
                                hasMore: data?.hasNextPage,
                                initialLoad: false,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(NewProductsList/* default */.Z, {
                                        data: data?.products
                                    }),
                                    loadingData && /*#__PURE__*/ jsx_runtime_.jsx(material_.Skeleton, {})
                                ]
                            }) : /*#__PURE__*/ jsx_runtime_.jsx(empty/* default */.Z, {
                                title: "Товары не найдены"
                            })
                        ]
                    })
                ]
            })
        ]
    }));
};
async function getServerSideProps({ params  }) {
    const categories = await apollo_client/* client.query */.L.query({
        query: graphql_categories/* CATEGORIES */.a
    });
    let category;
    if (params.slug === 'all') {
        category = {
            data: {
                productCategory: {
                    databaseId: 'all',
                    name: 'Каталог',
                    slug: 'all',
                    children: {
                        nodes: categories?.data?.productCategories?.nodes
                    }
                }
            }
        };
    } else {
        category = await apollo_client/* client.query */.L.query({
            query: CATEGORY,
            variables: {
                id: params.slug
            }
        });
    }
    const products = await apollo_client/* client.query */.L.query({
        query: graphql_products/* PRODUCTS */.b,
        variables: {
            first,
            categories: params.slug === 'all' ? categories?.data?.productCategories?.nodes.map(({ slug  })=>slug
            ) : [
                params.slug
            ]
        }
    });
    return {
        props: {
            categories: categories?.data?.productCategories?.nodes,
            category: category?.data?.productCategory,
            initialData: products?.data?.products
        }
    };
}


/***/ }),

/***/ 9114:
/***/ ((module) => {

module.exports = require("@apollo/client");

/***/ }),

/***/ 7812:
/***/ ((module) => {

module.exports = require("@apollo/client/link/context");

/***/ }),

/***/ 5692:
/***/ ((module) => {

module.exports = require("@mui/material");

/***/ }),

/***/ 9868:
/***/ ((module) => {

module.exports = require("@mui/material/useMediaQuery");

/***/ }),

/***/ 7986:
/***/ ((module) => {

module.exports = require("@mui/system");

/***/ }),

/***/ 562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 8028:
/***/ ((module) => {

module.exports = require("next/dist/server/image-config.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 4365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 3018:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/to-base-64.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 6022:
/***/ ((module) => {

module.exports = require("react-redux");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [730,61,932,987,158,689], () => (__webpack_exec__(4083)));
module.exports = __webpack_exports__;

})();