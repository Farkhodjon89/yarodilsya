"use strict";
(() => {
var exports = {};
exports.id = 222;
exports.ids = [222];
exports.modules = {

/***/ 7341:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _OrderDetails_order_details__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(852);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5641);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_7__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_4__]);
react_hook_form__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];








const inputs = [
    {
        name: 'name',
        label: 'Имя',
        required: true
    },
    {
        name: 'surname',
        label: 'Фамилия',
        required: true
    },
    {
        name: 'phone',
        label: 'Номер телефона',
        required: true
    },
    {
        name: 'city',
        label: 'Город',
        required: true
    },
    {
        name: 'district',
        label: 'Район',
        required: true
    },
    {
        name: 'street',
        label: 'Улица',
        required: true
    },
    {
        name: 'house',
        label: 'Дом',
        required: true
    },
    {
        name: 'flat',
        label: 'Квартира',
        required: false
    },
    {
        name: 'entrance',
        label: 'Подъезд',
        required: false
    },
    {
        name: 'floor',
        label: 'Этаж',
        required: false
    }, 
];
const CheckoutMain = ()=>{
    const cart = (0,react_redux__WEBPACK_IMPORTED_MODULE_6__.useSelector)((state)=>state.cart
    );
    const purchaseAmount = (0,react_redux__WEBPACK_IMPORTED_MODULE_6__.useSelector)((state)=>state.purchaseAmount
    );
    const deliveryCost = 'flat_rate';
    const selectMethod = 'cash';
    const { register , handleSubmit  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_4__.useForm)();
    const { 0: isLoading , 1: setIsLoading  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_5__.useRouter)();
    const lineItems = [];
    for (const product of cart){
        lineItems.push({
            product_id: product.databaseId,
            name: product.name,
            price: product.onSale ? product.woocsSalePrice : product.woocsRegularPrice,
            quantity: product.selectedQuantity,
            variation_id: product.variations && product.selectedProductId
        });
    }
    const sendInfo = async (data)=>{
        setIsLoading(true);
        const orderData = {
            set_paid: false,
            currency: 'UZS',
            status: selectMethod === 'cash' ? 'processing' : 'pending',
            total: purchaseAmount?.total?.price,
            payment_method_title: selectMethod === 'cash' ? 'Оплата наличными или картой при доставке' : selectMethod,
            line_items: lineItems,
            billing: {
                address_1: `${data.district} ${data.street} ${data.house} ${data.flat} ${data.entrance} ${data.floor}`,
                city: data.city,
                first_name: data.name,
                last_name: data.surname,
                phone: data.phone
            },
            shipping_lines: [
                {
                    method_id: deliveryCost === 'flat_rate' ? 'flat_rate' : 'local_pickup',
                    method_title: deliveryCost === 'flat_rate' ? 'Доставка курьером' : 'Самовывоз из магазина',
                    total: deliveryCost === 'flat_rate' ? purchaseAmount.delivery.price.toString() : ''
                }, 
            ],
            customer_note: data.comment
        };
        const response = await axios__WEBPACK_IMPORTED_MODULE_7___default().post('/api/order', {
            order: orderData
        });
        if (response.data.status) {
            window.location.assign(`/order/${response.data.order.order_key}`);
            localStorage.clear();
        } else {
            alert(response.data.message);
            router.reload();
        }
        setIsLoading(false);
    };
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
        sx: {
            width: '100%',
            display: {
                xs: 'block',
                md: 'flex'
            },
            justifyContent: 'space-between',
            mb: 6
        },
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
                sx: {
                    width: {
                        xs: '100%',
                        md: '68%'
                    }
                },
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
                        sx: {
                            display: 'flex',
                            justifyContent: 'space-between',
                            flexWrap: 'wrap',
                            padding: '25px 20px',
                            border: '1px solid #E8E8E8',
                            borderRadius: '8px'
                        },
                        children: inputs.map((item)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.TextField, {
                                name: item.name,
                                label: item.label,
                                variant: "outlined",
                                required: item.required,
                                sx: {
                                    '& .MuiInputBase-root': {
                                        borderRadius: '8px'
                                    },
                                    '& .MuiOutlinedInput-notchedOutline': {
                                        boxShadow: '0px 4px 40px rgba(0, 0, 0, 0.1)',
                                        border: '1px solid #E8E8E8'
                                    },
                                    width: {
                                        xs: '100%',
                                        lg: '49%'
                                    },
                                    mb: 2
                                },
                                ...register(item.name, {
                                    required: item.required
                                })
                            }, item.name)
                        )
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.TextareaAutosize, {
                        "aria-label": "textarea",
                        name: "comment",
                        placeholder: "Комментарий к заказу (необязательно)",
                        style: {
                            width: '100%',
                            height: '180px',
                            padding: '20px',
                            border: '1px solid #E8E8E8',
                            borderRadius: '8px',
                            marginTop: '35px',
                            fontSize: '16px',
                            fontWeight: 400,
                            color: '#999999',
                            resize: 'none'
                        },
                        ...register('comment')
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Button, {
                        variant: "contained",
                        sx: {
                            width: {
                                xs: '100%',
                                md: '200px'
                            },
                            height: {
                                xs: '45px',
                                md: '50px'
                            },
                            borderRadius: '8px',
                            display: 'flex',
                            justifyContent: 'center',
                            alignItems: 'center',
                            margin: '35px 0'
                        },
                        disabled: isLoading,
                        onClick: handleSubmit(sendInfo),
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                            sx: {
                                fontSize: '18px',
                                fontWeight: 500,
                                lineHeight: '24px'
                            },
                            children: "ЗАКАЗАТЬ"
                        })
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
                sx: {
                    width: {
                        xs: '100%',
                        md: '30%'
                    }
                },
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_OrderDetails_order_details__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {})
                })
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CheckoutMain);

});

/***/ }),

/***/ 8283:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Checkout),
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_Layout_layout__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9758);
/* harmony import */ var _components_Breadcrumbs_breadcrumbs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(741);
/* harmony import */ var _components_SectionTitle_section_title__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2161);
/* harmony import */ var _components_Checkout_checkout__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7341);
/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9999);
/* harmony import */ var _graphql_categories__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3610);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_Checkout_checkout__WEBPACK_IMPORTED_MODULE_5__]);
_components_Checkout_checkout__WEBPACK_IMPORTED_MODULE_5__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];








function Checkout({ categories  }) {
    const breadcrumbs = [
        {
            name: 'Главная',
            slug: '/'
        },
        {
            name: 'Оформление заказа',
            slug: `/checkout`
        }, 
    ];
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_Layout_layout__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
        categories: categories,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Breadcrumbs_breadcrumbs__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                breadcrumbs: breadcrumbs
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_SectionTitle_section_title__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                title: "Оформление заказа"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Checkout_checkout__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {})
        ]
    }));
};
async function getStaticProps() {
    const categories = await _apollo_client__WEBPACK_IMPORTED_MODULE_6__/* .client.query */ .L.query({
        query: _graphql_categories__WEBPACK_IMPORTED_MODULE_7__/* .CATEGORIES */ .a
    });
    return {
        props: {
            categories: categories?.data?.productCategories?.nodes
        }
    };
}

});

/***/ }),

/***/ 9114:
/***/ ((module) => {

module.exports = require("@apollo/client");

/***/ }),

/***/ 7812:
/***/ ((module) => {

module.exports = require("@apollo/client/link/context");

/***/ }),

/***/ 5692:
/***/ ((module) => {

module.exports = require("@mui/material");

/***/ }),

/***/ 9868:
/***/ ((module) => {

module.exports = require("@mui/material/useMediaQuery");

/***/ }),

/***/ 2167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 8028:
/***/ ((module) => {

module.exports = require("next/dist/server/image-config.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 4365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 3018:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/to-base-64.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 6022:
/***/ ((module) => {

module.exports = require("react-redux");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 5641:
/***/ ((module) => {

module.exports = import("react-hook-form");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [730,61,932,620], () => (__webpack_exec__(8283)));
module.exports = __webpack_exports__;

})();