"use strict";
(() => {
var exports = {};
exports.id = 405;
exports.ids = [405];
exports.modules = {

/***/ 3235:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ pages),
  "getStaticProps": () => (/* binding */ getStaticProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./components/Layout/layout.js + 21 modules
var layout = __webpack_require__(9758);
;// CONCATENATED MODULE: ./brands.js
const brands = [
    {
        id: 0,
        image: '/brand.png',
        slug: '/catalog'
    },
    {
        id: 1,
        image: '/brand.png',
        slug: '/catalog'
    },
    {
        id: 2,
        image: '/brand.png',
        slug: '/catalog'
    },
    {
        id: 3,
        image: '/brand.png',
        slug: '/catalog'
    },
    {
        id: 4,
        image: '/brand.png',
        slug: '/catalog'
    },
    {
        id: 5,
        image: '/brand.png',
        slug: '/catalog'
    },
    {
        id: 6,
        image: '/brand.png',
        slug: '/catalog'
    },
    {
        id: 7,
        image: '/brand.png',
        slug: '/catalog'
    },
    {
        id: 8,
        image: '/brand.png',
        slug: '/catalog'
    },
    {
        id: 9,
        image: '/brand.png',
        slug: '/catalog'
    },
    {
        id: 10,
        image: '/brand.png',
        slug: '/catalog'
    },
    {
        id: 11,
        image: '/brand.png',
        slug: '/catalog'
    },
    {
        id: 12,
        image: '/brand.png',
        slug: '/catalog'
    },
    {
        id: 13,
        image: '/brand.png',
        slug: '/catalog'
    },
    {
        id: 14,
        image: '/brand.png',
        slug: '/catalog'
    },
    {
        id: 15,
        image: '/brand.png',
        slug: '/catalog'
    }, 
];

;// CONCATENATED MODULE: ./slider-banners.js
const sliderBanners = [
    {
        id: 0,
        image: '/banners/Slider.png',
        mobImage: '/banners/SliderMob.png'
    },
    {
        id: 1,
        image: '/banners/Slider.png',
        mobImage: '/banners/SliderMob.png'
    }
];

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(5692);
// EXTERNAL MODULE: ./components/SectionTitle/section-title.js
var section_title = __webpack_require__(2161);
// EXTERNAL MODULE: ./components/Link.js
var Link = __webpack_require__(4373);
// EXTERNAL MODULE: external "@mui/system"
var system_ = __webpack_require__(7986);
;// CONCATENATED MODULE: ./components/Categories/categories.js







const data = [
    '/',
    '/',
    '/',
    '/'
];
const Categories = ({ title  })=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(section_title/* default */.Z, {
                title: title
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
                container: true,
                spacing: {
                    xs: 1,
                    lg: 2.5
                },
                children: data.map((item, index)=>/*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
                        item: true,
                        xs: 6,
                        lg: 3,
                        children: /*#__PURE__*/ jsx_runtime_.jsx(Link/* default */.Z, {
                            href: item,
                            sx: {
                                position: 'relative',
                                display: 'block',
                                width: '100%',
                                height: {
                                    xs: 90,
                                    lg: 160
                                }
                            },
                            children: /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                                alt: "categories",
                                src: `/news/${index + 1}.webp`,
                                layout: "fill"
                            })
                        })
                    }, index)
                )
            })
        ]
    })
;
/* harmony default export */ const Categories_categories = (Categories);

;// CONCATENATED MODULE: ./components/Banners/banners.js



const Banners = ({ background  })=>{
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
        sx: {
            display: 'flex',
            width: '100%',
            flexDirection: {
                xs: 'column',
                lg: 'row'
            },
            justifyContent: 'space-between',
            alignItems: {
                xs: 'center',
                lg: 'none'
            },
            marginBottom: '40px',
            cursor: 'pointer'
        },
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(material_.Paper, {
                sx: {
                    background: background,
                    width: {
                        xs: '100%',
                        lg: '49.5%'
                    },
                    height: {
                        xs: '90px',
                        md: '200px'
                    },
                    maxWidth: '640px',
                    borderRadius: '8px'
                },
                square: true
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(material_.Paper, {
                sx: {
                    display: {
                        xs: 'none',
                        md: 'block'
                    },
                    background: background,
                    width: {
                        xs: '100%',
                        lg: '49.5%'
                    },
                    height: '200px',
                    maxWidth: '640px',
                    transform: 'matrix(1, 0, 0, -1, 0, 0);',
                    borderRadius: '8px'
                },
                square: true
            })
        ]
    }));
};
/* harmony default export */ const banners = (Banners);

// EXTERNAL MODULE: ./apollo-client.js
var apollo_client = __webpack_require__(9999);
// EXTERNAL MODULE: ./graphql/categories.js
var graphql_categories = __webpack_require__(3610);
// EXTERNAL MODULE: ./graphql/products.js
var graphql_products = __webpack_require__(3552);
;// CONCATENATED MODULE: external "react-slick"
const external_react_slick_namespaceObject = require("react-slick");
var external_react_slick_default = /*#__PURE__*/__webpack_require__.n(external_react_slick_namespaceObject);
;// CONCATENATED MODULE: ./public/icons/SliderArrow.js


const SliderArrow = ()=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
        width: "36",
        height: "36",
        viewBox: "0 0 36 36",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("circle", {
                r: "17",
                transform: "matrix(0 -1 -1 0 18.1704 17.6266)",
                fill: "white",
                stroke: "#E8E8E8"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                d: "M12.1704 17.6294C12.1704 17.3607 12.2905 17.092 12.53 16.8871L20.0732 10.4399C20.5531 10.0298 21.331 10.0298 21.8107 10.4399C22.2903 10.8499 22.2903 11.5147 21.8107 11.9249L15.1361 17.6294L21.8104 23.3341C22.2901 23.7442 22.2901 24.4089 21.8104 24.8189C21.3308 25.2292 20.5528 25.2292 20.073 24.8189L12.5298 18.3717C12.2902 18.1668 12.1704 17.8981 12.1704 17.6294Z",
                fill: "#1F3A8F"
            })
        ]
    })
;
/* harmony default export */ const icons_SliderArrow = (SliderArrow);

;// CONCATENATED MODULE: ./components/ItemsSlider.js







const SliderPrevArrow = (props)=>/*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
        onClick: props.onClick,
        sx: {
            position: 'absolute',
            top: '50%',
            transform: 'translate(0, -50%)',
            left: -20,
            cursor: 'pointer',
            zIndex: 10
        },
        children: /*#__PURE__*/ jsx_runtime_.jsx(icons_SliderArrow, {})
    })
;
const SliderNextArrow = (props)=>/*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
        onClick: props.onClick,
        sx: {
            position: 'absolute',
            top: '50%',
            transform: 'translate(0, -50%)',
            right: -20,
            cursor: 'pointer',
            zIndex: 10,
            svg: {
                transform: 'rotate(180deg)'
            }
        },
        children: /*#__PURE__*/ jsx_runtime_.jsx(icons_SliderArrow, {})
    })
;
const ItemsSlider = ({ children , slidesToShow , dots =false  })=>{
    const mobile = (0,material_.useMediaQuery)((theme)=>theme.breakpoints.down('lg')
    );
    const settings = {
        arrows: mobile ? false : true,
        infinite: true,
        dots,
        slidesToShow: slidesToShow ? slidesToShow : mobile ? 2 : 6,
        slidesToScroll: 1,
        prevArrow: /*#__PURE__*/ jsx_runtime_.jsx(SliderPrevArrow, {}),
        nextArrow: /*#__PURE__*/ jsx_runtime_.jsx(SliderNextArrow, {})
    };
    return(/*#__PURE__*/ jsx_runtime_.jsx((external_react_slick_default()), {
        ...settings,
        children: children
    }));
};
/* harmony default export */ const components_ItemsSlider = (ItemsSlider);

// EXTERNAL MODULE: ./components/NewProductsList/Product.js + 1 modules
var Product = __webpack_require__(6158);
;// CONCATENATED MODULE: ./components/NewProductsList/SliderProducts.js





const SliderProducts = ({ title ='' , data =[] , slidesToShow  })=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
        my: slidesToShow ? 0 : 5,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                sx: {
                    fontWeight: 600,
                    fontSize: slidesToShow ? 16 : 25,
                    lineHeight: slidesToShow ? '22px' : '34px',
                    mb: slidesToShow ? 0 : 3,
                    textAlign: slidesToShow ? 'center' : 'start'
                },
                children: title
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(components_ItemsSlider, {
                slidesToShow: slidesToShow,
                dots: !!slidesToShow,
                children: data.map((item)=>/*#__PURE__*/ jsx_runtime_.jsx(Product/* default */.Z, {
                        product: item
                    }, item.databaseId)
                )
            })
        ]
    })
;
/* harmony default export */ const NewProductsList_SliderProducts = (SliderProducts);

;// CONCATENATED MODULE: ./pages/index.js














const Home = ({ categories , products , discountedProducts  })=>{
    const mobile = (0,material_.useMediaQuery)((theme)=>theme.breakpoints.down('lg')
    );
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(layout/* default */.Z, {
        categories: categories,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                sx: {
                    py: {
                        xs: 0.5,
                        lg: 1.5
                    },
                    borderBottom: '2px solid rgba(221, 221, 221, 0.5)'
                },
                children: /*#__PURE__*/ jsx_runtime_.jsx(components_ItemsSlider, {
                    slidesToShow: mobile ? 3 : 6,
                    children: categories.map(({ databaseId , name , slug  })=>/*#__PURE__*/ jsx_runtime_.jsx(Link/* default */.Z, {
                            href: `/catalog/${slug}`,
                            sx: {
                                display: 'flex !important',
                                alignItems: 'center',
                                justifyContent: 'center',
                                textAlign: 'center',
                                height: '100%',
                                textTransform: 'uppercase',
                                '&:hover': {
                                    color: 'primary.main'
                                }
                            },
                            children: name
                        }, databaseId)
                    )
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                display: {
                    xs: 'block',
                    lg: 'flex'
                },
                alignItems: "center",
                justifyContent: "space-between",
                mb: 6,
                mt: 1,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                        width: {
                            xs: '100%',
                            lg: 'calc(100% - 300px)'
                        },
                        mt: {
                            xs: 0,
                            lg: 2.5
                        },
                        children: /*#__PURE__*/ jsx_runtime_.jsx(components_ItemsSlider, {
                            slidesToShow: 1,
                            dots: true,
                            children: sliderBanners.map(({ mobImage , image  }, i)=>/*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(Link/* default */.Z, {
                                        href: "/catalog",
                                        sx: {
                                            display: 'block !important',
                                            width: '100%',
                                            height: {
                                                xs: 170,
                                                lg: 388
                                            },
                                            borderRadius: '8px',
                                            position: 'relative'
                                        },
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                                            alt: mobile ? mobImage : image,
                                            src: mobile ? mobImage : image,
                                            layout: "fill",
                                            priority: true
                                        })
                                    })
                                }, i)
                            )
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                        width: {
                            xs: '100%',
                            lg: 244
                        },
                        ml: {
                            xs: 0,
                            lg: 3.5
                        },
                        mt: {
                            xs: 4,
                            lg: 0
                        },
                        children: /*#__PURE__*/ jsx_runtime_.jsx(NewProductsList_SliderProducts, {
                            title: "Товар дня",
                            data: products.slice(0, 4),
                            slidesToShow: mobile ? 2 : 1
                        })
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Categories_categories, {
                title: "Поступление"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(NewProductsList_SliderProducts, {
                title: "Хиты продаж",
                data: products
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(banners, {
                background: 'linear-gradient(88.91deg, #FFE36B -14.56%, #FE5555 124.37%);'
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(NewProductsList_SliderProducts, {
                title: "Новинки",
                data: products
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(banners, {
                background: 'linear-gradient(88.73deg, #4BDBFF 0%, #B35AFF 100.51%);'
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(NewProductsList_SliderProducts, {
                title: "Скидки",
                data: discountedProducts
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(banners, {
                background: 'linear-gradient(268.89deg, #EA56AE 0.52%, #FF6161 117.37%);'
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                my: 5,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                        sx: {
                            fontWeight: 600,
                            fontSize: 25,
                            lineHeight: '34px',
                            mb: 3,
                            textAlign: 'start'
                        },
                        children: "Бренды в наших магазинах"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(components_ItemsSlider, {
                        slidesToShow: mobile ? 4 : 12,
                        children: brands.map(({ slug , image , id  })=>/*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(Link/* default */.Z, {
                                    href: slug,
                                    sx: {
                                        display: 'flex',
                                        justifyContent: 'center',
                                        alignItems: 'center',
                                        border: '1px solid #E8E8E8',
                                        width: 90,
                                        height: 70,
                                        borderRadius: '8px',
                                        position: 'relative'
                                    },
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                                        alt: image,
                                        src: image,
                                        layout: "fill"
                                    })
                                })
                            }, id)
                        )
                    })
                ]
            })
        ]
    }));
};
/* harmony default export */ const pages = (Home);
async function getStaticProps() {
    const categories = await apollo_client/* client.query */.L.query({
        query: graphql_categories/* CATEGORIES */.a
    });
    const products = await apollo_client/* client.query */.L.query({
        query: graphql_products/* PRODUCTS */.b,
        variables: {
            first: 12
        }
    });
    const discountedProducts = await apollo_client/* client.query */.L.query({
        query: graphql_products/* PRODUCTS */.b,
        variables: {
            first: 12,
            onSale: true
        }
    });
    return {
        props: {
            categories: categories?.data?.productCategories?.nodes,
            products: products?.data?.products?.nodes,
            discountedProducts: discountedProducts.data.products.nodes
        }
    };
}


/***/ }),

/***/ 9114:
/***/ ((module) => {

module.exports = require("@apollo/client");

/***/ }),

/***/ 7812:
/***/ ((module) => {

module.exports = require("@apollo/client/link/context");

/***/ }),

/***/ 5692:
/***/ ((module) => {

module.exports = require("@mui/material");

/***/ }),

/***/ 9868:
/***/ ((module) => {

module.exports = require("@mui/material/useMediaQuery");

/***/ }),

/***/ 7986:
/***/ ((module) => {

module.exports = require("@mui/system");

/***/ }),

/***/ 562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 8028:
/***/ ((module) => {

module.exports = require("next/dist/server/image-config.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 4365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 3018:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/to-base-64.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 6022:
/***/ ((module) => {

module.exports = require("react-redux");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [730,61,932,987,158], () => (__webpack_exec__(3235)));
module.exports = __webpack_exports__;

})();