"use strict";
(() => {
var exports = {};
exports.id = 331;
exports.ids = [331];
exports.modules = {

/***/ 4156:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Order),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./apollo-client.js
var apollo_client = __webpack_require__(9999);
;// CONCATENATED MODULE: external "graphql-tag"
const external_graphql_tag_namespaceObject = require("graphql-tag");
var external_graphql_tag_default = /*#__PURE__*/__webpack_require__.n(external_graphql_tag_namespaceObject);
;// CONCATENATED MODULE: ./graphql/order.js

const ORDER = (external_graphql_tag_default())`
  query ORDER($id: ID!) {
    order(id: $id, idType: ORDER_NUMBER) {
      databaseId
      orderKey
      date
      customerNote
      total(format: RAW)
      paymentMethodTitle
      discountTotal(format: RAW)
      subtotal(format: RAW)
      shippingLines {
        nodes {
          methodTitle
          total
        }
      }
      lineItems {
        nodes {
          product {
            image {
              sourceUrl
            }
            name
            databaseId
            onSale
            ... on SimpleProduct {
              woocsRegularPrice
              woocsSalePrice
            }
            ... on VariableProduct {
              woocsRegularPrice
              woocsSalePrice
            }
          }
          quantity
          total
          subtotal
        }
      }
    }
  }
`;
/* harmony default export */ const graphql_order = (ORDER);

// EXTERNAL MODULE: ./components/Layout/layout.js + 21 modules
var layout = __webpack_require__(9758);
// EXTERNAL MODULE: ./graphql/categories.js
var graphql_categories = __webpack_require__(3610);
// EXTERNAL MODULE: ./components/Breadcrumbs/breadcrumbs.js
var Breadcrumbs_breadcrumbs = __webpack_require__(741);
// EXTERNAL MODULE: ./components/SectionTitle/section-title.js
var section_title = __webpack_require__(2161);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(5692);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
// EXTERNAL MODULE: ./components/OrderDetails/order-details.js
var order_details = __webpack_require__(852);
// EXTERNAL MODULE: ./utility/formatPrice.js
var formatPrice = __webpack_require__(1770);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
;// CONCATENATED MODULE: ./pages/order/[slug].js













function Order({ order , categories  }) {
    const { push  } = (0,router_.useRouter)();
    const breadcrumbs = [
        {
            name: 'Главная',
            slug: '/'
        },
        {
            name: 'Ваш заказ принят',
            slug: `/`
        }, 
    ];
    const header = [
        'МОДЕЛЬ',
        'НАИМЕНОВАНИЕ',
        'ЦЕНА',
        'КОЛИЧЕСТВО',
        'ИТОГО'
    ];
    const products = order.lineItems.nodes;
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(layout/* default */.Z, {
        categories: categories,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(Breadcrumbs_breadcrumbs/* default */.Z, {
                breadcrumbs: breadcrumbs
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(section_title/* default */.Z, {
                title: "Ваш заказ принят"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                sx: {
                    display: 'flex',
                    justifyContent: 'space-between',
                    flexDirection: {
                        xs: 'column',
                        md: 'row'
                    },
                    marginBottom: '50px'
                },
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                        display: {
                            xs: 'none',
                            lg: 'block'
                        },
                        width: {
                            xs: '100%',
                            md: '65%'
                        },
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                                display: "flex",
                                alignItems: "center",
                                width: "100%",
                                mb: 1,
                                children: header.map((item, i)=>/*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                                        flex: i === 0 ? '0 0 90px' : i === 1 ? '0 0 25%' : '0 0 20%',
                                        pr: 2.5,
                                        mr: i === 0 ? 2.5 : 0,
                                        children: item
                                    }, item)
                                )
                            }),
                            products.map((item)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                                    sx: {
                                        display: 'flex',
                                        width: '100%',
                                        borderTop: '1px solid #E8E8E8',
                                        py: 2,
                                        '& > div': {
                                            pr: 2.5
                                        }
                                    },
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                                            flex: "0 0 90px",
                                            position: "relative",
                                            height: 110,
                                            borderRadius: "8px",
                                            overflow: "hidden",
                                            mr: 2.5,
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                                                alt: item.product.name,
                                                src: item.product.image.sourceUrl,
                                                layout: "fill"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                                            flex: "0 0 25%",
                                            color: "#606060",
                                            children: item.product.name
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                                            flex: "0 0 20%",
                                            sx: {
                                                fontSize: {
                                                    xs: 15,
                                                    lg: 19
                                                },
                                                lineHeight: {
                                                    xs: '20px',
                                                    lg: '26px'
                                                },
                                                fontWeight: 600,
                                                color: 'text.primary'
                                            },
                                            children: [
                                                item.product.onSale && /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                                                    sx: {
                                                        fontSize: {
                                                            xs: 15,
                                                            lg: 16
                                                        },
                                                        lineHeight: {
                                                            xs: '20px',
                                                            lg: '22px'
                                                        },
                                                        textDecoration: 'line-through',
                                                        textDecorationColor: 'red',
                                                        color: '#606060',
                                                        fontWeight: 400
                                                    },
                                                    children: (0,formatPrice/* formatPrice */.T)(item.product.woocsRegularPrice)
                                                }),
                                                (0,formatPrice/* formatPrice */.T)(item.product.onSale ? item.product.woocsSalePrice : item.product.woocsRegularPrice)
                                            ]
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                                            flex: "0 0 20%",
                                            children: item.quantity
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                                            sx: {
                                                display: 'flex',
                                                justifyContent: 'space-between',
                                                flex: 'auto',
                                                fontSize: {
                                                    xs: 15,
                                                    lg: 19
                                                },
                                                lineHeight: {
                                                    xs: '20px',
                                                    lg: '26px'
                                                },
                                                fontWeight: 600,
                                                color: 'text.primary'
                                            },
                                            children: (0,formatPrice/* formatPrice */.T)((item.product.onSale ? item.product.woocsSalePrice : item.product.woocsRegularPrice) * item.quantity)
                                        })
                                    ]
                                }, item.product.databaseId)
                            )
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                        display: {
                            xs: 'block',
                            lg: 'none'
                        },
                        width: "100%",
                        borderBottom: "1px solid #E8E8E8",
                        mb: 2,
                        pb: 2,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                                display: "flex",
                                alignItems: "center",
                                width: "100%",
                                mb: 1,
                                children: header.slice(0, 3).map((item, i)=>/*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                                        flex: i === 0 ? '0 0 90px' : i === 1 ? '0 0 calc(60% - 45px)' : '0 0 calc(40% - 45px)',
                                        pr: 1,
                                        mr: i === 0 ? 1 : 0,
                                        children: item
                                    }, item)
                                )
                            }),
                            products.map((item)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                                            sx: {
                                                display: 'flex',
                                                width: '100%',
                                                borderTop: '1px solid #E8E8E8',
                                                py: 1,
                                                '& > div': {
                                                    pr: 1
                                                }
                                            },
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                                                    flex: "0 0 90px",
                                                    position: "relative",
                                                    height: 110,
                                                    borderRadius: "8px",
                                                    overflow: "hidden",
                                                    mr: 1,
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                                                        alt: item.product.name,
                                                        src: item.product.image.sourceUrl,
                                                        layout: "fill"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                                                    flex: "0 0 calc(60% - 45px)",
                                                    color: "#606060",
                                                    children: item.product.name
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                                                    flex: "0 0 calc(40% - 45px)",
                                                    sx: {
                                                        fontSize: {
                                                            xs: 15,
                                                            lg: 19
                                                        },
                                                        lineHeight: {
                                                            xs: '20px',
                                                            lg: '26px'
                                                        },
                                                        fontWeight: 600,
                                                        color: 'text.primary'
                                                    },
                                                    children: [
                                                        item.product.onSale && /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                                                            sx: {
                                                                fontSize: {
                                                                    xs: 15,
                                                                    lg: 16
                                                                },
                                                                lineHeight: {
                                                                    xs: '20px',
                                                                    lg: '22px'
                                                                },
                                                                textDecoration: 'line-through',
                                                                textDecorationColor: 'red',
                                                                color: '#606060',
                                                                fontWeight: 400
                                                            },
                                                            children: (0,formatPrice/* formatPrice */.T)(item.product.woocsRegularPrice)
                                                        }),
                                                        (0,formatPrice/* formatPrice */.T)(item.product.onSale ? item.product.woocsSalePrice : item.product.woocsRegularPrice)
                                                    ]
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                                            display: "flex",
                                            alignItems: "center",
                                            pb: 2,
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                                                    width: 90,
                                                    display: "flex",
                                                    justifyContent: "center",
                                                    mr: 1,
                                                    children: item.quantity
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                                                    sx: {
                                                        display: 'flex',
                                                        justifyContent: 'space-between',
                                                        fontSize: {
                                                            xs: 15,
                                                            lg: 19
                                                        },
                                                        lineHeight: {
                                                            xs: '20px',
                                                            lg: '26px'
                                                        },
                                                        fontWeight: 600,
                                                        color: 'text.primary',
                                                        width: 'calc(100% - 98px)'
                                                    },
                                                    children: (0,formatPrice/* formatPrice */.T)((item.product.onSale ? item.product.woocsSalePrice : item.product.woocsRegularPrice) * item.quantity)
                                                })
                                            ]
                                        })
                                    ]
                                }, item.product.databaseId)
                            )
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                        sx: {
                            width: {
                                xs: '100%',
                                md: '33%'
                            }
                        },
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                                sx: {
                                    width: '100%'
                                },
                                children: /*#__PURE__*/ jsx_runtime_.jsx(order_details/* default */.Z, {
                                    length: products.length,
                                    total: order.total,
                                    deliveryPrice: order?.shippingLines?.nodes[0]?.total,
                                    subtotal: order.subtotal
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(material_.Button, {
                                fullWidth: true,
                                variant: "contained",
                                onClick: ()=>push('/')
                                ,
                                sx: {
                                    py: 1.5,
                                    px: 3.5,
                                    mt: 2
                                },
                                children: "ВЕРНУТЬСЯ НА ГЛАВНУЮ"
                            })
                        ]
                    })
                ]
            })
        ]
    }));
};
const getServerSideProps = async ({ params  })=>{
    const order = await apollo_client/* client.query */.L.query({
        query: graphql_order,
        variables: {
            id: params.slug
        }
    });
    const categories = await apollo_client/* client.query */.L.query({
        query: graphql_categories/* CATEGORIES */.a
    });
    return {
        props: {
            order: order.data.order,
            categories: categories.data.productCategories.nodes
        }
    };
};


/***/ }),

/***/ 9114:
/***/ ((module) => {

module.exports = require("@apollo/client");

/***/ }),

/***/ 7812:
/***/ ((module) => {

module.exports = require("@apollo/client/link/context");

/***/ }),

/***/ 5692:
/***/ ((module) => {

module.exports = require("@mui/material");

/***/ }),

/***/ 9868:
/***/ ((module) => {

module.exports = require("@mui/material/useMediaQuery");

/***/ }),

/***/ 562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 8028:
/***/ ((module) => {

module.exports = require("next/dist/server/image-config.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 4365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 3018:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/to-base-64.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 6022:
/***/ ((module) => {

module.exports = require("react-redux");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [730,61,932,620], () => (__webpack_exec__(4156)));
module.exports = __webpack_exports__;

})();