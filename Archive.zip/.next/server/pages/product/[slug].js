"use strict";
(() => {
var exports = {};
exports.id = 915;
exports.ids = [915];
exports.modules = {

/***/ 6780:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Product),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./components/Layout/layout.js + 21 modules
var layout = __webpack_require__(9758);
// EXTERNAL MODULE: ./components/Breadcrumbs/breadcrumbs.js
var Breadcrumbs_breadcrumbs = __webpack_require__(741);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(5692);
;// CONCATENATED MODULE: external "react-image-gallery"
const external_react_image_gallery_namespaceObject = require("react-image-gallery");
var external_react_image_gallery_default = /*#__PURE__*/__webpack_require__.n(external_react_image_gallery_namespaceObject);
// EXTERNAL MODULE: ./components/SectionTitle/section-title.js
var section_title = __webpack_require__(2161);
// EXTERNAL MODULE: ./utility/formatPrice.js
var formatPrice = __webpack_require__(1770);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(6022);
;// CONCATENATED MODULE: ./public/icons/arrowDown.js


const ArrowDown = ()=>{
    return(/*#__PURE__*/ jsx_runtime_.jsx("svg", {
        width: "15",
        height: "10",
        viewBox: "0 0 15 10",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
            d: "M7.03755 9.79769L0.208873 2.10206C-0.0357703 1.84953 -0.0357703 1.43998 0.208873 1.18745C0.453498 0.934914 0.850429 0.934914 1.09507 1.18745L7.51249 8.41906L13.9299 1.18809C14.1745 0.935555 14.5715 0.935555 14.8161 1.18809C15.0607 1.44062 15.0607 1.85017 14.8161 2.10268L7.98741 9.79833C7.85699 9.93292 7.6841 9.99063 7.51311 9.98164C7.34148 9.99001 7.16861 9.93232 7.03755 9.79769Z",
            fill: "#606060"
        })
    }));
};
/* harmony default export */ const arrowDown = (ArrowDown);

;// CONCATENATED MODULE: ./public/icons/DeliveryIcon.js


const DeliveryIcon = ()=>{
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
        width: "35",
        height: "26",
        viewBox: "0 0 35 26",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                d: "M0 8.56055L10 8.56055",
                stroke: "#EA56AE",
                strokeWidth: "2"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                d: "M5 19.5605L10 19.5605",
                stroke: "#EA56AE",
                strokeWidth: "2"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                d: "M24.9087 13.2049L23.7354 13.8792V25.9999L34.3012 19.9423V7.82153L24.9087 13.2049Z",
                fill: "#EA56AE"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                d: "M26.8219 2.33568L22.7586 0L11.8994 6.22489L15.9682 8.56057L26.8219 2.33568Z",
                fill: "#EA56AE"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                d: "M33.6116 6.22496L28.9289 3.57642L18.0752 9.80131L18.6945 10.1196L22.7578 12.4499L26.7995 10.1357L33.6116 6.22496Z",
                fill: "#EA56AE"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                d: "M17.2556 14.2569L15.3108 13.2644V10.1789L11.3018 7.88641V19.9208L21.7915 25.9354V13.9009L17.2556 11.3063V14.2569Z",
                fill: "#EA56AE"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                d: "M2 14.5605L10 14.5605",
                stroke: "#EA56AE",
                strokeWidth: "2"
            })
        ]
    }));
};
/* harmony default export */ const icons_DeliveryIcon = (DeliveryIcon);

;// CONCATENATED MODULE: ./public/icons/Wallet.js


const Wallet = ()=>{
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
        width: "23",
        height: "22",
        viewBox: "0 0 23 22",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                d: "M16.8883 17.1977C15.7861 17.1976 14.8895 16.3094 14.8895 15.2175V11.9291C14.8895 10.8372 15.7861 9.94898 16.8883 9.94898H22.0964C22.1279 9.94898 22.1593 9.94993 22.1905 9.95132V6.67549C22.1905 5.83225 21.5005 5.14868 20.6493 5.14868H1.54121C0.69 5.14863 0 5.8322 0 6.67544V20.4711C0 21.3144 0.69 21.998 1.54121 21.998H20.6493C21.5005 21.998 22.1905 21.3144 22.1905 20.4711V17.1953C22.1593 17.1967 22.1279 17.1977 22.0964 17.1977H16.8883Z",
                fill: "#EA56AE"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                d: "M22.096 11.0338H16.8879C16.3889 11.0338 15.9844 11.4346 15.9844 11.9289V15.2174C15.9844 15.7117 16.3889 16.1125 16.8879 16.1125H22.096C22.595 16.1125 22.9995 15.7118 22.9995 15.2174V11.9289C22.9995 11.4345 22.595 11.0338 22.096 11.0338ZM18.6825 14.8651C17.9623 14.8651 17.3784 14.2866 17.3784 13.5731C17.3784 12.8596 17.9623 12.2811 18.6825 12.2811C19.4028 12.2811 19.9866 12.8596 19.9866 13.5731C19.9866 14.2866 19.4028 14.8651 18.6825 14.8651Z",
                fill: "#EA56AE"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                d: "M17.9646 2.35165C17.6198 1.31775 16.4943 0.756521 15.4507 1.09811L7.62109 3.6607H18.4012L17.9646 2.35165Z",
                fill: "#EA56AE"
            })
        ]
    }));
};
/* harmony default export */ const icons_Wallet = (Wallet);

;// CONCATENATED MODULE: ./components/ProductCardAccordion/product-card-accordion.js






const ProductCardAccordion = ()=>{
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Accordion, {
                sx: {
                    backgroundColor: 'transparent',
                    boxShadow: 'none',
                    borderTop: '1px solid #E8E8E8'
                },
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.AccordionSummary, {
                        expandIcon: /*#__PURE__*/ jsx_runtime_.jsx(arrowDown, {}),
                        "aria-controls": "panel1a-content",
                        id: "panel1a-header",
                        sx: {
                            display: 'flex',
                            alignItems: 'center'
                        },
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(material_.IconButton, {
                                "aria-label": "delivery",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(icons_DeliveryIcon, {})
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                sx: {
                                    fontWeight: 600,
                                    fontSize: '16px',
                                    color: 'text.primary'
                                },
                                children: "Доставка по Ташкенту"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.AccordionDetails, {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                            sx: {
                                fontWeight: 400,
                                fontSize: '16px',
                                color: 'grey.main'
                            },
                            children: "Формула шампуня для тела и волос Chicco Baby Moments мягко очищает нежную кожу малыша, начиная с принятия первых ванн."
                        })
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(material_.Accordion, {
                sx: {
                    backgroundColor: 'transparent',
                    boxShadow: 'none',
                    borderTop: '1px solid #E8E8E8'
                },
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.AccordionSummary, {
                    expandIcon: /*#__PURE__*/ jsx_runtime_.jsx(arrowDown, {}),
                    "aria-controls": "panel1a-content",
                    id: "panel1a-header",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(material_.IconButton, {
                            "aria-label": "delivery",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(icons_DeliveryIcon, {})
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                            sx: {
                                fontWeight: 600,
                                fontSize: '16px',
                                color: 'text.primary'
                            },
                            children: "Доставка по Узбекистану"
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Accordion, {
                sx: {
                    backgroundColor: 'transparent',
                    boxShadow: 'none',
                    borderTop: '1px solid #E8E8E8'
                },
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.AccordionSummary, {
                        expandIcon: /*#__PURE__*/ jsx_runtime_.jsx(arrowDown, {}),
                        "aria-controls": "panel1a-content",
                        id: "panel1a-header",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(material_.IconButton, {
                                "aria-label": "delivery",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(icons_Wallet, {})
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                sx: {
                                    fontWeight: 600,
                                    fontSize: '16px',
                                    color: 'text.primary'
                                },
                                children: "Оплата"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.AccordionDetails, {
                        sx: {
                            fontWeight: 400,
                            fontSize: '16px',
                            color: 'grey.main'
                        },
                        children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                            children: "Детское молочко содержит уникальную комбинацию ингредиентов: OPTIPRO\xae, 2’FL и BL Probiotic, которые поддержат здоровое развитие вашего ребенка"
                        })
                    })
                ]
            })
        ]
    }));
};
/* harmony default export */ const product_card_accordion = (ProductCardAccordion);

// EXTERNAL MODULE: external "@mui/material/useMediaQuery"
var useMediaQuery_ = __webpack_require__(9868);
var useMediaQuery_default = /*#__PURE__*/__webpack_require__.n(useMediaQuery_);
// EXTERNAL MODULE: ./components/NewProductsList/index.js
var NewProductsList = __webpack_require__(733);
// EXTERNAL MODULE: ./components/NewSetQuantity.js + 1 modules
var NewSetQuantity = __webpack_require__(9987);
// EXTERNAL MODULE: ./redux/actions/cart.js
var actions_cart = __webpack_require__(6613);
;// CONCATENATED MODULE: ./components/ProductCard/product-card.js













const ProductCard = ({ product  })=>{
    const dispatch = (0,external_react_redux_.useDispatch)();
    const mobile = useMediaQuery_default()((theme)=>theme.breakpoints.down('lg')
    );
    const cart = (0,external_react_redux_.useSelector)((state)=>state.cart
    );
    const { 0: quantity , 1: setQuantity  } = (0,external_react_.useState)(1);
    const alreadyAddedToCart = !!cart.find((item)=>item.selectedId === product.databaseId
    );
    const images = [
        {
            original: product.image.sourceUrl,
            thumbnail: product.image.sourceUrl
        },
        ...product?.galleryImages?.nodes?.map(({ sourceUrl  })=>({
                original: sourceUrl,
                thumbnail: sourceUrl
            })
        ), 
    ];
    const quantityInCart = cart.find((item)=>item.selectedId === product.databaseId
    )?.selectedQuantity;
    (0,external_react_.useEffect)(()=>{
        if (quantityInCart) {
            setQuantity(quantityInCart);
        }
    }, [
        quantityInCart
    ]);
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(section_title/* default */.Z, {
                title: product.name
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                sx: {
                    display: 'flex',
                    flexDirection: {
                        xs: 'column',
                        lg: 'row'
                    },
                    marginBottom: {
                        xs: '15px',
                        lg: '90px'
                    }
                },
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                        sx: {
                            width: {
                                xs: '100%',
                                lg: '45%'
                            },
                            mr: {
                                xs: 0,
                                lg: 3
                            },
                            mb: {
                                xs: 2,
                                lg: 0
                            },
                            '.image-gallery-slide .image-gallery-image': {
                                objectFit: 'cover !important',
                                minHeight: {
                                    xs: '340px !important',
                                    lg: '580px !important'
                                },
                                height: {
                                    xs: '340px !important',
                                    lg: '580px !important'
                                },
                                maxHeight: {
                                    xs: '340px !important',
                                    lg: '580px !important'
                                }
                            },
                            '.image-gallery-thumbnail': {
                                width: {
                                    lg: '90px'
                                },
                                borderRadius: '8px'
                            },
                            '.image-gallery-thumbnail ': {
                                border: '2px solid #EA56AE;'
                            },
                            '.image-gallery-right-nav .image-gallery-svg': {
                                height: '72px !important',
                                width: '36px !important'
                            },
                            '.image-gallery-left-nav .image-gallery-svg': {
                                height: '72px !important',
                                width: '36px !important'
                            },
                            '@media (hover: hover) and (pointer: fine)': {
                                '.image-gallery-icon:hover': {
                                    color: '#f6a68d !important'
                                },
                                '.image-gallery-bullets .image-gallery-bullet:hover': {
                                    background: '#f6a68d !important',
                                    border: '1px solid #f6a68d !important'
                                }
                            }
                        },
                        children: /*#__PURE__*/ jsx_runtime_.jsx((external_react_image_gallery_default()), {
                            items: images,
                            thumbnailPosition: "left",
                            showThumbnails: !mobile,
                            showBullets: false,
                            showPlayButton: false,
                            showFullscreenButton: false,
                            autoPlay: false
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                        sx: {
                            width: {
                                xs: '100%',
                                lg: '40%'
                            }
                        },
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                                sx: {
                                    fontSize: {
                                        xs: 15,
                                        lg: 19
                                    },
                                    lineHeight: {
                                        xs: '20px',
                                        lg: '26px'
                                    },
                                    fontWeight: 600,
                                    color: 'text.primary',
                                    mt: 'auto',
                                    mb: 1
                                },
                                children: [
                                    product?.onSale && /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                                        sx: {
                                            fontSize: {
                                                xs: 15,
                                                lg: 16
                                            },
                                            lineHeight: {
                                                xs: '20px',
                                                lg: '22px'
                                            },
                                            textDecoration: 'line-through',
                                            textDecorationColor: 'red',
                                            color: '#606060',
                                            fontWeight: 400
                                        },
                                        children: (0,formatPrice/* formatPrice */.T)(product?.woocsRegularPrice)
                                    }),
                                    (0,formatPrice/* formatPrice */.T)(product?.onSale ? product?.woocsSalePrice : product?.woocsRegularPrice)
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Typography, {
                                sx: {
                                    color: 'grey.main',
                                    fontSize: '15px',
                                    fontWeight: '400',
                                    pb: 2,
                                    borderBottom: '1px solid #E8E8E8'
                                },
                                children: [
                                    "Артикул: ",
                                    product.sku
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                                display: "flex",
                                alignItems: "center",
                                my: 2.5,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(NewSetQuantity/* default */.Z, {
                                        quantity: quantity,
                                        setQuantity: setQuantity,
                                        max: product?.stockQuantity,
                                        id: product?.databaseId,
                                        mr: {
                                            xs: 1,
                                            lg: 1.5
                                        }
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Button, {
                                        fullWidth: true,
                                        color: alreadyAddedToCart ? 'secondary' : 'primary',
                                        onClick: alreadyAddedToCart ? ()=>dispatch((0,actions_cart/* removeFromCart */.h2)(product?.databaseId))
                                         : ()=>dispatch((0,actions_cart/* addToCart */.Xq)(product, product?.databaseId, quantity))
                                        ,
                                        sx: {
                                            color: 'common.white',
                                            py: 1.5,
                                            px: 3.5
                                        },
                                        children: alreadyAddedToCart ? 'В КОРЗИНЕ' : 'ДОБАВИТЬ В КОРЗИНУ'
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(product_card_accordion, {})
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Grid, {
                container: true,
                spacing: 3,
                sx: {
                    marginBottom: '90px'
                },
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Grid, {
                        item: true,
                        xs: 12,
                        lg: 5,
                        children: [
                            product?.description && /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                                sx: {
                                    mb: 5
                                },
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(section_title/* default */.Z, {
                                        title: "Описание"
                                    }),
                                    product?.description
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(section_title/* default */.Z, {
                                        title: "Характеристики:"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Stack, {
                                        sx: {
                                            maxWidth: '400px',
                                            width: '100%'
                                        },
                                        direction: "column",
                                        spacing: 1,
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                                                sx: {
                                                    display: 'flex',
                                                    justifyContent: 'space-between'
                                                },
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                                        sx: {
                                                            fontWeight: 400,
                                                            fontSize: '16px',
                                                            color: 'grey.main'
                                                        },
                                                        children: "Бренд:"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                                        sx: {
                                                            fontWeight: 400,
                                                            fontSize: '16px',
                                                            color: 'text.primary'
                                                        }
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                                                sx: {
                                                    display: 'flex',
                                                    justifyContent: 'space-between'
                                                },
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                                        sx: {
                                                            fontWeight: 400,
                                                            fontSize: '16px',
                                                            color: 'grey.main'
                                                        },
                                                        children: "Артикул:"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                                        sx: {
                                                            fontWeight: 400,
                                                            fontSize: '16px',
                                                            color: 'text.primary'
                                                        },
                                                        children: product.sku
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                                                sx: {
                                                    display: 'flex',
                                                    justifyContent: 'space-between'
                                                },
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                                        sx: {
                                                            fontWeight: 400,
                                                            fontSize: '16px',
                                                            color: 'grey.main'
                                                        },
                                                        children: "Производитель:"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                                        sx: {
                                                            fontWeight: 400,
                                                            fontSize: '16px',
                                                            color: 'text.primary'
                                                        }
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Grid, {
                        item: true,
                        xs: 12,
                        lg: 7,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(section_title/* default */.Z, {
                                title: "С этим товаром рекомендуют"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(NewProductsList/* default */.Z, {
                                data: product.related.nodes.slice(0, 3),
                                productCard2: true
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                fontWeight: 600,
                fontSize: 25,
                lineHeight: "34px",
                mb: 2,
                children: "Похожие товары"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(NewProductsList/* default */.Z, {
                data: product.related.nodes,
                productCard: true
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                mb: 4,
                pb: 4
            })
        ]
    }));
};
/* harmony default export */ const product_card = (ProductCard);

// EXTERNAL MODULE: ./apollo-client.js
var apollo_client = __webpack_require__(9999);
// EXTERNAL MODULE: external "@apollo/client"
var client_ = __webpack_require__(9114);
;// CONCATENATED MODULE: ./graphql/product.js

const PRODUCT = client_.gql`
  query MyQuery($id: ID!) {
    product(id: $id, idType: SLUG) {
      databaseId
      slug
      name
      sku
      onSale
      image {
        sourceUrl
      }
      description
      galleryImages {
        nodes {
          sourceUrl
        }
      }
      productCategories(where: { orderby: TERM_GROUP }) {
        nodes {
          name
          slug
          databaseId
        }
      }
      ... on SimpleProduct {
        woocsRegularPrice
        woocsSalePrice
        stockQuantity
      }
      ... on VariableProduct {
        woocsRegularPrice
        woocsSalePrice
        variations(where: { stockStatus: IN_STOCK }) {
          nodes {
            databaseId
          }
        }
      }
      related(first: 6, where: { shuffle: true, stockStatus: IN_STOCK }) {
        nodes {
          databaseId
          slug
          name
          onSale
          image {
            sourceUrl
          }
          ... on SimpleProduct {
            woocsRegularPrice
            woocsSalePrice
          }
          ... on VariableProduct {
            woocsRegularPrice
            woocsSalePrice
            variations(where: { stockStatus: IN_STOCK }) {
              nodes {
                databaseId
              }
            }
          }
        }
      }
    }
  }
`;

// EXTERNAL MODULE: ./graphql/categories.js
var graphql_categories = __webpack_require__(3610);
;// CONCATENATED MODULE: ./pages/product/[slug].js







function Product({ product , categories  }) {
    const breadcrumbs = [
        {
            name: 'Главная',
            slug: '/'
        },
        {
            name: product.name,
            slug: product.slug
        }, 
    ];
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(layout/* default */.Z, {
        categories: categories,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(Breadcrumbs_breadcrumbs/* default */.Z, {
                breadcrumbs: breadcrumbs
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(product_card, {
                product: product
            })
        ]
    }));
};
async function getServerSideProps({ params  }) {
    const categories = await apollo_client/* client.query */.L.query({
        query: graphql_categories/* CATEGORIES */.a
    });
    const product = await apollo_client/* client.query */.L.query({
        query: PRODUCT,
        variables: {
            id: params.slug
        }
    });
    return {
        props: {
            product: product?.data?.product,
            categories: categories?.data?.productCategories?.nodes
        }
    };
}


/***/ }),

/***/ 9114:
/***/ ((module) => {

module.exports = require("@apollo/client");

/***/ }),

/***/ 7812:
/***/ ((module) => {

module.exports = require("@apollo/client/link/context");

/***/ }),

/***/ 5692:
/***/ ((module) => {

module.exports = require("@mui/material");

/***/ }),

/***/ 9868:
/***/ ((module) => {

module.exports = require("@mui/material/useMediaQuery");

/***/ }),

/***/ 7986:
/***/ ((module) => {

module.exports = require("@mui/system");

/***/ }),

/***/ 562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 8028:
/***/ ((module) => {

module.exports = require("next/dist/server/image-config.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 4365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 3018:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/to-base-64.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 6022:
/***/ ((module) => {

module.exports = require("react-redux");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [730,61,932,987,158,689], () => (__webpack_exec__(6780)));
module.exports = __webpack_exports__;

})();