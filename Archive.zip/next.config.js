module.exports = {
  reactStrictMode: true,
  images: {
    domains: ['kids-planet.billz.work'],
  },
  env: {
    WP_URL: 'https://kids-planet.billz.work',
    GRAPHQL: 'https://kids-planet.billz.work/graphql',
    CONSUMER_KEY: 'ck_d7e1d32f50804e3e75a071376a38c5f9f76a3f32',
    CONSUMER_SECRET: 'cs_830934e7fbdca949727974d0d03cc517ba56cd34',
    WP_TOKEN:
      'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJodHRwczovL2tpZHMtcGxhbmV0LmJpbGx6LndvcmsiLCJpYXQiOjE2MDQ2NjMwMDUsIm5iZiI6MTYwNDY2MzAwNSwiZXhwIjoxNzYyNDI5NDIwLCJkYXRhIjp7InVzZXIiOnsiaWQiOiIxIn19fQ.EfOdjLOAu78KDqvIdwTzhYJABoHXtXQPUzat26dx_Dk',
  },
}
