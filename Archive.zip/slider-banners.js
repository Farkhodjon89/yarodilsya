export const sliderBanners = [
  {
    id: 0,
    image: '/banners/Slider.png',
    mobImage: '/banners/SliderMob.png'
  },
  {
    id: 1,
    image: '/banners/Slider.png',
    mobImage: '/banners/SliderMob.png'
  }
]